shader_type sky;
// Cielo lunar: negro con campo de estrellas procedural.

float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 456.21));
	p += dot(p, p + 45.32);
	return fract(p.x * p.y);
}

void sky() {
	vec3 d = normalize(EYEDIR);
	vec2 uv = vec2(atan(d.x, d.z), asin(clamp(d.y, -1.0, 1.0))) * 70.0;
	vec2 id = floor(uv);
	vec2 f = fract(uv) - 0.5;
	float h = hash21(id);
	float star = step(0.97, h) * smoothstep(0.16, 0.0, length(f));
	float tw = 0.6 + 0.4 * hash21(id + 7.0);
	vec3 tint = mix(vec3(0.7, 0.8, 1.0), vec3(1.0, 0.9, 0.75), hash21(id + 3.0));
	COLOR = tint * star * tw * 1.4 + vec3(0.002, 0.003, 0.006);
}
