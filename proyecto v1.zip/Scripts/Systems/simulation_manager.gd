extends Node
## AUTOLOAD "Sim" — Núcleo de la simulación de LUNAR BASE 01.
## Crea y coordina los sistemas (energía, oxígeno, agua, alimentos, eventos,
## evaluación e interacciones) y mantiene alertas, salud de la tripulación y
## el estado de la misión.

signal alerts_changed
signal toast(text: String, kind: String)
signal mission_started
signal mission_ended(report: Dictionary)
signal dashboard_requested(tab: String)

const PowerSystem = preload("res://Scripts/Systems/power_system.gd")
const OxygenSystem = preload("res://Scripts/Systems/oxygen_system.gd")
const WaterSystem = preload("res://Scripts/Systems/water_system.gd")
const FoodSystem = preload("res://Scripts/Systems/food_system.gd")
const EventSystem = preload("res://Scripts/Systems/event_system.gd")
const EvaluationSystem = preload("res://Scripts/Systems/evaluation_system.gd")
const InteractionManager = preload("res://Scripts/Systems/interaction_manager.gd")
const AudioManager = preload("res://Scripts/Systems/audio_manager.gd")

const BASE_LOAD := 3.0   # kW: aviónica, climatización, comunicaciones
const LAB_LOAD := 1.5    # kW: laboratorio

var config: Resource
var power: Node
var oxygen: Node
var water: Node
var food: Node
var events: Node
var evaluation: Node
var interaction: Node
var audio: Node

var elapsed: float = 0.0
var running: bool = false
var paused: bool = false
var mission_over: bool = false
var ui_blocking: bool = false
var crew_health: float = 100.0
var repair_kits: int = 6
var kit_timer: float = 0.0
var alerts: Dictionary = {}
var station_status: String = "NOMINAL"
var current_prompt: String = ""
var mission_log: Array = []
var last_report: Dictionary = {}
## true si hay un visor OpenXR (Meta Quest, etc.) activo.
var vr_mode: bool = false


func _ready() -> void:
	_init_xr()
	config = load("res://Resources/sim_config.tres")
	if config == null:
		config = load("res://Resources/sim_config.gd").new()
	power = _add_system(PowerSystem, "Power")
	oxygen = _add_system(OxygenSystem, "Oxygen")
	water = _add_system(WaterSystem, "Water")
	food = _add_system(FoodSystem, "Food")
	events = _add_system(EventSystem, "Events")
	evaluation = _add_system(EvaluationSystem, "Evaluation")
	interaction = _add_system(InteractionManager, "Interaction")
	audio = _add_system(AudioManager, "Audio")
	start_mission()


func _init_xr() -> void:
	var xr: XRInterface = XRServer.find_interface("OpenXR")
	if xr and xr.is_initialized():
		vr_mode = true
		get_viewport().use_xr = true
		get_viewport().msaa_3d = Viewport.MSAA_2X
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
		print("LUNAR BASE 01: modo VR (OpenXR) activo")


func _add_system(script: Script, node_name: String) -> Node:
	var n: Node = script.new()
	n.name = node_name
	add_child(n)
	return n


func start_mission() -> void:
	elapsed = 0.0
	crew_health = 100.0
	repair_kits = 6
	kit_timer = 0.0
	alerts.clear()
	mission_log.clear()
	mission_over = false
	paused = false
	ui_blocking = false
	station_status = "NOMINAL"
	last_report = {}
	power.reset()
	oxygen.reset()
	water.reset()
	food.reset()
	events.reset()
	evaluation.reset()
	running = true
	alerts_changed.emit()
	mission_started.emit()
	notify("Misión iniciada. Mantenga la estación estable.", "info")


func _process(delta: float) -> void:
	step(delta)


## Avanza la simulación `delta` segundos reales (usado también por las pruebas).
func step(delta: float) -> void:
	if not running or paused or mission_over:
		return
	var dt: float = delta * config.sim_speed
	elapsed += dt
	power.step(dt)
	oxygen.step(dt)
	water.step(dt)
	food.step(dt)
	events.step(dt)
	_update_crew(dt)
	_update_alerts()
	evaluation.step(dt)
	kit_timer += dt
	if kit_timer >= 75.0:
		kit_timer = 0.0
		if repair_kits < 8:
			repair_kits += 1
			notify("Llegó un kit de reparación (suministro automático).", "info")
	if crew_health <= 0.0:
		end_mission("PÉRDIDA DE LA TRIPULACIÓN", false)
	elif elapsed >= config.mission_duration:
		end_mission("MISIÓN COMPLETADA", true)


## Demanda eléctrica total de la estación en kW.
func total_power_demand() -> float:
	return BASE_LOAD + LAB_LOAD + power.extra_load() + oxygen.power_demand() \
		+ water.power_demand() + food.power_demand()


func use_kit() -> bool:
	if repair_kits <= 0:
		notify("No quedan kits de reparación. Espere el próximo suministro.", "bad")
		return false
	repair_kits -= 1
	return true


func notify(text: String, kind: String = "info") -> void:
	mission_log.append("[%s] %s" % [format_clock(elapsed), text])
	if mission_log.size() > 40:
		mission_log.pop_front()
	toast.emit(text, kind)


func set_alert(key: String, text: String, severity: int) -> void:
	var cur = alerts.get(key)
	if cur != null and cur["text"] == text and cur["severity"] == severity:
		return
	var is_new: bool = cur == null or cur["severity"] < severity
	alerts[key] = {"text": text, "severity": severity}
	alerts_changed.emit()
	if is_new and severity >= 2 and audio:
		audio.play_alarm()


func clear_alert(key: String) -> void:
	if alerts.erase(key):
		alerts_changed.emit()


func critical_count() -> int:
	var c := 0
	for k in alerts:
		if alerts[k]["severity"] >= 2:
			c += 1
	return c


func format_clock(real_seconds: float) -> String:
	var t: int = int(real_seconds * config.clock_scale)
	var d: int = t / 86400
	var h: int = (t % 86400) / 3600
	var m: int = (t % 3600) / 60
	var s: int = t % 60
	return "D%d %02d:%02d:%02d" % [d, h, m, s]


func end_mission(reason: String, success: bool) -> void:
	if mission_over:
		return
	mission_over = true
	running = false
	last_report = evaluation.build_report(reason, success)
	mission_ended.emit(last_report)


func _update_crew(dt: float) -> void:
	var dmg := 0.0
	if oxygen.cabin <= 0.0:
		dmg += 2.0
	elif oxygen.cabin < 15.0:
		dmg += 0.4
	if water.reserve <= 0.0:
		dmg += 0.3
	if food.stock <= 0.0:
		dmg += 0.15
	if power.supply_ratio < 0.1:
		dmg += 0.2
	if dmg > 0.0:
		crew_health = maxf(0.0, crew_health - dmg * dt)
	elif oxygen.cabin > 50.0:
		crew_health = minf(100.0, crew_health + 0.2 * dt)


func _level_alert(key: String, pct: float, warn: float, crit: float, label: String) -> void:
	if pct <= crit:
		set_alert(key, "%s CRÍTICO (%d%%)" % [label, int(pct)], 2)
	elif pct <= warn:
		set_alert(key, "%s BAJO (%d%%)" % [label, int(pct)], 1)
	else:
		clear_alert(key)


func _update_alerts() -> void:
	_level_alert("lvl_energy", power.percent(), 25.0, 10.0, "ENERGÍA")
	_level_alert("lvl_cabin", oxygen.cabin, 40.0, 20.0, "O₂ DE CABINA")
	_level_alert("lvl_o2res", oxygen.reserve_percent(), 25.0, 10.0, "RESERVA DE O₂")
	_level_alert("lvl_water", water.percent(), 25.0, 10.0, "AGUA")
	_level_alert("lvl_food", food.percent(), 20.0, 8.0, "ALIMENTOS")
	var demand: float = total_power_demand()
	if power.generation < demand and power.sun_factor <= 0.01:
		set_alert("gen_low", "NOCHE LUNAR: generación insuficiente", 1)
	elif power.generation < demand * 0.8 and power.sun_factor > 0.01:
		set_alert("gen_low", "GENERACIÓN INSUFICIENTE", 1)
	else:
		clear_alert("gen_low")
	if food.stalled_reason != "":
		set_alert("crops_stalled", "CULTIVOS DETENIDOS: " + food.stalled_reason, 1)
	else:
		clear_alert("crops_stalled")
	if crew_health < 40.0:
		set_alert("crew", "SALUD DE LA TRIPULACIÓN %d%%" % int(crew_health), 2)
	elif crew_health < 80.0:
		set_alert("crew", "SALUD DE LA TRIPULACIÓN %d%%" % int(crew_health), 1)
	else:
		clear_alert("crew")
	var new_status := "NOMINAL"
	if critical_count() > 0:
		new_status = "CRÍTICO"
	elif not alerts.is_empty():
		new_status = "ADVERTENCIA"
	station_status = new_status
