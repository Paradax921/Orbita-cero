extends Node
## SISTEMA DE ALIMENTOS — INVERNADERO HIDROPÓNICO
## 6 bandejas con 5 etapas: 0 vacía, 1 semilla, 2 brote, 3 crecimiento, 4 madura.
## El crecimiento requiere: luces encendidas + energía (>=50 %) + agua + nutrientes.
## La cosecha llena el almacén; la tripulación consume alimentos continuamente.

const PLOTS := 6
const STAGE_TIME := [0.0, 15.0, 20.0, 25.0]   # s para pasar de etapa 1->2, 2->3, 3->4
const STAGE_NAMES := ["Vacía", "Semilla", "Brote", "Crecimiento", "Madura"]
const WATER_USE := 0.006     # u/s por bandeja en crecimiento
const NUTRIENT_USE := 0.02   # u/s por bandeja en crecimiento
const LIGHT_POWER := 4.0     # kW
const CREW_USE := 0.035      # u/s por tripulante
const HARVEST_YIELD := 6.0
const CAP := 100.0

var plots: Array = []        # [{stage, progress, blight}]
var stock: float = 45.0
var nutrients: float = 100.0
var lights_on: bool = true
var stalled_reason: String = ""
var harvested_total: float = 0.0
var consumed_total: float = 0.0


func reset() -> void:
	plots.clear()
	var stages := [3, 2, 2, 1, 1, 0]
	var progs := [0.5, 0.4, 0.1, 0.5, 0.0, 0.0]
	for i in PLOTS:
		plots.append({"stage": stages[i], "progress": progs[i], "blight": false})
	stock = 45.0
	nutrients = 100.0
	lights_on = true
	stalled_reason = ""
	harvested_total = 0.0
	consumed_total = 0.0


func percent() -> float:
	return stock / CAP * 100.0


func power_demand() -> float:
	return LIGHT_POWER if lights_on else 0.0


func ripe_count() -> int:
	var c := 0
	for p in plots:
		if p["stage"] == 4:
			c += 1
	return c


func empty_count() -> int:
	var c := 0
	for p in plots:
		if p["stage"] == 0:
			c += 1
	return c


func blight_count() -> int:
	var c := 0
	for p in plots:
		if p["blight"]:
			c += 1
	return c


func growing_count() -> int:
	var c := 0
	for p in plots:
		if p["stage"] >= 1 and p["stage"] <= 3 and not p["blight"]:
			c += 1
	return c


func toggle_lights() -> void:
	lights_on = not lights_on


func plant_all() -> int:
	var n := 0
	for p in plots:
		if p["stage"] == 0:
			p["stage"] = 1
			p["progress"] = 0.0
			p["blight"] = false
			n += 1
	return n


func harvest_all() -> float:
	var total := 0.0
	for p in plots:
		if p["stage"] == 4:
			total += HARVEST_YIELD
			p["stage"] = 0
			p["progress"] = 0.0
	var added: float = minf(total, CAP - stock)
	stock += added
	harvested_total += added
	return added


func treat_blight() -> int:
	var n := 0
	for p in plots:
		if p["blight"]:
			p["blight"] = false
			n += 1
	return n


## Prepara solución nutritiva: cuesta 5 u de agua. Devuelve false si no hay agua.
func mix_nutrients() -> bool:
	if Sim.water.reserve < 5.0:
		return false
	Sim.water.draw(5.0)
	nutrients = minf(100.0, nutrients + 50.0)
	return true


func step(dt: float) -> void:
	var r: float = Sim.power.supply_ratio
	var reason := ""
	if growing_count() > 0:
		if not lights_on:
			reason = "luces apagadas"
		elif r < 0.5:
			reason = "energía insuficiente"
		elif Sim.water.reserve <= 1.0:
			reason = "sin agua"
		elif nutrients <= 0.0:
			reason = "sin nutrientes"
	if blight_count() > 0 and reason == "":
		reason = "plaga en bandejas"
	stalled_reason = reason

	if lights_on and r >= 0.5 and Sim.water.reserve > 1.0 and nutrients > 0.0:
		for p in plots:
			var st: int = p["stage"]
			if st < 1 or st > 3 or p["blight"]:
				continue
			Sim.water.draw(WATER_USE * dt)
			nutrients = maxf(0.0, nutrients - NUTRIENT_USE * dt)
			p["progress"] += dt / STAGE_TIME[st]
			if p["progress"] >= 1.0:
				p["stage"] = st + 1
				p["progress"] = 0.0
	var use: float = Sim.config.crew_size * CREW_USE * dt
	var eaten: float = minf(use, stock)
	stock -= eaten
	consumed_total += use
