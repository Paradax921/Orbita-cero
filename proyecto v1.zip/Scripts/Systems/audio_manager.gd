extends Node
## Audio sintetizado en código (sin archivos externos): zumbido ambiente,
## alarma y clic de interfaz.

var _hum: AudioStreamPlayer
var _alarm: AudioStreamPlayer
var _click: AudioStreamPlayer
const RATE := 22050


func _ready() -> void:
	_hum = _make_player(_make_hum(), -22.0)
	_hum.stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	_hum.stream.loop_end = int(RATE * 2.0)
	_alarm = _make_player(_make_tone([880.0, 660.0], 0.5, 0.35), -12.0)
	_click = _make_player(_make_tone([1400.0], 0.07, 0.4), -14.0)
	_hum.play()


func play_alarm() -> void:
	if _alarm and not _alarm.playing:
		_alarm.play()


func play_click() -> void:
	if _click:
		_click.play()


func _make_player(stream: AudioStream, volume_db: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.volume_db = volume_db
	add_child(p)
	return p


func _wav(samples: PackedFloat32Array) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i in samples.size():
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	return w


func _make_hum() -> AudioStreamWAV:
	var n: int = int(RATE * 2.0)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t: float = float(i) / RATE
		s[i] = 0.35 * sin(TAU * 60.0 * t) + 0.2 * sin(TAU * 120.0 * t) + 0.08 * sin(TAU * 240.0 * t)
	return _wav(s)


func _make_tone(freqs: Array, length: float, amp: float) -> AudioStreamWAV:
	var n: int = int(RATE * length)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t: float = float(i) / RATE
		var f: float = freqs[int(float(i) / n * freqs.size())]
		var env: float = 1.0 - float(i) / n
		s[i] = sin(TAU * f * t) * amp * env
	return _wav(s)
