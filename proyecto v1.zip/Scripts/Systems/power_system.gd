extends Node
## SISTEMA ENERGÉTICO
## 6 paneles solares + banco de baterías. La generación depende del ciclo
## día/noche lunar, del polvo acumulado y de fallos/tormentas solares.
## La demanda total la suman todos los sistemas (Sim.total_power_demand()).
## Si la batería se agota y la generación no cubre la demanda, `supply_ratio`
## cae por debajo de 1 y TODOS los sistemas reducen su rendimiento.

signal panel_changed(index: int)

const PANEL_COUNT := 6
const PANEL_KW := 4.0         # kW nominales por panel
const ENERGY_SCALE := 0.1     # kWh de batería por (kW · s simulado)
const SHORT_LOAD := 6.0       # kW extra durante un cortocircuito
const DAY_FRACTION := 0.68    # fracción del ciclo con Sol

var capacity: float = 500.0   # kWh
var battery: float = 350.0
var panels: Array = []        # [{online, failed, dust}]
var sun_factor: float = 1.0
var flare_time: float = 0.0
var short_active: bool = false
var generation: float = 0.0   # kW
var consumption: float = 0.0  # kW realmente servidos
var supply_ratio: float = 1.0
var energy_generated: float = 0.0
var energy_consumed: float = 0.0
var energy_wasted: float = 0.0


func reset() -> void:
	panels.clear()
	for i in PANEL_COUNT:
		panels.append({"online": true, "failed": false, "dust": 0.0})
	battery = capacity * 0.7
	sun_factor = sun_at(0.0)
	flare_time = 0.0
	short_active = false
	generation = 0.0
	consumption = 0.0
	supply_ratio = 1.0
	energy_generated = 0.0
	energy_consumed = 0.0
	energy_wasted = 0.0


func percent() -> float:
	return battery / capacity * 100.0


func extra_load() -> float:
	return SHORT_LOAD if short_active else 0.0


func day_phase(t: float) -> float:
	return fmod(t / Sim.config.day_cycle + 0.08, 1.0)


func sun_at(t: float) -> float:
	var ph: float = day_phase(t)
	if ph >= DAY_FRACTION:
		return 0.0
	return clampf(sin(PI * ph / DAY_FRACTION) * 2.5, 0.0, 1.0)


func is_night() -> bool:
	return day_phase(Sim.elapsed) >= DAY_FRACTION


## Segundos hasta el próximo cambio día/noche.
func time_to_change() -> float:
	var ph: float = day_phase(Sim.elapsed)
	var cyc: float = Sim.config.day_cycle
	if ph < DAY_FRACTION:
		return (DAY_FRACTION - ph) * cyc
	return (1.0 - ph) * cyc


func panels_online() -> int:
	var c := 0
	for p in panels:
		if p["online"] and not p["failed"]:
			c += 1
	return c


func failed_count() -> int:
	var c := 0
	for p in panels:
		if p["failed"]:
			c += 1
	return c


func avg_dust() -> float:
	var s := 0.0
	for p in panels:
		s += p["dust"]
	return s / panels.size()


func toggle_panel(i: int) -> void:
	if i < 0 or i >= panels.size() or panels[i]["failed"]:
		return
	panels[i]["online"] = not panels[i]["online"]
	panel_changed.emit(i)


func set_all(on: bool) -> void:
	for i in panels.size():
		if not panels[i]["failed"]:
			panels[i]["online"] = on
			panel_changed.emit(i)


func fail_panel(i: int) -> void:
	panels[i]["failed"] = true
	panels[i]["online"] = false
	panel_changed.emit(i)


func repair_panel(i: int) -> void:
	panels[i]["failed"] = false
	panels[i]["online"] = true
	panel_changed.emit(i)


func clean_dust() -> void:
	for i in panels.size():
		panels[i]["dust"] = 0.0
		panel_changed.emit(i)


func step(dt: float) -> void:
	sun_factor = sun_at(Sim.elapsed)
	var gen := 0.0
	for p in panels:
		p["dust"] = minf(1.0, p["dust"] + 0.0012 * dt)
		if p["online"] and not p["failed"]:
			gen += PANEL_KW * (1.0 - 0.5 * p["dust"])
	gen *= sun_factor
	if flare_time > 0.0:
		gen *= 0.4
		flare_time = maxf(0.0, flare_time - dt)
	generation = gen

	var demand: float = Sim.total_power_demand()
	var net: float = (gen - demand) * ENERGY_SCALE * dt
	supply_ratio = 1.0
	if battery <= 0.0 and net < 0.0:
		supply_ratio = clampf(gen / demand, 0.0, 1.0) if demand > 0.0 else 1.0
		consumption = gen
	else:
		battery += net
		consumption = demand
		if battery > capacity:
			energy_wasted += battery - capacity
			battery = capacity
		elif battery < 0.0:
			battery = 0.0
	energy_generated += gen * ENERGY_SCALE * dt
	energy_consumed += consumption * ENERGY_SCALE * dt
