extends Node
## SISTEMA DE EVENTOS Y MUTADORES ROGUELIKE (NASA EVENT MANAGER)
## Extrae procedimentalmente eventos de crisis desde `nasa_events.json` basados en
## datos históricos y observaciones de DONKI (clima espacial) y Artemis/OSDR.
## También administra las 3 cartas de mejora / mutadores entre ciclos.

signal crisis_deck_drawn(events_list: Array)
signal crisis_resolved(event_id: String, choice_index: int)
signal perk_options_ready(perks_list: Array)
signal perk_applied(perk: Dictionary)

const EVENTS_PATH: String = "res://Resources/nasa_events.json"
const PERKS_PATH: String = "res://Resources/nasa_perks.json"

var events_catalog: Array = []
var perks_catalog: Array = []
var active_crisis_list: Array = []
var active_perks: Array = []


func _ready() -> void:
	load_data()


func load_data() -> void:
	events_catalog = _read_json_array(EVENTS_PATH, "events")
	perks_catalog = _read_json_array(PERKS_PATH, "perks")
	print("EventManager: %d eventos y %d mutadores/perks listos." % [events_catalog.size(), perks_catalog.size()])


func _read_json_array(path: String, key: String) -> Array:
	if not FileAccess.file_exists(path):
		push_warning("EventManager: archivo no encontrado: %s" % path)
		return []
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return []
	var txt := f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if parsed is Dictionary and parsed.has(key):
		return parsed[key]
	return []


## Extrae 1 o 2 eventos de crisis al iniciar cada ciclo
func draw_cycle_crises(count: int = 1) -> Array:
	active_crisis_list.clear()
	if events_catalog.is_empty():
		load_data()
		if events_catalog.is_empty():
			return []
	
	var pool: Array = events_catalog.duplicate(true)
	pool.shuffle()
	
	var draw_n: int = clampi(count, 1, mini(2, pool.size()))
	for i in range(draw_n):
		active_crisis_list.append(pool[i])
		
	crisis_deck_drawn.emit(active_crisis_list)
	return active_crisis_list


## Resuelve una crisis específica mediante la opción elegida por el jugador
func resolve_crisis(event_id: String, choice_index: int) -> Dictionary:
	var target_ev: Dictionary = {}
	var target_idx: int = -1
	
	for i in range(active_crisis_list.size()):
		if active_crisis_list[i].get("id") == event_id:
			target_ev = active_crisis_list[i]
			target_idx = i
			break
			
	if target_ev.is_empty():
		# Si no se encuentra por id, resolver la primera activa
		if not active_crisis_list.is_empty():
			target_ev = active_crisis_list[0]
			target_idx = 0
		else:
			return {}
			
	var options: Array = target_ev.get("options", [])
	if choice_index < 0 or choice_index >= options.size():
		return {}
		
	var chosen_option: Dictionary = options[choice_index]
	var deltas: Dictionary = chosen_option.get("deltas", {})
	
	var de: float = float(deltas.get("energy", 0.0))
	var dox: float = float(deltas.get("oxygen", 0.0))
	var dsh: float = float(deltas.get("radiation_shield", 0.0))
	
	GameManager.apply_resource_deltas(de, dox, dsh)
	GameManager.notify_player(chosen_option.get("feedback", "Decisión ejecutada."), "ok" if de >= 0 or dox >= 0 or dsh >= 0 else "warn")
	
	crisis_resolved.emit(event_id, choice_index)
	active_crisis_list.remove_at(target_idx)
	
	return chosen_option


## Ofrece 3 mejoras aleatorias tipo roguelike con ventajas y desventajas
func get_3_random_perks() -> Array:
	if perks_catalog.is_empty():
		load_data()
	var pool: Array = perks_catalog.duplicate(true)
	pool.shuffle()
	
	var offerings: Array = []
	for i in range(mini(3, pool.size())):
		offerings.append(pool[i])
		
	perk_options_ready.emit(offerings)
	return offerings


## Aplica el mutador elegido permanentemente durante la partida
func apply_chosen_perk(perk: Dictionary) -> void:
	active_perks.append(perk)
	perk_applied.emit(perk)
	GameManager.notify_player("¡Mejora activada: %s!" % perk.get("title", ""), "ok")


## Aplica los efectos pasivos acumulados de todos los mutadores activos al pasar de ciclo
func apply_perks_cycle_effects() -> void:
	var total_de: float = 0.0
	var total_dox: float = 0.0
	var total_dsh: float = 0.0
	
	for p in active_perks:
		var deltas: Dictionary = p.get("deltas_per_cycle", {})
		total_de += float(deltas.get("energy", 0.0))
		total_dox += float(deltas.get("oxygen", 0.0))
		total_dsh += float(deltas.get("radiation_shield", 0.0))
		
	if total_de != 0.0 or total_dox != 0.0 or total_dsh != 0.0:
		GameManager.apply_resource_deltas(total_de, total_dox, total_dsh)
