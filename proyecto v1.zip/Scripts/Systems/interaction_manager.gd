extends Node
## Lógica de las interacciones del jugador (tecla E). Cada objeto interactivo
## del escenario tiene un `interaction_id`; aquí se define qué texto muestra
## (prompt), qué hace (perform) y el color de su luz de estado (status_color).

const OK := Color(0.2, 1.0, 0.5)
const WARN := Color(1.0, 0.8, 0.15)
const BAD := Color(1.0, 0.2, 0.15)
const OFF := Color(0.35, 0.4, 0.45)
const INFO := Color(0.3, 0.75, 1.0)


func prompt(id: String) -> String:
	match id:
		"power_console":
			if Sim.events.is_active("power_short"):
				return "[E] Reparar cortocircuito (1 kit)"
			var f: int = _failed_panel()
			if f >= 0:
				return "[E] Reparar panel solar #%d (1 kit)" % (f + 1)
			if Sim.power.panels_online() == 0:
				return "[E] Encender paneles solares"
			var all_on := true
			for p in Sim.power.panels:
				if not p["online"]:
					all_on = false
			return "[E] Apagar paneles solares" if all_on else "[E] Encender paneles solares"
		"o2_tank":
			if Sim.oxygen.leak_active:
				return "[E] Sellar fuga de oxígeno (1 kit)"
			return "[E] Revisar reserva de oxígeno"
		"o2_valve":
			var nxt: int = (Sim.oxygen.valve_mode + 1) % 4
			return "[E] Distribución de O₂: %s → %s" % [Sim.oxygen.MODE_NAMES[Sim.oxygen.valve_mode], Sim.oxygen.MODE_NAMES[nxt]]
		"o2_generator":
			return "[E] %s generador de oxígeno" % ("Apagar" if Sim.oxygen.generator_on else "Activar")
		"water_recycler":
			return "[E] %s reciclaje de agua" % ("Desactivar" if Sim.water.recycler_on else "Activar")
		"water_filter":
			if Sim.water.filter < 0.95:
				return "[E] Mantenimiento del filtro (1 kit)"
			return "[E] Revisar filtro de agua"
		"water_tank":
			if Sim.water.leak_active:
				return "[E] Sellar fuga del tanque (1 kit)"
			return "[E] Revisar reserva de agua"
		"greenhouse":
			if Sim.food.blight_count() > 0:
				return "[E] Tratar plaga del invernadero"
			if Sim.food.ripe_count() > 0:
				return "[E] Cosechar cultivos maduros"
			if Sim.food.empty_count() > 0:
				return "[E] Sembrar bandejas vacías"
			if Sim.food.nutrients < 30.0:
				return "[E] Preparar solución nutritiva (5 agua)"
			return "[E] Revisar invernadero"
		"lab_terminal":
			return "[E] Consultar estadísticas de la misión"
		"central_console":
			var gm = get_node_or_null("/root/GameManager")
			if gm and gm.is_transmitting_to_earth:
				return "[Antena DSN transmitiendo a Houston...]"
			return "[E] Enlace DSN con Houston (-15 Energía, latencia 1.3s)"
		"toolbox":
			return "[E] Mantenimiento general de equipos (1 kit)"
	return "[E] Interactuar"


func status_color(id: String) -> Color:
	match id:
		"power_console":
			if Sim.events.is_active("power_short") or Sim.power.failed_count() > 0:
				return BAD
			if Sim.power.percent() < 25.0:
				return WARN
			return OK if Sim.power.panels_online() > 0 else OFF
		"o2_tank":
			if Sim.oxygen.leak_active or Sim.oxygen.reserve_percent() < 10.0:
				return BAD
			return WARN if Sim.oxygen.reserve_percent() < 25.0 else OK
		"o2_valve":
			return OFF if Sim.oxygen.valve_mode == 0 else (WARN if Sim.oxygen.cabin < 40.0 else OK)
		"o2_generator":
			if not Sim.oxygen.generator_on:
				return OFF
			return WARN if Sim.oxygen.generator_wear > 0.6 else OK
		"water_recycler":
			if not Sim.water.recycler_on:
				return OFF
			return WARN if Sim.water.filter < 0.4 else OK
		"water_filter":
			return BAD if Sim.events.is_active("filter_clog") else (WARN if Sim.water.filter < 0.4 else OK)
		"water_tank":
			if Sim.water.leak_active or Sim.water.percent() < 10.0:
				return BAD
			return WARN if Sim.water.percent() < 25.0 else OK
		"greenhouse":
			if Sim.food.blight_count() > 0:
				return BAD
			if Sim.food.ripe_count() > 0:
				return INFO
			return WARN if Sim.food.stalled_reason != "" else OK
		"lab_terminal", "central_console":
			if Sim.station_status == "CRÍTICO":
				return BAD
			return WARN if Sim.station_status == "ADVERTENCIA" else OK
		"toolbox":
			return OK if Sim.repair_kits > 0 else BAD
	return INFO


## Ejecuta la acción. Devuelve true si tuvo efecto.
func perform(id: String) -> bool:
	if Sim.mission_over:
		return false
	var ok := true
	match id:
		"power_console":
			ok = _power_console()
		"o2_tank":
			if Sim.oxygen.leak_active:
				if Sim.use_kit():
					Sim.events.resolve("o2_leak")
				else:
					ok = false
			else:
				Sim.notify("Reserva de O₂: %d%% | Cabina: %d%% | Generador: %s (eficiencia %d%%)" % [
					int(Sim.oxygen.reserve_percent()), int(Sim.oxygen.cabin),
					"ON" if Sim.oxygen.generator_on else "OFF", int(Sim.oxygen.efficiency() * 100.0)], "info")
		"o2_valve":
			Sim.oxygen.cycle_valve()
			Sim.notify("Distribución de O₂: %s (%d kW de soporte vital)" % [
				Sim.oxygen.MODE_NAMES[Sim.oxygen.valve_mode], int(Sim.oxygen.LIFE_SUPPORT_POWER) if Sim.oxygen.valve_mode > 0 else 0], "info")
		"o2_generator":
			Sim.oxygen.toggle_generator()
			Sim.notify("Generador de oxígeno %s" % ("ACTIVADO" if Sim.oxygen.generator_on else "APAGADO"),
				"ok" if Sim.oxygen.generator_on else "warn")
		"water_recycler":
			Sim.water.toggle_recycler()
			Sim.notify("Reciclaje de agua %s" % ("ACTIVADO" if Sim.water.recycler_on else "DESACTIVADO"),
				"ok" if Sim.water.recycler_on else "warn")
		"water_filter":
			if Sim.water.filter < 0.95:
				if Sim.use_kit():
					if Sim.events.is_active("filter_clog"):
						Sim.events.resolve("filter_clog")
					else:
						Sim.water.maintain_filter()
						Sim.notify("Filtro reemplazado: eficacia 100 %.", "ok")
				else:
					ok = false
			else:
				Sim.notify("Filtro al %d%% de eficacia. Sin necesidad de mantenimiento." % int(Sim.water.filter * 100.0), "info")
		"water_tank":
			if Sim.water.leak_active:
				if Sim.use_kit():
					Sim.events.resolve("water_leak")
				else:
					ok = false
			else:
				Sim.notify("Agua: %d%% | Recuperada: %.1f u | Reciclador: %s" % [
					int(Sim.water.percent()), Sim.water.recycled_total, "ON" if Sim.water.recycler_on else "OFF"], "info")
		"greenhouse":
			_greenhouse()
		"lab_terminal":
			Sim.dashboard_requested.emit("Estadísticas")
		"central_console":
			var gm = get_node_or_null("/root/GameManager")
			if gm:
				gm.request_houston_support()
			else:
				Sim.dashboard_requested.emit("Energía")
		"toolbox":
			ok = _maintenance()
	if ok and Sim.audio:
		Sim.audio.play_click()
	return ok


func _failed_panel() -> int:
	for i in Sim.power.panels.size():
		if Sim.power.panels[i]["failed"]:
			return i
	return -1


func _power_console() -> bool:
	if Sim.events.is_active("power_short"):
		if Sim.use_kit():
			Sim.events.resolve("power_short")
			return true
		return false
	var f: int = _failed_panel()
	if f >= 0:
		if Sim.use_kit():
			Sim.events.resolve("panel_%d" % f)
			return true
		return false
	var all_on := true
	for p in Sim.power.panels:
		if not p["online"]:
			all_on = false
	Sim.power.set_all(not all_on)
	Sim.notify("Paneles solares %s | Generación: %.1f kW | Batería: %d%%" % [
		"ACTIVADOS" if not all_on else "DESACTIVADOS", Sim.power.generation,
		int(Sim.power.percent())], "ok" if not all_on else "warn")
	return true


func _greenhouse() -> void:
	var f = Sim.food
	if f.blight_count() > 0:
		if Sim.water.reserve >= 3.0:
			Sim.water.draw(3.0)
			Sim.events.resolve("crop_blight")
		else:
			Sim.notify("Se necesitan 3 u de agua para el tratamiento.", "bad")
		return
	if f.ripe_count() > 0:
		var got: float = f.harvest_all()
		Sim.notify("Cosecha completada: +%.0f u de alimentos (almacén %d%%)" % [got, int(f.percent())], "ok")
		return
	if f.empty_count() > 0:
		var n: int = f.plant_all()
		Sim.notify("Sembradas %d bandejas." % n, "ok")
		return
	if f.nutrients < 30.0:
		if f.mix_nutrients():
			Sim.notify("Solución nutritiva renovada (nutrientes %d%%)." % int(f.nutrients), "ok")
		else:
			Sim.notify("Agua insuficiente para preparar nutrientes.", "bad")
		return
	Sim.notify("Invernadero: %d en crecimiento, nutrientes %d%%, almacén %d%%." % [
		f.growing_count(), int(f.nutrients), int(f.percent())], "info")


func _maintenance() -> bool:
	var target := ""
	if Sim.oxygen.generator_wear > 0.3:
		target = "gen"
	elif Sim.power.avg_dust() > 0.3:
		target = "dust"
	elif Sim.water.filter < 0.6:
		target = "filter"
	if target == "":
		Sim.notify("Todos los equipos están en buen estado. No se consumió ningún kit.", "info")
		return true
	if not Sim.use_kit():
		return false
	match target:
		"gen":
			Sim.oxygen.maintain_generator()
			Sim.notify("Mantenimiento: generador de O₂ restaurado.", "ok")
		"dust":
			Sim.power.clean_dust()
			Sim.notify("Mantenimiento: polvo lunar retirado de los paneles.", "ok")
		"filter":
			Sim.water.maintain_filter()
			Sim.notify("Mantenimiento: filtro de agua reemplazado.", "ok")
	return true
