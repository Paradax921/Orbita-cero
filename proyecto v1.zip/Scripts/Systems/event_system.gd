extends Node
## SISTEMA DE EVENTOS Y PROBLEMAS
## Genera incidentes aleatorios que modifican los demás sistemas. Cada evento
## crea una alerta y se resuelve con una acción del usuario (la mayoría
## consume un kit de reparación) o, en el caso de la tormenta solar, al pasar.

const TYPES := ["solar_flare", "power_short", "panel_failure", "o2_leak",
	"water_leak", "filter_clog", "crop_blight"]

var active: Dictionary = {}     # clave -> {text, severity, started, type}
var timer: float = 40.0
var rng := RandomNumberGenerator.new()
var total_incidents: int = 0
var resolved_incidents: int = 0
var resolution_times: Array = []


func reset() -> void:
	active.clear()
	total_incidents = 0
	resolved_incidents = 0
	resolution_times.clear()
	rng.randomize()
	timer = Sim.config.first_event_delay


func is_active(key: String) -> bool:
	return active.has(key)


func first_with_prefix(prefix: String) -> String:
	for k in active:
		if k.begins_with(prefix):
			return k
	return ""


func step(dt: float) -> void:
	# La tormenta solar se resuelve sola cuando termina.
	if active.has("solar_flare") and Sim.power.flare_time <= 0.0:
		resolve("solar_flare", true)
	timer -= dt
	if timer <= 0.0:
		timer = rng.randf_range(Sim.config.event_interval_min, Sim.config.event_interval_max) \
			/ maxf(0.1, Sim.config.difficulty)
		if active.size() < Sim.config.max_active_events:
			trigger_random()


func trigger_random() -> bool:
	var pool: Array = TYPES.duplicate()
	pool.shuffle()
	for t in pool:
		if trigger(t):
			return true
	return false


## Dispara un evento concreto. Devuelve false si no es aplicable ahora mismo.
func trigger(type: String) -> bool:
	match type:
		"solar_flare":
			if active.has("solar_flare") or Sim.power.is_night():
				return false
			Sim.power.flare_time = 45.0
			_open("solar_flare", type, "TORMENTA SOLAR: generación reducida", 1,
				"Tormenta solar: la generación cae. Reduzca consumos no esenciales.")
		"power_short":
			if active.has("power_short"):
				return false
			Sim.power.short_active = true
			_open("power_short", type, "CORTOCIRCUITO: fuga de energía (+6 kW)", 2,
				"Cortocircuito en el bus principal. Repárelo en el panel de energía.")
		"panel_failure":
			var candidates: Array = []
			for i in Sim.power.panels.size():
				if not Sim.power.panels[i]["failed"]:
					candidates.append(i)
			if candidates.size() <= Sim.power.panels.size() - 2:
				return false  # ya hay 2 paneles averiados
			var idx: int = candidates[rng.randi() % candidates.size()]
			Sim.power.fail_panel(idx)
			_open("panel_%d" % idx, type, "FALLA DEL PANEL SOLAR #%d" % (idx + 1), 2,
				"El panel solar #%d ha fallado. Repárelo en el panel de energía." % (idx + 1))
		"o2_leak":
			if active.has("o2_leak"):
				return false
			Sim.oxygen.leak_active = true
			_open("o2_leak", type, "FUGA DE OXÍGENO EN LOS TANQUES", 2,
				"Fuga de oxígeno detectada. Selle los tanques de O₂.")
		"water_leak":
			if active.has("water_leak"):
				return false
			Sim.water.leak_active = true
			_open("water_leak", type, "FUGA EN EL TANQUE DE AGUA", 2,
				"Fuga en el tanque de agua. Selle el depósito.")
		"filter_clog":
			if active.has("filter_clog"):
				return false
			Sim.water.filter = 0.12
			_open("filter_clog", type, "FILTRO OBSTRUIDO: reciclaje reducido", 1,
				"El filtro del reciclador está obstruido. Realice su mantenimiento.")
		"crop_blight":
			if active.has("crop_blight"):
				return false
			var ok: Array = []
			for i in Sim.food.plots.size():
				var p: Dictionary = Sim.food.plots[i]
				if p["stage"] >= 1 and p["stage"] <= 3:
					ok.append(i)
			if ok.is_empty():
				return false
			ok.shuffle()
			for j in mini(2, ok.size()):
				Sim.food.plots[ok[j]]["blight"] = true
			_open("crop_blight", type, "PLAGA: crecimiento interrumpido", 1,
				"Plaga en el invernadero. Trate los cultivos afectados.")
		_:
			return false
	return true


func _open(key: String, type: String, text: String, severity: int, message: String) -> void:
	active[key] = {"text": text, "severity": severity, "started": Sim.elapsed, "type": type}
	total_incidents += 1
	Sim.set_alert("ev_" + key, text, severity)
	Sim.notify(message, "bad" if severity >= 2 else "warn")


## Marca un evento como resuelto y revierte su efecto sobre los sistemas.
func resolve(key: String, silent: bool = false) -> void:
	if not active.has(key):
		return
	var ev: Dictionary = active[key]
	match ev["type"]:
		"solar_flare":
			Sim.power.flare_time = 0.0
		"power_short":
			Sim.power.short_active = false
		"panel_failure":
			Sim.power.repair_panel(int(key.substr(6)))
		"o2_leak":
			Sim.oxygen.leak_active = false
		"water_leak":
			Sim.water.leak_active = false
		"filter_clog":
			Sim.water.maintain_filter()
		"crop_blight":
			Sim.food.treat_blight()
	resolved_incidents += 1
	resolution_times.append(Sim.elapsed - ev["started"])
	active.erase(key)
	Sim.clear_alert("ev_" + key)
	if not silent:
		Sim.notify("Incidente resuelto: " + ev["text"], "ok")


func avg_resolution_time() -> float:
	if resolution_times.is_empty():
		return 0.0
	var s := 0.0
	for t in resolution_times:
		s += t
	return s / resolution_times.size()
