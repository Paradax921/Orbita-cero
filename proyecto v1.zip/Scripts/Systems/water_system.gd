extends Node
## SISTEMA DE AGUA
## Reserva + consumo de la tripulación + consumo del invernadero y de la
## electrólisis. El reciclador recupera agua si hay energía; su eficacia
## depende del estado del filtro, que se degrada y se mantiene con kits.

const CAP := 100.0
const CREW_USE := 0.025        # u/s por tripulante
const RECYCLE_RATE := 0.18     # u/s a filtro 100 % y energía completa
const RECYCLER_POWER := 2.5    # kW
const FILTER_DECAY := 0.0015   # fracción/s
const LEAK_RATE := 0.25

var reserve: float = 90.0
var recycler_on: bool = true
var filter: float = 1.0        # 0..1
var leak_active: bool = false
var consumed_total: float = 0.0
var recycled_total: float = 0.0
var last_recycle: float = 0.0  # u/s


func reset() -> void:
	reserve = 90.0
	recycler_on = true
	filter = 1.0
	leak_active = false
	consumed_total = 0.0
	recycled_total = 0.0
	last_recycle = 0.0


func percent() -> float:
	return reserve / CAP * 100.0


func power_demand() -> float:
	return RECYCLER_POWER if recycler_on else 0.0


func toggle_recycler() -> void:
	recycler_on = not recycler_on


func maintain_filter() -> void:
	filter = 1.0


## Extrae agua de la reserva; devuelve lo que realmente se pudo extraer.
func draw(amount: float) -> float:
	var got: float = minf(amount, reserve)
	reserve -= got
	consumed_total += got
	return got


func add(amount: float) -> void:
	reserve = minf(CAP, reserve + amount)


func step(dt: float) -> void:
	var r: float = Sim.power.supply_ratio
	draw(Sim.config.crew_size * CREW_USE * dt)
	last_recycle = 0.0
	if recycler_on and r > 0.0:
		var rec: float = RECYCLE_RATE * filter * r
		last_recycle = rec
		add(rec * dt)
		recycled_total += rec * dt
		filter = maxf(0.0, filter - FILTER_DECAY * dt)
	if leak_active:
		reserve = maxf(0.0, reserve - LEAK_RATE * dt)
