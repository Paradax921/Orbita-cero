extends Node
## SISTEMA DE OXÍGENO
## Reserva (tanques) -> válvula de distribución -> atmósfera de cabina.
## El generador (electrólisis) consume agua y energía y se desgasta.
## La tripulación consume O₂ de la cabina de forma continua.

const RESERVE_CAP := 100.0
const GEN_RATE := 0.35        # u/s a plena eficiencia
const GEN_WATER := 0.04       # agua consumida por la electrólisis (u/s)
const GEN_POWER := 3.0        # kW
const LIFE_SUPPORT_POWER := 1.5  # kW (ventiladores, depuradores CO₂) si hay flujo
const CREW_USE := 0.0625      # % de cabina por tripulante y segundo
const LEAK_RATE := 0.25       # u/s
const FLOWS := [0.0, 0.15, 0.3, 0.6]
const MODE_NAMES := ["CERRADA", "BAJA", "NORMAL", "ALTA"]

var reserve: float = 80.0
var cabin: float = 100.0
var generator_on: bool = true
var generator_wear: float = 0.0
var valve_mode: int = 2
var leak_active: bool = false
var produced_total: float = 0.0
var consumed_total: float = 0.0
var last_production: float = 0.0   # u/s (para HUD)


func reset() -> void:
	reserve = 80.0
	cabin = 100.0
	generator_on = true
	generator_wear = 0.0
	valve_mode = 2
	leak_active = false
	produced_total = 0.0
	consumed_total = 0.0
	last_production = 0.0


func reserve_percent() -> float:
	return reserve / RESERVE_CAP * 100.0


func efficiency() -> float:
	return 1.0 - 0.75 * generator_wear


func power_demand() -> float:
	var p := 0.0
	if generator_on:
		p += GEN_POWER
	if valve_mode > 0:
		p += LIFE_SUPPORT_POWER
	return p


func toggle_generator() -> void:
	generator_on = not generator_on


func cycle_valve() -> void:
	valve_mode = (valve_mode + 1) % FLOWS.size()


func set_valve(mode: int) -> void:
	valve_mode = clampi(mode, 0, FLOWS.size() - 1)


func maintain_generator() -> void:
	generator_wear = 0.0


func step(dt: float) -> void:
	var r: float = Sim.power.supply_ratio
	var produced := 0.0
	if generator_on and r > 0.0 and Sim.water.reserve > 0.0:
		produced = GEN_RATE * efficiency() * r * dt
		Sim.water.draw(GEN_WATER * r * dt)
		generator_wear = minf(1.0, generator_wear + 0.0025 * dt)
	last_production = produced / dt if dt > 0.0 else 0.0
	reserve += produced
	produced_total += produced
	if leak_active:
		reserve -= LEAK_RATE * dt
	reserve = clampf(reserve, 0.0, RESERVE_CAP)

	var flow: float = FLOWS[valve_mode] * r * dt
	flow = minf(flow, minf(reserve, 100.0 - cabin))
	flow = maxf(flow, 0.0)
	reserve -= flow
	cabin += flow
	var use: float = Sim.config.crew_size * CREW_USE * dt
	cabin = maxf(0.0, cabin - use)
	consumed_total += use
