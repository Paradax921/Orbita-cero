extends Node
## SISTEMA DE EVALUACIÓN
## Muestrea la estación cada tick y calcula métricas de rendimiento y el
## informe final de misión.

var samples: float = 0.0
var stability_sum: float = 0.0
var availability_sum: float = 0.0
var uptime_ok: float = 0.0
var total_time: float = 0.0
var min_stability: float = 100.0


func reset() -> void:
	samples = 0.0
	stability_sum = 0.0
	availability_sum = 0.0
	uptime_ok = 0.0
	total_time = 0.0
	min_stability = 100.0


## Disponibilidad media de recursos (0-100).
func availability() -> float:
	return (Sim.power.percent() + Sim.oxygen.cabin + Sim.water.percent() + Sim.food.percent()) / 4.0


## Estabilidad instantánea (0-100).
func stability() -> float:
	var vals := [Sim.power.percent(), Sim.oxygen.cabin, Sim.water.percent(), Sim.food.percent()]
	var mn: float = vals.min()
	var base: float = availability() * 0.6 + mn * 0.4
	base -= Sim.events.active.size() * 6.0
	base *= Sim.crew_health / 100.0
	return clampf(base, 0.0, 100.0)


func energy_efficiency() -> float:
	var used: float = Sim.power.energy_consumed
	var waste: float = Sim.power.energy_wasted
	if used + waste <= 0.0:
		return 100.0
	return used / (used + waste) * 100.0


func food_production_level() -> float:
	var need: float = Sim.food.consumed_total
	if need <= 0.01:
		return 100.0
	return clampf(Sim.food.harvested_total / need * 100.0, 0.0, 100.0)


func uptime_percent() -> float:
	return 100.0 if total_time <= 0.0 else uptime_ok / total_time * 100.0


func avg_stability() -> float:
	return stability() if samples <= 0.0 else stability_sum / samples


func avg_availability() -> float:
	return availability() if samples <= 0.0 else availability_sum / samples


func step(dt: float) -> void:
	var s: float = stability()
	samples += 1.0
	stability_sum += s
	availability_sum += availability()
	min_stability = minf(min_stability, s)
	total_time += dt
	if Sim.critical_count() == 0:
		uptime_ok += dt


func build_report(reason: String, success: bool) -> Dictionary:
	var dur_frac: float = clampf(Sim.elapsed / Sim.config.mission_duration, 0.0, 1.0)
	var unresolved: int = Sim.events.active.size()
	var food_score: float = food_production_level()
	var score: float = 0.35 * avg_stability() + 0.20 * avg_availability() \
		+ 0.15 * uptime_percent() + 0.15 * energy_efficiency() + 0.15 * food_score
	score -= 5.0 * unresolved
	score *= dur_frac
	if not success:
		score = minf(score, 39.0)
	score = clampf(score, 0.0, 100.0)
	var grade := "F"
	if score >= 85.0: grade = "A"
	elif score >= 70.0: grade = "B"
	elif score >= 55.0: grade = "C"
	elif score >= 40.0: grade = "D"
	return {
		"reason": reason,
		"success": success,
		"duration": Sim.elapsed,
		"clock": Sim.format_clock(Sim.elapsed),
		"stability_avg": avg_stability(),
		"stability_min": min_stability,
		"availability": avg_availability(),
		"uptime": uptime_percent(),
		"incidents": Sim.events.total_incidents,
		"resolved": Sim.events.resolved_incidents,
		"unresolved": unresolved,
		"avg_resolution": Sim.events.avg_resolution_time(),
		"energy_eff": energy_efficiency(),
		"energy_generated": Sim.power.energy_generated,
		"energy_consumed": Sim.power.energy_consumed,
		"food_harvested": Sim.food.harvested_total,
		"food_consumed": Sim.food.consumed_total,
		"food_level": food_score,
		"water_recycled": Sim.water.recycled_total,
		"o2_produced": Sim.oxygen.produced_total,
		"crew_health": Sim.crew_health,
		"kits_left": Sim.repair_kits,
		"final_energy": Sim.power.percent(),
		"final_o2": Sim.oxygen.cabin,
		"final_water": Sim.water.percent(),
		"final_food": Sim.food.percent(),
		"score": score,
		"grade": grade,
	}
