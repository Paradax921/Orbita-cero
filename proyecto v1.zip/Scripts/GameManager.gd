extends Node
## AUTOLOAD "GameManager" — SPACE CONTI (Junior Astronaut Mission Trainer)
## Gestor principal de supervivencia espacial y mecánicas roguelike para niños (7-12 años).
## Basado en datos reales de la NASA (DONKI, OSDR y Programa Artemis).

signal resources_changed(energy: float, oxygen: float, food: float, radiation_shield: float)
signal debuff_changed(debuff_name: String, active: bool)
signal day_cycle_advanced(new_cycle: int)
signal player_died(reason: String, educational_explanation: String)
signal game_restarted
signal notification(text: String, kind: String)
signal notification_sent(message: String, color: Color)
signal module_repaired(module_name: String)
signal perk_selection_requested(perks: Array)
signal crisis_triggered(crisis_dict: Dictionary)
signal houston_transmission_started(duration: float)
signal houston_transmission_completed()
signal badge_unlocked(badge_id: String, badge_name: String)

const MAX_RESOURCE: float = 100.0
const MIN_RESOURCE: float = 0.0
const CYCLE_DURATION: float = 75.0 # Duración en segundos de un Sol/Día de misión

# Tasas de consumo pasivo por segundo
const DRAIN_ENERGY_BASE: float = 0.35
const DRAIN_OXYGEN_BASE: float = 0.45
const DRAIN_FOOD_BASE: float = 0.30
const DRAIN_SHIELD_BASE: float = 0.25

# 4 Recursos principales
var energy: float = 100.0:
	set(val):
		energy = clampf(val, MIN_RESOURCE, MAX_RESOURCE)
		_emit_resources()

var oxygen: float = 100.0:
	set(val):
		oxygen = clampf(val, MIN_RESOURCE, MAX_RESOURCE)
		_emit_resources()

var food: float = 100.0:
	set(val):
		food = clampf(val, MIN_RESOURCE, MAX_RESOURCE)
		_emit_resources()

var radiation_shield: float = 100.0:
	set(val):
		radiation_shield = clampf(val, MIN_RESOURCE, MAX_RESOURCE)
		_emit_resources()

var day_cycle: int = 1
var cycle: int:
	get:
		return day_cycle
	set(val):
		day_cycle = val

var cycle_timer: float = 0.0
var is_game_active: bool = false
var is_dead: bool = false

# Asignación de baterías en 3D
var battery_allocations: Dictionary = {
	"greenhouse": 1,
	"shield": 1,
	"antenna": 1
}
var is_transmitting_to_earth: bool = false
var waiting_for_perk_selection: bool = false
var event_manager: Node = null

# Estados físicos de desventaja (< 25% o < 30%)
var is_starving: bool = false
var is_suffocating: bool = false
var is_irradiated: bool = false

# Control de micro-desmayos por asfixia
var blackout_timer: float = 0.0
var in_micro_blackout: bool = false
const BLACKOUT_INTERVAL: float = 14.0
const BLACKOUT_DURATION: float = 2.5

# Asignación de módulos y nodos de la base
var active_crisis: Dictionary = {}
var unlocked_badges: Dictionary = {}
var crisis_triggered_this_cycle: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS


func unlock_badge(badge_id: String, title: String, desc: String, icon: String = "🏅") -> void:
	if not unlocked_badges.has(badge_id):
		unlocked_badges[badge_id] = {
			"id": badge_id,
			"title": title,
			"desc": desc,
			"icon": icon
		}
		badge_unlocked.emit(badge_id, title)
		notify_player("¡Nuevo Parche de Misión Desbloqueado: %s %s!" % [icon, title], Color(1.0, 0.85, 0.2))


func start_game() -> void:
	is_dead = false
	is_game_active = true
	day_cycle = 1
	cycle_timer = 0.0
	crisis_triggered_this_cycle = false
	energy = 100.0
	oxygen = 100.0
	food = 100.0
	radiation_shield = 100.0
	is_starving = false
	is_suffocating = false
	is_irradiated = false
	in_micro_blackout = false
	blackout_timer = 0.0
	game_restarted.emit()
	unlock_badge("artemis_cadet", "Cadete Lunar", "Iniciaste la simulación espacial en Base Lunar 01.", "🚀")
	notify_player("¡Misión SPACE CONTI iniciada! Gestiona la base lunar como un astronauta.", Color(0.4, 0.9, 1.0))


func _process(delta: float) -> void:
	if not is_game_active or is_dead:
		return
	
	_update_passive_drain(delta)
	_update_physical_debuffs(delta)
	_update_day_cycle(delta)
	_check_death_conditions()


func _update_passive_drain(delta: float) -> void:
	var d_energy: float = DRAIN_ENERGY_BASE * delta
	var d_oxygen: float = DRAIN_OXYGEN_BASE * delta
	var d_food: float = DRAIN_FOOD_BASE * delta
	var d_shield: float = DRAIN_SHIELD_BASE * delta
	
	# Desventaja de radiación: el consumo de oxígeno se duplica
	if is_irradiated:
		d_oxygen *= 2.0
		
	# Si las baterías están a 0, la estación sufre fallos térmicos (pierde oxígeno y comida más rápido)
	if energy <= 0.0:
		d_oxygen *= 1.5
		d_shield *= 1.5
		
	self.energy -= d_energy
	self.oxygen -= d_oxygen
	self.food -= d_food
	self.radiation_shield -= d_shield


func _update_physical_debuffs(delta: float) -> void:
	# 1. Inanición (food < 25)
	var new_starving: bool = food < 25.0
	if new_starving != is_starving:
		is_starving = new_starving
		debuff_changed.emit("is_starving", is_starving)
		if is_starving:
			_notify("¡ALERTA DE HAMBRE! La tripulación está débil. Velocidad reducida al 55% y sin sprint.", "warn")
		else:
			_notify("Nutrición restablecida. Fuerza física nominal.", "ok")
			
	# 2. Asfixia (oxygen < 30)
	var new_suffocating: bool = oxygen < 30.0
	if new_suffocating != is_suffocating:
		is_suffocating = new_suffocating
		debuff_changed.emit("is_suffocating", is_suffocating)
		if is_suffocating:
			_notify("¡PELIGRO DE ASFIXIA! Falta de O₂ en cabina. Visión inestable y riesgo de desmayo.", "bad")
		else:
			in_micro_blackout = false
			_notify("Presión de oxígeno normalizada.", "ok")
			
	if is_suffocating and not in_micro_blackout:
		blackout_timer += delta
		if blackout_timer >= BLACKOUT_INTERVAL:
			blackout_timer = 0.0
			_trigger_micro_blackout()
			
	# 3. Irradiación (radiation_shield < 25)
	var new_irradiated: bool = radiation_shield < 25.0
	if new_irradiated != is_irradiated:
		is_irradiated = new_irradiated
		debuff_changed.emit("is_irradiated", is_irradiated)
		if is_irradiated:
			_notify("¡ALERTA DE RADIACIÓN CÓSMICA (DONKI/OSDR)! Desgaste celular: consumo de O₂ duplicado.", "bad")
		else:
			_notify("Blindaje deflector restablecido.", "ok")


func _trigger_micro_blackout() -> void:
	in_micro_blackout = true
	_notify("¡Micro-desmayo por hipoxia! El astronauta se desploma temporalmente...", "bad")
	await get_tree().create_timer(BLACKOUT_DURATION).timeout
	in_micro_blackout = false


func _update_day_cycle(delta: float) -> void:
	cycle_timer += delta
	
	# A mitad de ciclo (~35 segundos), si estamos en Sol >= 2, disparar evento de crisis DONKI/OSDR
	if cycle_timer >= (CYCLE_DURATION * 0.45) and not crisis_triggered_this_cycle and day_cycle >= 2:
		crisis_triggered_this_cycle = true
		var em = get_node_or_null("/root/EventManager")
		if em and em.has_method("draw_cycle_crises"):
			var crises: Array = em.draw_cycle_crises(1)
			if not crises.is_empty():
				crisis_triggered.emit(crises[0])
				
	if cycle_timer >= CYCLE_DURATION:
		cycle_timer = 0.0
		advance_cycle()


func _check_death_conditions() -> void:
	if is_dead:
		return
		
	if oxygen <= 0.0:
		_die(
			"Asfixia Crítica por Falta de Oxígeno",
			"La atmósfera de la base se quedó sin O₂ respirable. En el espacio, la NASA utiliza sistemas regenerativos como OGA (Oxygen Generation Assembly) que descomponen agua en oxígeno e hidrógeno mediante electrólisis para que nunca se agote el aire."
		)
	elif food <= 0.0:
		_die(
			"Inanición de la Tripulación",
			"Se agotaron los suministros alimenticios y los cultivos del hábitat. Para misiones de larga duración, la NASA investiga en el repositorio OSDR el proyecto VEGGIE, cultivando lechuga espacial y microalgas ricas en nutrientes y proteínas."
		)
	elif radiation_shield <= 0.0:
		_die(
			"Colapso de Blindaje por Radiación Cósmica",
			"El campo deflector y las paredes de regolito colapsaron bajo los protones solares registrados por DONKI. Sin blindaje, la radiación ionizante daña los sistemas electrónicos y el ADN celular humano."
		)


func _die(reason: String, educational_explanation: String) -> void:
	is_dead = true
	is_game_active = false
	player_died.emit(reason, educational_explanation)
	_notify("MISIÓN FALLIDA: %s" % reason, "bad")


func _trigger_victory() -> void:
	is_dead = true
	is_game_active = false
	player_died.emit(
		"¡Misión Artemis Superada con Éxito!",
		"¡Felicidades, Astronauta! Has demostrado comprender el balance crítico de soporte vital, radiación solar DONKI y fotosíntesis OSDR como un auténtico planificador de vuelo de la NASA."
	)


func apply_tradeoff(d_energy: float, d_oxygen: float, d_food: float, d_shield: float) -> void:
	if is_dead:
		return
	self.energy += d_energy
	self.oxygen += d_oxygen
	self.food += d_food
	self.radiation_shield += d_shield
	_check_death_conditions()


func apply_resource_deltas(d_energy: float, d_oxygen: float, d_shield: float, d_food: float = 0.0) -> void:
	apply_tradeoff(d_energy, d_oxygen, d_food, d_shield)


func _emit_resources() -> void:
	resources_changed.emit(energy, oxygen, food, radiation_shield)
	_sync_with_sim()


func _sync_with_sim() -> void:
	var sim_node: Node = get_node_or_null("/root/Sim")
	if sim_node and sim_node.get("power") and sim_node.get("oxygen"):
		if "battery" in sim_node.power and "capacity" in sim_node.power:
			sim_node.power.battery = (energy / 100.0) * sim_node.power.capacity
		if "reserve" in sim_node.oxygen and "RESERVE_CAP" in sim_node.oxygen:
			sim_node.oxygen.reserve = (oxygen / 100.0) * sim_node.oxygen.RESERVE_CAP
			sim_node.oxygen.cabin = oxygen


func cycle_battery_to_node(node_name: String) -> void:
	if not battery_allocations.has(node_name):
		return
	var other_nodes: Array = []
	for k in battery_allocations.keys():
		if k != node_name:
			other_nodes.append(k)
	var donor: String = other_nodes[0]
	if battery_allocations[other_nodes[1]] > battery_allocations[donor]:
		donor = other_nodes[1]
	if battery_allocations[donor] > 0:
		battery_allocations[donor] -= 1
		battery_allocations[node_name] += 1
		_notify("Batería transferida a %s (Total: %d)" % [node_name, battery_allocations[node_name]], "ok")


func request_houston_support() -> void:
	if is_transmitting_to_earth or is_dead:
		return
	if energy < 15.0:
		notify_player("¡Energía insuficiente para antena DSN (Requieres 15 Energía)!", Color(1.0, 0.3, 0.3))
		return
	is_transmitting_to_earth = true
	self.energy -= 15.0
	notify_player("📡 Transmitiendo a Houston vía Red del Espacio Profundo (Latencia 1.3 s)...", Color(0.3, 0.8, 1.0))
	houston_transmission_started.emit(1.3)
	await get_tree().create_timer(1.3).timeout
	is_transmitting_to_earth = false
	self.oxygen += 20.0
	self.radiation_shield += 20.0
	unlock_badge("deep_space_network", "Operador de Radio DSN", "Estableciste enlace de telemetría a 384,400 km.", "📡")
	houston_transmission_completed.emit()
	notify_player("🛰️ ¡Telemetría de la Tierra recibida! (+20 Oxígeno, +20 Escudo)", Color.GREEN)


func advance_cycle() -> void:
	if is_dead:
		return
	day_cycle += 1
	cycle_timer = 0.0
	crisis_triggered_this_cycle = false
	
	if day_cycle >= 3:
		unlock_badge("artemis_survivor", "Pionero Artemis", "Sobreviviste 3 soles en la superficie lunar.", "🌙")
	if day_cycle >= 7:
		unlock_badge("lunar_veteran", "Veterano de Base Lunar", "Mantuviste la base con vida 7 soles.", "⭐")
	if day_cycle > 14:
		unlock_badge("commander", "Comandante de Misión Artemis", "¡Completaste con éxito la expedición de 14 soles!", "🏆")
		_trigger_victory()
		return
		
	day_cycle_advanced.emit(day_cycle)
	notify_player("¡Avanzaste al Sol %d de 14!" % day_cycle, Color(0.4, 0.85, 1.0))
	
	# 1. Aplicar mutadores pasivos acumulados de ciclos previos
	var em = get_node_or_null("/root/EventManager")
	if em:
		if em.has_method("apply_perks_cycle_effects"):
			em.apply_perks_cycle_effects()
		# 2. Ofrecer 3 cartas de perks tipo roguelike
		if em.has_method("get_3_random_perks"):
			var perks: Array = em.get_3_random_perks()
			if not perks.is_empty():
				perk_selection_requested.emit(perks)


func select_perk(_idx: int) -> void:
	waiting_for_perk_selection = false


func notify_player(message: String, color: Variant = Color.WHITE) -> void:
	var final_color: Color = Color.WHITE
	if color is Color:
		final_color = color
	elif color is String:
		match color:
			"ok", "green":
				final_color = Color.GREEN
			"warn", "yellow":
				final_color = Color.YELLOW
			"bad", "red":
				final_color = Color(1.0, 0.3, 0.3)
			_:
				final_color = Color.WHITE
	notification_sent.emit(message, final_color)
	print("[SPACE CONTI] %s" % message)
	_notify(message, "ok" if final_color == Color.GREEN else ("warn" if final_color == Color.YELLOW else "info"))


func _notify(text: String, kind: String = "info") -> void:
	notification.emit(text, kind)
	var sim_node: Node = get_node_or_null("/root/Sim")
	if sim_node and sim_node.get("config") != null and sim_node.has_method("notify"):
		sim_node.notify(text, kind)
