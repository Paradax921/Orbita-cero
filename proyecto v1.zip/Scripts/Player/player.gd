extends CharacterBody3D
## Astronauta en primera persona: WASD, ratón, colisiones, RayCast3D de
## interacción (tecla E) y manos enguantadas con animación.

const InputSetup = preload("res://Scripts/Player/input_setup.gd")

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var ray: RayCast3D = $Head/Camera3D/InteractRay
@onready var hands: Node3D = $Head/Camera3D/Hands

var _pitch: float = 0.0
var _bob: float = 0.0
var _hand_nodes: Array = []
var _target: Object = null


func _ready() -> void:
	add_to_group("player")
	InputSetup.ensure()
	_build_hands()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not Sim.ui_blocking:
		var s: float = Sim.config.mouse_sensitivity
		rotate_y(-event.relative.x * s)
		_pitch = clampf(_pitch - event.relative.y * s, deg_to_rad(-85.0), deg_to_rad(85.0))
		head.rotation.x = _pitch
	elif event.is_action_pressed("toggle_cursor") and not Sim.ui_blocking:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event is InputEventMouseButton and event.pressed and not Sim.ui_blocking:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event.is_action_pressed("pause_sim") and not Sim.ui_blocking and not Sim.mission_over:
		Sim.paused = not Sim.paused
	elif event.is_action_pressed("interact") and not Sim.ui_blocking:
		if _target and _target.has_method("interact"):
			_target.interact(self)
			_punch_hand()


func _physics_process(delta: float) -> void:
	var gm = get_node_or_null("/root/GameManager")
	var dir := Vector3.ZERO
	var captured: bool = Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not Sim.ui_blocking
	
	if captured and not (gm and gm.in_micro_blackout):
		var input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		dir = (transform.basis * Vector3(input.x, 0.0, input.y)).normalized()
		
	var speed: float = Sim.config.move_speed
	if gm and gm.is_starving:
		# Inanición: Sin sprint y velocidad al 55%
		speed *= 0.55
	elif Input.is_action_pressed("sprint") and not (gm and gm.in_micro_blackout):
		speed *= Sim.config.sprint_multiplier
		
	velocity.x = move_toward(velocity.x, dir.x * speed, speed * 8.0 * delta)
	velocity.z = move_toward(velocity.z, dir.z * speed, speed * 8.0 * delta)
	velocity.y = -1.0 if is_on_floor() else velocity.y - 9.8 * delta
	move_and_slide()
	_update_bob(delta)
	_update_target()


func _update_target() -> void:
	_target = null
	Sim.current_prompt = ""
	var gm = get_node_or_null("/root/GameManager")
	if ray.is_colliding() and not Sim.ui_blocking and not Sim.mission_over and not (gm and gm.in_micro_blackout):
		var c := ray.get_collider()
		if c and c.has_method("get_prompt"):
			_target = c
			Sim.current_prompt = c.get_prompt()


func _update_bob(delta: float) -> void:
	var gm = get_node_or_null("/root/GameManager")
	if gm and gm.in_micro_blackout:
		# Desmayo por asfixia: el astronauta cae al suelo
		camera.position.y = -0.7
		camera.rotation.z = deg_to_rad(20.0)
		hands.position.y = -0.6
		return
		
	var moving := Vector2(velocity.x, velocity.z).length()
	_bob += delta * (4.0 + moving * 1.5)
	var amp: float = clampf(moving / 4.0, 0.0, 1.0)
	hands.position = Vector3(0.0, sin(_bob * 2.0) * 0.008 * amp + sin(_bob * 0.5) * 0.002, 0.0)
	camera.position.y = sin(_bob * 2.0) * 0.012 * amp
	
	if gm and gm.is_suffocating:
		# Tambaleo de visión por falta de oxígeno
		var wobble: float = sin(Time.get_ticks_msec() * 0.006) * 0.04
		camera.rotation.z = wobble
	else:
		camera.rotation.z = 0.0


# --------------------------------------------------------------------- manos
func _build_hands() -> void:
	var glove := StandardMaterial3D.new()
	glove.albedo_color = Color(0.82, 0.84, 0.86)
	glove.roughness = 0.8
	var cuff := StandardMaterial3D.new()
	cuff.albedo_color = Color(0.25, 0.28, 0.32)
	cuff.metallic = 0.6
	cuff.roughness = 0.4
	var sleeve := StandardMaterial3D.new()
	sleeve.albedo_color = Color(0.9, 0.9, 0.92)
	sleeve.roughness = 0.9
	for side in [-1.0, 1.0]:
		var h := Node3D.new()
		h.position = Vector3(side * 0.22, -0.26, -0.42)
		h.rotation_degrees = Vector3(12.0, side * -8.0, side * -6.0)
		hands.add_child(h)
		_box(h, Vector3(0, 0, 0), Vector3(0.095, 0.04, 0.10), glove)
		for i in 4:
			var f := _box(h, Vector3((i - 1.5) * 0.022, -0.004, -0.095), Vector3(0.02, 0.025, 0.07), glove)
			f.rotation_degrees.x = -18.0
		_box(h, Vector3(side * -0.06, -0.01, -0.03), Vector3(0.03, 0.03, 0.07), glove).rotation_degrees.y = side * 30.0
		var c := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.058
		cm.bottom_radius = 0.058
		cm.height = 0.05
		c.mesh = cm
		c.material_override = cuff
		c.rotation_degrees.x = 90.0
		c.position = Vector3(0, 0, 0.075)
		h.add_child(c)
		_box(h, Vector3(0, 0.005, 0.28), Vector3(0.11, 0.1, 0.32), sleeve)
		_hand_nodes.append(h)


func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	m.mesh = b
	m.material_override = mat
	m.position = pos
	parent.add_child(m)
	return m


func _punch_hand() -> void:
	if _hand_nodes.is_empty():
		return
	var h: Node3D = _hand_nodes[1]
	var base := h.position
	var tw := create_tween()
	tw.tween_property(h, "position", base + Vector3(-0.04, 0.03, -0.12), 0.08)
	tw.tween_property(h, "position", base, 0.15)
