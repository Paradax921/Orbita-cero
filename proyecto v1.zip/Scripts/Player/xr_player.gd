extends CharacterBody3D
## Jugador VR (OpenXR: Meta Quest 2/3/3S/Pro por Link o standalone, y cualquier
## visor OpenXR). Locomoción con el stick izquierdo, giro por saltos con el
## derecho, puntero láser en la mano derecha, gatillo = interactuar (E).
## Panel de muñeca en la mano izquierda con el HUD.

const WristPanel = preload("res://Scripts/UI/vr_wrist_panel.gd")

@onready var origin: XROrigin3D = $XROrigin3D
@onready var camera: XRCamera3D = $XROrigin3D/XRCamera3D
@onready var left: XRController3D = $XROrigin3D/LeftHand
@onready var right: XRController3D = $XROrigin3D/RightHand
@onready var ray: RayCast3D = $XROrigin3D/RightHand/PointerRay
@onready var col: CollisionShape3D = $CollisionShape3D

const RAY_LENGTH := 3.5
const SNAP_DEGREES := 45.0

var _laser: MeshInstance3D
var _laser_mat: StandardMaterial3D
var _prompt: Label3D
var _snap_ready: bool = true
var _target: Object = null
var _panel: Node = null
var _active_panel: Node = null


func _ready() -> void:
	add_to_group("player")
	_build_hand(left, -1.0)
	_build_hand(right, 1.0)
	_build_laser()
	var wrist := Node3D.new()
	wrist.set_script(WristPanel)
	left.add_child(wrist)
	right.button_pressed.connect(_on_right_pressed)
	right.button_released.connect(_on_right_released)
	left.button_pressed.connect(_on_left_pressed)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _physics_process(delta: float) -> void:
	# --- locomoción (stick izquierdo, relativa a la mirada) ---
	var s: Vector2 = left.get_vector2("primary")
	var dir := Vector3.ZERO
	if s.length() > 0.15 and not Sim.mission_over:
		var yaw := Basis(Vector3.UP, camera.global_rotation.y)
		dir = yaw * Vector3(s.x, 0.0, -s.y)
	var speed: float = Sim.config.move_speed * 0.7
	velocity.x = move_toward(velocity.x, dir.x * speed, speed * 10.0 * delta)
	velocity.z = move_toward(velocity.z, dir.z * speed, speed * 10.0 * delta)
	velocity.y = -1.0 if is_on_floor() else velocity.y - 9.8 * delta
	# la cápsula de colisión sigue a la cabeza (room-scale)
	col.global_position = Vector3(camera.global_position.x, global_position.y + 0.86, camera.global_position.z)
	move_and_slide()
	# --- giro por saltos (stick derecho) ---
	var t: float = right.get_vector2("primary").x
	if absf(t) > 0.7 and _snap_ready:
		_snap_ready = false
		_snap_turn(-signf(t) * SNAP_DEGREES)
	elif absf(t) < 0.3:
		_snap_ready = true
	_update_pointer()


func _snap_turn(deg: float) -> void:
	var p := Vector3(camera.global_position.x, origin.global_position.y, camera.global_position.z)
	var rot := Transform3D(Basis(Vector3.UP, deg_to_rad(deg)), Vector3.ZERO)
	var pivot := Transform3D(Basis.IDENTITY, p)
	origin.global_transform = pivot * rot * pivot.affine_inverse() * origin.global_transform


func _update_pointer() -> void:
	_target = null
	_panel = null
	Sim.current_prompt = ""
	_prompt.visible = false
	var length := RAY_LENGTH
	var color := Color(0.3, 0.8, 1.0, 0.6)
	ray.force_raycast_update()
	if ray.is_colliding():
		var c := ray.get_collider()
		var hit := ray.get_collision_point()
		length = ray.global_position.distance_to(hit)
		if c and c.has_meta("vr_panel"):
			_panel = c.get_meta("vr_panel")
			_panel.pointer_move(hit)
			color = Color(0.3, 1.0, 0.5, 0.8)
		elif c and c.has_method("get_prompt") and not Sim.ui_blocking and not Sim.mission_over:
			_target = c
			Sim.current_prompt = c.get_prompt()
			_prompt.text = Sim.current_prompt.replace("[E]", "[Gatillo]")
			_prompt.global_position = hit + (camera.global_position - hit).normalized() * 0.25 + Vector3(0, 0.12, 0)
			_prompt.visible = true
			color = Color(1.0, 0.85, 0.2, 0.9)
	if _active_panel and _panel != _active_panel:
		pass
	_laser_mat.albedo_color = color
	_laser_mat.emission = color
	var cm: CylinderMesh = _laser.mesh
	cm.height = length
	_laser.position = Vector3(0, 0, -length * 0.5)


func _on_right_pressed(button: String) -> void:
	if button != "trigger_click":
		return
	if _panel:
		_active_panel = _panel
		_panel.pointer_button(true)
		right.trigger_haptic_pulse("haptic", 0.0, 0.3, 0.05, 0.0)
	elif _target and _target.has_method("interact"):
		_target.interact(self)
		right.trigger_haptic_pulse("haptic", 0.0, 0.8, 0.12, 0.0)


func _on_right_released(button: String) -> void:
	if button == "trigger_click" and _active_panel:
		_active_panel.pointer_button(false)
		_active_panel = null


func _on_left_pressed(button: String) -> void:
	if button == "menu_button" and not Sim.mission_over:
		Sim.paused = not Sim.paused
		Sim.notify("Simulación " + ("en PAUSA" if Sim.paused else "reanudada"), "info")
	elif button == "by_button":
		var d := get_tree().get_first_node_in_group("dashboard")
		if d and Sim.ui_blocking:
			d.close()


# --------------------------------------------------------------- modelos
func _build_laser() -> void:
	_laser = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.003
	cm.bottom_radius = 0.003
	cm.height = RAY_LENGTH
	cm.radial_segments = 6
	_laser.mesh = cm
	_laser.rotation_degrees = Vector3(90, 0, 0)
	_laser_mat = StandardMaterial3D.new()
	_laser_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_laser_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_laser_mat.emission_enabled = true
	_laser.material_override = _laser_mat
	_laser.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ray.add_child(_laser)
	_prompt = Label3D.new()
	_prompt.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_prompt.no_depth_test = true
	_prompt.pixel_size = 0.0018
	_prompt.font_size = 64
	_prompt.outline_size = 16
	_prompt.modulate = Color(1.0, 0.85, 0.2)
	_prompt.top_level = true
	_prompt.visible = false
	add_child(_prompt)


func _build_hand(ctrl: XRController3D, side: float) -> void:
	var glove := StandardMaterial3D.new()
	glove.albedo_color = Color(0.82, 0.84, 0.86)
	glove.roughness = 0.8
	var cuff := StandardMaterial3D.new()
	cuff.albedo_color = Color(0.2, 0.23, 0.28)
	cuff.metallic = 0.6
	cuff.roughness = 0.4
	var h := Node3D.new()
	h.rotation_degrees = Vector3(-30, 0, 0)
	ctrl.add_child(h)
	_box(h, Vector3(0, 0, 0), Vector3(0.09, 0.04, 0.1), glove)
	for i in 4:
		_box(h, Vector3((i - 1.5) * 0.021, -0.004, -0.085), Vector3(0.019, 0.024, 0.065), glove)
	_box(h, Vector3(side * -0.055, -0.01, -0.02), Vector3(0.03, 0.03, 0.065), glove).rotation_degrees.y = side * 30.0
	_box(h, Vector3(0, 0, 0.09), Vector3(0.1, 0.1, 0.06), cuff)
	_box(h, Vector3(0, 0.003, 0.22), Vector3(0.1, 0.09, 0.22), glove)


func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	m.mesh = b
	m.material_override = mat
	m.position = pos
	parent.add_child(m)
	return m
