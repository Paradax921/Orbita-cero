extends Area3D
## MÓDULO 3D INTERACTIVO DIDÁCTICO — SPACE CONTI
## Mantiene un indicador 3D limpio y pequeño en el mundo (pixel_size = 0.003).
## Al acercarse el astronauta, envía los datos al panel 2D de alta legibilidad
## en el HUD de SpaceContiUI para que nunca se corten ni tapen la vista.

signal minigame_triggered(module_ref: Node)
signal module_calibrated(success: bool)

@export var module_id: String = "subsystem"
@export var module_title: String = "Módulo Lunar"
@export var short_tag: String = ""
@export_multiline var nasa_fact: String = "Dato científico de la NASA sobre este sistema."
@export var nasa_source: String = "NASA Exploration Systems"
@export var cost_benefit_text: String = "Coste: -15 E / Beneficio: +25 O₂"

@export_group("Tradeoffs de Calibración")
@export var delta_energy: float = -15.0
@export var delta_oxygen: float = 25.0
@export var delta_food: float = 0.0
@export var delta_shield: float = 0.0

@onready var label_3d: Label3D = $Label3D

var is_player_nearby: bool = false
var is_cooldown: bool = false


func _ready() -> void:
	collision_layer = 3 # Capa 1 y 2 para detección física y raycast
	collision_mask = 1  # Detecta al jugador
	
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	
	if label_3d:
		label_3d.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label_3d.pixel_size = 0.003
		label_3d.font_size = 20
		label_3d.outline_size = 4
		label_3d.no_depth_test = true
		_update_3d_label(false)


func _unhandled_input(event: InputEvent) -> void:
	if is_player_nearby and event.is_action_pressed("interact") and not Sim.ui_blocking:
		var ui = get_tree().root.find_child("SpaceContiUI", true, false)
		if ui and not ui.minigame_active:
			interact(self)
			get_viewport().set_input_as_handled()


func _on_body_entered(body: Node3D) -> void:
	if body.is_in_group("player") or body.name == "Player":
		is_player_nearby = true
		_update_3d_label(true)
		var ui = get_tree().root.find_child("SpaceContiUI", true, false)
		if ui and ui.has_method("show_module_card"):
			ui.show_module_card(self)


func _on_body_exited(body: Node3D) -> void:
	if body.is_in_group("player") or body.name == "Player":
		is_player_nearby = false
		_update_3d_label(false)
		var ui = get_tree().root.find_child("SpaceContiUI", true, false)
		if ui and ui.has_method("hide_module_card"):
			ui.hide_module_card(self)


func _update_3d_label(highlight: bool) -> void:
	if not label_3d:
		return
	# Indicador 3D corto, limpio y sin textos largos flotantes
	var display_text = short_tag if not short_tag.is_empty() else ("%s [E]" % module_title)
	label_3d.text = display_text
	if is_cooldown:
		label_3d.modulate = Color(0.5, 0.5, 0.5, 0.7)
	elif highlight:
		label_3d.modulate = Color(1.0, 0.88, 0.25, 1.0)
	else:
		label_3d.modulate = Color(0.4, 0.85, 1.0, 0.85)


func get_prompt() -> String:
	if is_cooldown:
		return "[Calibrando circuitos...]"
	return "[E] Calibrar %s (%s)" % [module_title, cost_benefit_text]


func interact(_player: Node) -> void:
	if is_cooldown:
		return
		
	var ui = get_tree().root.find_child("SpaceContiUI", true, false)
	if ui and ui.has_method("start_calibration_minigame"):
		ui.start_calibration_minigame(self)
	else:
		apply_calibration_effect(true)


func apply_calibration_effect(success: bool) -> void:
	var ui = get_tree().root.find_child("SpaceContiUI", true, false)
	if success:
		GameManager.apply_tradeoff(delta_energy, delta_oxygen, delta_food, delta_shield)
		GameManager.notify_player("¡Calibración exitosa de %s! %s" % [module_title, cost_benefit_text], Color.GREEN)
		GameManager.module_repaired.emit(module_title)
		
		# Desbloqueo de insignias pedagógicas según el subsistema
		match module_id:
			"oxygen_generator":
				GameManager.unlock_badge("oga_specialist", "Especialista OGA", "Calibraste el ensamble de oxígeno Artemis.", "💨")
			"greenhouse_veggie":
				GameManager.unlock_badge("veggie_botanist", "Botánico VEGGIE", "Optimizaste los cultivos espaciales OSDR.", "🌱")
			"solar_power_grid":
				GameManager.unlock_badge("glenn_power", "Ingeniero Solar Glenn", "Restableciste la red fotovoltaica lunar.", "⚡")
			"shield_airlock":
				GameManager.unlock_badge("regolith_shield", "Guardián de Regolito", "Fortaleciste la esclusa contra radiación DONKI.", "🛡️")
				
		if ui and ui.has_method("play_sfx_success"):
			ui.play_sfx_success()
			
		# Pulso visual en 3D: brillo verde y escalado
		if label_3d:
			label_3d.modulate = Color(0.2, 1.0, 0.4)
			var tw := create_tween()
			tw.tween_property(label_3d, "scale", Vector3(1.25, 1.25, 1.25), 0.15)
			tw.tween_property(label_3d, "scale", Vector3.ONE, 0.25)
	else:
		var pen_e: float = 0.0
		var pen_ox: float = 0.0
		var pen_food: float = 0.0
		var pen_shield: float = 0.0
		
		match module_id:
			"solar_power_grid":
				pen_e = -25.0
				pen_shield = -15.0
			"oxygen_generator":
				pen_ox = -25.0
				pen_e = -15.0
			"greenhouse_veggie":
				pen_food = -25.0
				pen_ox = -15.0
			"shield_airlock":
				pen_shield = -25.0
				pen_e = -15.0
			_:
				pen_e = -25.0
				pen_shield = -15.0
				
		GameManager.apply_tradeoff(pen_e, pen_ox, pen_food, pen_shield)
		var parts: Array[String] = []
		if pen_e < 0.0: parts.append("%d Energía" % int(pen_e))
		if pen_ox < 0.0: parts.append("%d Oxígeno" % int(pen_ox))
		if pen_food < 0.0: parts.append("%d Comida" % int(pen_food))
		if pen_shield < 0.0: parts.append("%d Escudo" % int(pen_shield))
		var msg: String = "⚠️ ¡FALLO DE CALIBRACIÓN! %s" % " / ".join(parts)
		GameManager.notify_player(msg, Color(1.0, 0.25, 0.25))
		
		if ui and ui.has_method("play_sfx_error"):
			ui.play_sfx_error()
			
		# Sacudida visual en 3D: rojo
		if label_3d:
			label_3d.modulate = Color(1.0, 0.2, 0.2)
			var base_x = label_3d.position.x
			var tw := create_tween()
			tw.tween_property(label_3d, "position:x", base_x + 0.04, 0.05)
			tw.tween_property(label_3d, "position:x", base_x - 0.04, 0.05)
			tw.tween_property(label_3d, "position:x", base_x, 0.05)
		
	_start_cooldown()


func _start_cooldown() -> void:
	is_cooldown = true
	_update_3d_label(false)
	await get_tree().create_timer(3.0).timeout
	is_cooldown = false
	_update_3d_label(is_player_nearby)
	if is_player_nearby:
		var ui = get_tree().root.find_child("SpaceContiUI", true, false)
		if ui and ui.has_method("show_module_card"):
			ui.show_module_card(self)
