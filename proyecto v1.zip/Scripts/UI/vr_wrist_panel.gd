extends Node3D
## Panel de muñeca (mano izquierda) con el HUD resumido para VR:
## recursos, estado, reloj, alertas y último mensaje. Mire su muñeca para leerlo.

const UIStyle = preload("res://Scripts/UI/ui_style.gd")

var _vp: SubViewport
var _bars: Dictionary = {}
var _clock: Label
var _status: Label
var _alerts: Label
var _toast: Label
var _footer: Label
var _acc: float = 0.0


func _ready() -> void:
	_vp = SubViewport.new()
	_vp.size = Vector2i(640, 420)
	_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(_vp)
	var root := PanelContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.01, 0.04, 0.1, 1.0), UIStyle.EDGE, 3, 0))
	_vp.add_child(root)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 3)
	root.add_child(v)
	var head := HBoxContainer.new()
	_clock = UIStyle.label("", 22, UIStyle.ACCENT)
	_clock.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_status = UIStyle.label("", 18)
	head.add_child(_clock)
	head.add_child(_status)
	v.add_child(head)
	for key in ["ENERGÍA", "OXÍGENO", "AGUA", "ALIMENTOS"]:
		var h := HBoxContainer.new()
		var n := UIStyle.label(key, 18, UIStyle.DIM)
		n.custom_minimum_size = Vector2(130, 0)
		var b := UIStyle.progress(UIStyle.OK, 20.0)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var val := UIStyle.label("", 18)
		val.custom_minimum_size = Vector2(60, 0)
		h.add_child(n)
		h.add_child(b)
		h.add_child(val)
		v.add_child(h)
		_bars[key] = {"bar": b, "val": val}
	_alerts = UIStyle.label("", 16, UIStyle.WARN)
	_alerts.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_alerts.custom_minimum_size = Vector2(0, 70)
	v.add_child(_alerts)
	_toast = UIStyle.label("", 15, UIStyle.TEXT)
	_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast.custom_minimum_size = Vector2(0, 40)
	v.add_child(_toast)
	_footer = UIStyle.label("", 16, UIStyle.ACCENT)
	v.add_child(_footer)
	var quad := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(0.22, 0.22 * 420.0 / 640.0)
	quad.mesh = qm
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = _vp.get_texture()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	quad.material_override = mat
	quad.rotation_degrees = Vector3(-90, 0, 0)
	quad.position = Vector3(0, 0.07, 0.0)
	add_child(quad)
	Sim.toast.connect(func(t, _k): _toast.text = t)
	_refresh()


func _process(delta: float) -> void:
	_acc += delta
	if _acc >= 0.25:
		_acc = 0.0
		_refresh()


func _set_row(key: String, pct: float) -> void:
	var c: Dictionary = _bars[key]
	UIStyle.set_bar(c["bar"], pct, UIStyle.level_color(pct))
	c["val"].text = "%d%%" % int(pct)


func _refresh() -> void:
	_clock.text = "T+ " + Sim.format_clock(Sim.elapsed)
	_status.text = Sim.station_status
	_status.add_theme_color_override("font_color", {"NOMINAL": UIStyle.OK, "ADVERTENCIA": UIStyle.WARN, "CRÍTICO": UIStyle.BAD}[Sim.station_status])
	_set_row("ENERGÍA", Sim.power.percent())
	_set_row("OXÍGENO", Sim.oxygen.cabin)
	_set_row("AGUA", Sim.water.percent())
	_set_row("ALIMENTOS", Sim.food.percent())
	var keys: Array = Sim.alerts.keys()
	keys.sort_custom(func(a, b): return Sim.alerts[a]["severity"] > Sim.alerts[b]["severity"])
	var t := ""
	for i in mini(3, keys.size()):
		t += ("⚠ " if Sim.alerts[keys[i]]["severity"] >= 2 else "▲ ") + Sim.alerts[keys[i]]["text"] + "\n"
	_alerts.text = t.strip_edges()
	_footer.text = "Kits: %d   Tripulación: %d%%   %s" % [Sim.repair_kits, int(Sim.crew_health), "☾" if Sim.power.is_night() else "☀"]
	_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
