extends CanvasLayer
## Informe final de misión.

const UIStyle = preload("res://Scripts/UI/ui_style.gd")
const VRPanel = preload("res://Scripts/UI/vr_panel.gd")

var _root: Control
var _text: RichTextLabel
var _title: Label
var _vr_panel: Node3D = null


func _ready() -> void:
	layer = 20
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	if Sim.vr_mode:
		_vr_panel = VRPanel.new()
		_vr_panel.content = _root
		_vr_panel.size_px = Vector2i(780, 600)
		_vr_panel.width_m = 1.5
		get_parent().add_child.call_deferred(_vr_panel)
	else:
		add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0, 0.01, 0.04, 0.85)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(dim)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.02, 0.06, 0.14, 0.98), UIStyle.EDGE, 2, 6))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(720, 560)
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	_root.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)
	_title = UIStyle.label("INFORME DE MISIÓN", 24, UIStyle.ACCENT)
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_title)
	_text = RichTextLabel.new()
	_text.bbcode_enabled = true
	_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_text.add_theme_font_size_override("normal_font_size", 15)
	_text.add_theme_font_size_override("bold_font_size", 15)
	v.add_child(_text)
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 20)
	var again := UIStyle.button("Nueva misión")
	again.pressed.connect(_restart)
	var quit := UIStyle.button("Salir")
	quit.pressed.connect(func(): get_tree().quit())
	h.add_child(again)
	h.add_child(quit)
	v.add_child(h)
	_root.visible = false
	Sim.mission_ended.connect(_show)


func _show(r: Dictionary) -> void:
	Sim.ui_blocking = true
	_root.visible = true
	if _vr_panel:
		_vr_panel.show_in_front()
	else:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var col := "#40f08c" if r["success"] else "#ff4030"
	var t := "[center][color=%s][b]%s[/b][/color]\n" % [col, r["reason"]]
	t += "Calificación: [color=#ffd133][b]%s[/b][/color]   ·   Puntuación: %d / 100[/center]\n\n" % [r["grade"], int(r["score"])]
	t += "Duración de la misión: %s\n" % r["clock"]
	t += "Estabilidad media: %d%% (mínima %d%%)\n" % [int(r["stability_avg"]), int(r["stability_min"])]
	t += "Disponibilidad media de recursos: %d%%\n" % int(r["availability"])
	t += "Tiempo de funcionamiento sin alertas críticas: %d%%\n" % int(r["uptime"])
	t += "Incidentes: %d (resueltos %d, sin resolver %d) · resolución media %ds\n" % [r["incidents"], r["resolved"], r["unresolved"], int(r["avg_resolution"])]
	t += "Eficiencia energética: %d%% (generado %.0f kWh, consumido %.0f kWh)\n" % [int(r["energy_eff"]), r["energy_generated"], r["energy_consumed"]]
	t += "Producción alimentaria: %d%% de la demanda (%.0f cosechadas / %.0f consumidas)\n" % [int(r["food_level"]), r["food_harvested"], r["food_consumed"]]
	t += "O₂ generado: %.1f u · Agua reciclada: %.1f u\n" % [r["o2_produced"], r["water_recycled"]]
	t += "Salud final de la tripulación: %d%% · Kits sobrantes: %d\n\n" % [int(r["crew_health"]), r["kits_left"]]
	t += "[b]Niveles finales[/b]  Energía %d%% · O₂ %d%% · Agua %d%% · Alimentos %d%%" % [int(r["final_energy"]), int(r["final_o2"]), int(r["final_water"]), int(r["final_food"])]
	_text.text = t


func _restart() -> void:
	_root.visible = false
	if _vr_panel:
		_vr_panel.hide_panel()
	Sim.start_mission()
	get_tree().reload_current_scene()
