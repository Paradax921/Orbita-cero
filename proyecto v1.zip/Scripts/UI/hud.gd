extends CanvasLayer
## HUD futurista: recursos, estado general, reloj de misión, alertas,
## mensajes (toasts), prompt de interacción y mira.

const UIStyle = preload("res://Scripts/UI/ui_style.gd")

var _cards: Dictionary = {}
var _status_label: Label
var _clock_label: Label
var _sun_label: Label
var _crew_label: Label
var _kits_label: Label
var _alert_box: VBoxContainer
var _toast_box: VBoxContainer
var _prompt: Label
var _help: Label
var _acc: float = 0.0
var _blink: float = 0.0
var _pause_label: Label


func _ready() -> void:
	layer = 5
	if Sim.vr_mode:
		visible = false   # en VR el HUD es el panel de la muñeca izquierda
		set_process(false)
		return
	_build()
	Sim.toast.connect(_on_toast)


func _build() -> void:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	# --- Barra superior de recursos ---
	var top := PanelContainer.new()
	top.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.01, 0.04, 0.1, 0.7)))
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 12
	top.offset_right = -12
	top.offset_top = 10
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top)
	if get_tree().root.find_child("SpaceContiUI", true, false) != null:
		top.visible = false
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(row)
	for key in ["energy", "oxygen", "radiation_shield"]:
		row.add_child(_make_card(key))
	var info := VBoxContainer.new()
	info.custom_minimum_size = Vector2(190, 0)
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_clock_label = UIStyle.label("T+ D0 00:00:00", 18, UIStyle.ACCENT)
	_status_label = UIStyle.label("ESTACIÓN: NOMINAL", 14, UIStyle.OK)
	_sun_label = UIStyle.label("", 12, UIStyle.DIM)
	info.add_child(_clock_label)
	info.add_child(_status_label)
	info.add_child(_sun_label)
	row.add_child(info)

	# --- Alertas (izquierda) ---
	_alert_box = VBoxContainer.new()
	_alert_box.set_anchors_preset(Control.PRESET_TOP_LEFT)
	_alert_box.offset_left = 14
	_alert_box.offset_top = 120
	_alert_box.add_theme_constant_override("separation", 4)
	_alert_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_alert_box)

	# --- Estado de tripulación / kits (abajo izquierda) ---
	var bl := PanelContainer.new()
	bl.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.01, 0.04, 0.1, 0.7)))
	bl.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	bl.offset_left = 12
	bl.offset_bottom = -12
	bl.offset_top = -64
	bl.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(bl)
	var bv := VBoxContainer.new()
	bl.add_child(bv)
	_crew_label = UIStyle.label("", 13)
	_kits_label = UIStyle.label("", 13, UIStyle.ACCENT)
	bv.add_child(_crew_label)
	bv.add_child(_kits_label)

	# --- Ayuda de controles (abajo derecha) ---
	_help = UIStyle.label("WASD mover · Ratón mirar · E interactuar · Shift correr · P pausa · ESC cursor", 12, UIStyle.DIM)
	_help.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	_help.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_help.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_help.offset_right = -14
	_help.offset_bottom = -10
	root.add_child(_help)

	# --- Mira + prompt ---
	var cross := UIStyle.label("+", 22, Color(0.7, 0.95, 1.0, 0.8))
	cross.set_anchors_preset(Control.PRESET_CENTER)
	cross.grow_horizontal = Control.GROW_DIRECTION_BOTH
	cross.grow_vertical = Control.GROW_DIRECTION_BOTH
	root.add_child(cross)
	_prompt = UIStyle.label("", 18, UIStyle.ACCENT)
	_prompt.set_anchors_preset(Control.PRESET_CENTER)
	_prompt.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_prompt.offset_top = 40
	_prompt.offset_bottom = 70
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.add_theme_color_override("font_outline_color", Color.BLACK)
	_prompt.add_theme_constant_override("outline_size", 6)
	root.add_child(_prompt)

	# --- Toasts (centro inferior) ---
	_toast_box = VBoxContainer.new()
	_toast_box.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_toast_box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_toast_box.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_toast_box.offset_bottom = -60
	_toast_box.alignment = BoxContainer.ALIGNMENT_END
	_toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_toast_box)

	_pause_label = UIStyle.label("— PAUSA —", 40, UIStyle.ACCENT)
	_pause_label.set_anchors_preset(Control.PRESET_CENTER)
	_pause_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_pause_label.offset_top = -120
	_pause_label.visible = false
	root.add_child(_pause_label)


func _make_card(key: String) -> Control:
	var names := {
		"energy": "ENERGÍA",
		"oxygen": "OXÍGENO",
		"radiation_shield": "ESCUDO RADIACIÓN",
		"water": "AGUA",
		"food": "ALIMENTOS"
	}
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.03, 0.1, 0.2, 0.8)))
	pc.custom_minimum_size = Vector2(190, 0)
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var v := VBoxContainer.new()
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.add_child(v)
	var h := HBoxContainer.new()
	var name_l := UIStyle.label(names.get(key, key), 13, UIStyle.DIM)
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var val_l := UIStyle.label("0%", 16)
	h.add_child(name_l)
	h.add_child(val_l)
	var bar := UIStyle.progress()
	var detail := UIStyle.label("", 11, UIStyle.DIM)
	v.add_child(h)
	v.add_child(bar)
	v.add_child(detail)
	_cards[key] = {"value": val_l, "bar": bar, "detail": detail}
	return pc


func _process(delta: float) -> void:
	_blink += delta
	_prompt.text = Sim.current_prompt
	_pause_label.visible = Sim.paused
	_acc += delta
	if _acc < 0.1:
		return
	_acc = 0.0
	_update_cards()
	_update_alerts()


func _set_card(key: String, pct: float, detail: String) -> void:
	if not _cards.has(key):
		return
	var c: Dictionary = _cards[key]
	var col: Color = UIStyle.level_color(pct)
	c["value"].text = "%d%%" % int(round(pct))
	c["value"].add_theme_color_override("font_color", col)
	UIStyle.set_bar(c["bar"], pct, col)
	c["detail"].text = detail


func _update_cards() -> void:
	var gm = get_node_or_null("/root/GameManager")
	if gm != null:
		_set_card("energy", gm.energy, "Baterías / Paneles Artemis")
		_set_card("oxygen", gm.oxygen, "Cabina y Reciclaje CDRA")
		_set_card("radiation_shield", gm.radiation_shield, "Deflector y Regolito")
		_clock_label.text = "CICLO LUNAR %d / 14" % gm.cycle
		if gm.event_manager and not gm.event_manager.active_crisis_list.is_empty():
			var ev = gm.event_manager.active_crisis_list[0]
			_status_label.text = "CRISIS: " + ev.get("badge", "ALERTA")
			_status_label.add_theme_color_override("font_color", UIStyle.BAD)
		else:
			_status_label.text = "ESTACIÓN: NOMINAL"
			_status_label.add_theme_color_override("font_color", UIStyle.OK)
		_sun_label.text = "Nodos Batería: Inv %d | Esc %d | Ant %d" % [
			gm.battery_allocations["greenhouse"],
			gm.battery_allocations["shield"],
			gm.battery_allocations["antenna"]
		]
		_crew_label.text = "ROGUELIKE ARTEMIS NASA"
		_kits_label.text = "BATERÍAS ASIGNADAS: 3 / 3"
		return

	var p = Sim.power
	_set_card("energy", p.percent(), "+%.1f kW  /  -%.1f kW  (%d/6 paneles)" % [p.generation, Sim.total_power_demand(), p.panels_online()])
	var o = Sim.oxygen
	_set_card("oxygen", o.cabin, "Cabina %d%% · Reserva %d%% · Válvula %s" % [int(o.cabin), int(o.reserve_percent()), o.MODE_NAMES[o.valve_mode]])
	var w = Sim.water
	_set_card("water", w.percent(), "Reciclaje %s · Filtro %d%%" % ["ON" if w.recycler_on else "OFF", int(w.filter * 100.0)])
	var f = Sim.food
	_set_card("food", f.percent(), "Cosecha: %d listas · %d creciendo" % [f.ripe_count(), f.growing_count()])
	_clock_label.text = "T+ " + Sim.format_clock(Sim.elapsed)
	var st: String = Sim.station_status
	_status_label.text = "ESTACIÓN: " + st
	_status_label.add_theme_color_override("font_color", {"NOMINAL": UIStyle.OK, "ADVERTENCIA": UIStyle.WARN, "CRÍTICO": UIStyle.BAD}[st])
	var ttc: int = int(p.time_to_change())
	_sun_label.text = ("☾ NOCHE LUNAR · amanecer en %ds" if p.is_night() else "☀ DÍA LUNAR · anochecer en %ds") % ttc
	_crew_label.text = "TRIPULACIÓN: %d%% salud · %d astronautas" % [int(Sim.crew_health), Sim.config.crew_size]
	_kits_label.text = "KITS DE REPARACIÓN: %d" % Sim.repair_kits


func _update_alerts() -> void:
	for c in _alert_box.get_children():
		c.queue_free()
	var keys: Array = Sim.alerts.keys()
	keys.sort_custom(func(a, b): return Sim.alerts[a]["severity"] > Sim.alerts[b]["severity"])
	var shown := 0
	for k in keys:
		if shown >= 7:
			break
		var a: Dictionary = Sim.alerts[k]
		var crit: bool = a["severity"] >= 2
		var pc := PanelContainer.new()
		var col: Color = UIStyle.BAD if crit else UIStyle.WARN
		pc.add_theme_stylebox_override("panel", UIStyle.panel(Color(col.r * 0.25, col.g * 0.2, 0.03, 0.85), col, 1, 3))
		pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var l := UIStyle.label(("⚠ " if crit else "▲ ") + a["text"], 13, col)
		pc.add_child(l)
		if crit and int(_blink * 2.0) % 2 == 0:
			pc.modulate = Color(1, 1, 1, 0.55)
		_alert_box.add_child(pc)
		shown += 1


func _on_toast(text: String, kind: String) -> void:
	var col := {"ok": UIStyle.OK, "warn": UIStyle.WARN, "bad": UIStyle.BAD, "info": UIStyle.TEXT}.get(kind, UIStyle.TEXT) as Color
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.01, 0.05, 0.12, 0.9), col, 1, 3))
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := UIStyle.label(text, 15, col)
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	pc.add_child(l)
	_toast_box.add_child(pc)
	while _toast_box.get_child_count() > 4:
		var old := _toast_box.get_child(0)
		_toast_box.remove_child(old)
		old.queue_free()
	var tw := create_tween()
	tw.tween_interval(4.5)
	tw.tween_property(pc, "modulate:a", 0.0, 0.6)
	tw.tween_callback(pc.queue_free)
