extends CanvasLayer
## Consola central de administración: control manual de todos los sistemas,
## estadísticas de misión y configuración. Se abre con E en la consola
## central o en el terminal del laboratorio. ESC la cierra.

const UIStyle = preload("res://Scripts/UI/ui_style.gd")
const VRPanel = preload("res://Scripts/UI/vr_panel.gd")

var _root: Control
var _tabs: TabContainer
var _updaters: Array = []
var _is_open: bool = false
var _vr_panel: Node3D = null


func _ready() -> void:
	layer = 10
	add_to_group("dashboard")
	_build()
	_root.visible = false
	Sim.dashboard_requested.connect(open)
	Sim.mission_started.connect(close)
	Sim.mission_ended.connect(func(_r): close())


func _input(event: InputEvent) -> void:
	if _is_open and event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		close()
		get_viewport().set_input_as_handled()


func open(tab_name: String = "Energía") -> void:
	if Sim.mission_over:
		return
	for i in _tabs.get_tab_count():
		if _tabs.get_tab_title(i) == tab_name:
			_tabs.current_tab = i
	_is_open = true
	_root.visible = true
	Sim.ui_blocking = true
	if _vr_panel:
		_vr_panel.show_in_front()
	else:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func close() -> void:
	if not _is_open:
		return
	_is_open = false
	_root.visible = false
	Sim.ui_blocking = false
	if _vr_panel:
		_vr_panel.hide_panel()
	elif not Sim.mission_over:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _process(_delta: float) -> void:
	if not _is_open:
		return
	for u in _updaters:
		u.call()


# ------------------------------------------------------------------ construcción
func _build() -> void:
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	if Sim.vr_mode:
		_vr_panel = VRPanel.new()
		_vr_panel.content = _root
		_vr_panel.size_px = Vector2i(900, 600)
		_vr_panel.width_m = 1.6
		get_parent().add_child.call_deferred(_vr_panel)
	else:
		add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0, 0.02, 0.06, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(dim)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.02, 0.06, 0.14, 0.97), UIStyle.EDGE, 2, 6))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.custom_minimum_size = Vector2(860, 560)
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	_root.add_child(panel)
	var v := VBoxContainer.new()
	panel.add_child(v)
	var head := HBoxContainer.new()
	var title := UIStyle.label("LUNAR BASE 01 · CONSOLA CENTRAL DE ADMINISTRACIÓN", 18, UIStyle.ACCENT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	var kits := UIStyle.label("", 14, UIStyle.ACCENT)
	_updaters.append(func(): kits.text = "Kits: %d    Misión: %s   " % [Sim.repair_kits, Sim.format_clock(Sim.elapsed)])
	head.add_child(kits)
	var close_btn := UIStyle.button("Cerrar (ESC)")
	close_btn.pressed.connect(close)
	head.add_child(close_btn)
	v.add_child(head)
	_tabs = TabContainer.new()
	_tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tabs.add_theme_color_override("font_selected_color", UIStyle.ACCENT)
	_tabs.add_theme_color_override("font_unselected_color", UIStyle.DIM)
	_tabs.add_theme_font_size_override("font_size", 15)
	v.add_child(_tabs)
	_build_power()
	_build_oxygen()
	_build_water()
	_build_food()
	_build_stats()
	_build_settings()


func _tab(title: String) -> VBoxContainer:
	var m := MarginContainer.new()
	m.name = title
	for s in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + s, 12)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	m.add_child(v)
	_tabs.add_child(m)
	return v


func _bar_row(parent: Control, caption: String, getter: Callable, max_is_pct: bool = true) -> void:
	var h := HBoxContainer.new()
	var cap := UIStyle.label(caption, 14, UIStyle.DIM)
	cap.custom_minimum_size = Vector2(190, 0)
	var bar := UIStyle.progress(UIStyle.EDGE, 18.0)
	bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var val := UIStyle.label("", 14)
	val.custom_minimum_size = Vector2(60, 0)
	h.add_child(cap)
	h.add_child(bar)
	h.add_child(val)
	parent.add_child(h)
	_updaters.append(func():
		var pct: float = getter.call()
		UIStyle.set_bar(bar, pct, UIStyle.level_color(pct))
		val.text = "%d%%" % int(pct))


func _text_row(parent: Control, getter: Callable, color: Color = UIStyle.TEXT) -> Label:
	var l := UIStyle.label("", 14, color)
	parent.add_child(l)
	_updaters.append(func(): l.text = getter.call())
	return l


func _btn_row(parent: Control) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	parent.add_child(h)
	return h


func _btn(parent: Control, text: String, action: Callable) -> Button:
	var b := UIStyle.button(text)
	b.pressed.connect(func():
		action.call()
		Sim.audio.play_click())
	parent.add_child(b)
	return b


func _kit_action(fn: Callable) -> Callable:
	return func():
		if Sim.use_kit():
			fn.call()


# ------------------------------------------------------------------ pestañas
func _build_power() -> void:
	var v := _tab("Energía")
	_bar_row(v, "Batería", func(): return Sim.power.percent())
	_text_row(v, func(): return "Generación: %.1f kW   ·   Consumo: %.1f kW   ·   Balance: %+.1f kW   ·   Suministro: %d%%" % [
		Sim.power.generation, Sim.total_power_demand(), Sim.power.generation - Sim.total_power_demand(), int(Sim.power.supply_ratio * 100.0)])
	_text_row(v, func(): return ("☾ Noche lunar (sin generación) — cambia en %ds" if Sim.power.is_night() else "☀ Día lunar — anochece en %ds") % int(Sim.power.time_to_change()), UIStyle.ACCENT)
	_text_row(v, func(): return "Polvo medio en paneles: %d%% (reduce hasta 50%% la generación)" % int(Sim.power.avg_dust() * 100.0), UIStyle.DIM)
	for i in Sim.power.PANEL_COUNT:
		var h := _btn_row(v)
		var lbl := UIStyle.label("", 14)
		lbl.custom_minimum_size = Vector2(380, 0)
		h.add_child(lbl)
		var idx: int = i
		_updaters.append(func():
			var p: Dictionary = Sim.power.panels[idx]
			var st := "AVERIADO" if p["failed"] else ("ACTIVO" if p["online"] else "APAGADO")
			lbl.text = "Panel solar #%d — %s — polvo %d%%" % [idx + 1, st, int(p["dust"] * 100.0)]
			lbl.add_theme_color_override("font_color", UIStyle.BAD if p["failed"] else (UIStyle.OK if p["online"] else UIStyle.DIM)))
		_btn(h, "Activar / Desactivar", func(): Sim.power.toggle_panel(idx))
		_btn(h, "Reparar (1 kit)", func():
			var key: String = Sim.events.first_with_prefix("panel_%d" % idx)
			if key != "" and Sim.use_kit():
				Sim.events.resolve(key))
	var h2 := _btn_row(v)
	_btn(h2, "Encender todos", func(): Sim.power.set_all(true))
	_btn(h2, "Apagar todos", func(): Sim.power.set_all(false))
	_btn(h2, "Limpiar polvo (1 kit)", _kit_action(func(): Sim.power.clean_dust()))
	_btn(h2, "Reparar cortocircuito (1 kit)", func():
		if Sim.events.is_active("power_short") and Sim.use_kit():
			Sim.events.resolve("power_short"))


func _build_oxygen() -> void:
	var v := _tab("Oxígeno")
	_bar_row(v, "Reserva de tanques", func(): return Sim.oxygen.reserve_percent())
	_bar_row(v, "Atmósfera de cabina", func(): return Sim.oxygen.cabin)
	_bar_row(v, "Eficiencia del generador", func(): return Sim.oxygen.efficiency() * 100.0)
	_text_row(v, func(): return "Producción: %.2f u/s · Consumo tripulación: %.2f u/s · Fuga: %s" % [
		Sim.oxygen.last_production, Sim.config.crew_size * Sim.oxygen.CREW_USE, "ACTIVA" if Sim.oxygen.leak_active else "no"])
	_text_row(v, func(): return "Válvula de distribución: %s  ·  Potencia soporte vital: %.1f kW" % [Sim.oxygen.MODE_NAMES[Sim.oxygen.valve_mode], Sim.oxygen.power_demand()])
	var h := _btn_row(v)
	for m in 4:
		var mode: int = m
		_btn(h, "Válvula " + Sim.oxygen.MODE_NAMES[m].capitalize(), func(): Sim.oxygen.set_valve(mode))
	var h2 := _btn_row(v)
	_btn(h2, "Generador ON / OFF", func(): Sim.oxygen.toggle_generator())
	_btn(h2, "Mantenimiento generador (1 kit)", _kit_action(func(): Sim.oxygen.maintain_generator()))
	_btn(h2, "Sellar fuga (1 kit)", func():
		if Sim.oxygen.leak_active and Sim.use_kit():
			Sim.events.resolve("o2_leak"))


func _build_water() -> void:
	var v := _tab("Agua")
	_bar_row(v, "Reserva de agua", func(): return Sim.water.percent())
	_bar_row(v, "Estado del filtro", func(): return Sim.water.filter * 100.0)
	_text_row(v, func(): return "Reciclaje: %s · Recuperación: %.3f u/s · Total reciclado: %.1f u" % ["ACTIVO" if Sim.water.recycler_on else "INACTIVO", Sim.water.last_recycle, Sim.water.recycled_total])
	_text_row(v, func(): return "Consumo total acumulado: %.1f u · Fuga: %s" % [Sim.water.consumed_total, "ACTIVA" if Sim.water.leak_active else "no"])
	_text_row(v, func(): return "El reciclador consume %.1f kW; la electrólisis de O₂ y el invernadero también usan agua." % Sim.water.RECYCLER_POWER, UIStyle.DIM)
	var h := _btn_row(v)
	_btn(h, "Reciclador ON / OFF", func(): Sim.water.toggle_recycler())
	_btn(h, "Mantenimiento filtro (1 kit)", func():
		if Sim.water.filter < 0.95 and Sim.use_kit():
			if Sim.events.is_active("filter_clog"):
				Sim.events.resolve("filter_clog")
			else:
				Sim.water.maintain_filter())
	_btn(h, "Sellar fuga (1 kit)", func():
		if Sim.water.leak_active and Sim.use_kit():
			Sim.events.resolve("water_leak"))


func _build_food() -> void:
	var v := _tab("Alimentos")
	_bar_row(v, "Almacén de alimentos", func(): return Sim.food.percent())
	_bar_row(v, "Solución nutritiva", func(): return Sim.food.nutrients)
	_text_row(v, func(): return "Luces: %s · Cosechado: %.0f u · Consumido: %.1f u%s" % [
		"ON" if Sim.food.lights_on else "OFF", Sim.food.harvested_total, Sim.food.consumed_total,
		("  ·  DETENIDO: " + Sim.food.stalled_reason) if Sim.food.stalled_reason != "" else ""])
	for i in Sim.food.PLOTS:
		var idx: int = i
		var bar := UIStyle.progress(UIStyle.OK, 12.0)
		var l := UIStyle.label("", 13)
		var h := HBoxContainer.new()
		l.custom_minimum_size = Vector2(330, 0)
		h.add_child(l)
		bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(bar)
		v.add_child(h)
		_updaters.append(func():
			var p: Dictionary = Sim.food.plots[idx]
			var txt: String = "Bandeja %d — %s" % [idx + 1, Sim.food.STAGE_NAMES[p["stage"]]]
			if p["blight"]:
				txt += " (PLAGA)"
			l.text = txt
			l.add_theme_color_override("font_color", UIStyle.BAD if p["blight"] else UIStyle.TEXT)
			bar.value = 100.0 if p["stage"] == 4 else (float(p["stage"] - 1) + p["progress"]) / 3.0 * 100.0 if p["stage"] > 0 else 0.0)
	var h2 := _btn_row(v)
	_btn(h2, "Luces ON / OFF", func(): Sim.food.toggle_lights())
	_btn(h2, "Sembrar", func(): Sim.food.plant_all())
	_btn(h2, "Cosechar", func(): Sim.food.harvest_all())
	_btn(h2, "Tratar plaga (3 agua)", func():
		if Sim.food.blight_count() > 0 and Sim.water.reserve >= 3.0:
			Sim.water.draw(3.0)
			Sim.events.resolve("crop_blight"))
	_btn(h2, "Nutrientes (5 agua)", func():
		if not Sim.food.mix_nutrients():
			Sim.notify("Agua insuficiente para preparar nutrientes.", "bad"))


func _build_stats() -> void:
	var v := _tab("Estadísticas")
	var rt := RichTextLabel.new()
	rt.bbcode_enabled = true
	rt.fit_content = false
	rt.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rt.custom_minimum_size = Vector2(0, 360)
	v.add_child(rt)
	_updaters.append(func():
		var e = Sim.evaluation
		var t := "[color=#ffd133][b]RENDIMIENTO DE LA ESTACIÓN[/b][/color]\n"
		t += "Estabilidad actual: %d%%   (media %d%%)\n" % [int(e.stability()), int(e.avg_stability())]
		t += "Disponibilidad de recursos: %d%%   (media %d%%)\n" % [int(e.availability()), int(e.avg_availability())]
		t += "Tiempo de funcionamiento sin alertas críticas: %d%%\n" % int(e.uptime_percent())
		t += "Incidentes: %d (resueltos %d, activos %d) · tiempo medio de resolución %ds\n" % [
			Sim.events.total_incidents, Sim.events.resolved_incidents, Sim.events.active.size(), int(Sim.events.avg_resolution_time())]
		t += "Eficiencia energética: %d%% · Generado %.0f kWh · Consumido %.0f kWh\n" % [int(e.energy_efficiency()), Sim.power.energy_generated, Sim.power.energy_consumed]
		t += "Producción alimentaria: %d%% de la demanda cubierta (%.0f u cosechadas)\n" % [int(e.food_production_level()), Sim.food.harvested_total]
		t += "O₂ producido: %.1f u · Agua reciclada: %.1f u\n\n" % [Sim.oxygen.produced_total, Sim.water.recycled_total]
		t += "[color=#ffd133][b]REGISTRO DE MISIÓN[/b][/color]\n"
		var log: Array = Sim.mission_log
		for i in range(maxi(0, log.size() - 9), log.size()):
			t += log[i] + "\n"
		rt.text = t)
	var h := _btn_row(v)
	_btn(h, "Finalizar misión y ver informe", func():
		close()
		Sim.end_mission("MISIÓN FINALIZADA POR EL OPERADOR", true))


func _build_settings() -> void:
	var v := _tab("Config")
	_slider(v, "Velocidad de movimiento (m/s)", 1.0, 10.0, 0.5, Sim.config.move_speed, func(x): Sim.config.move_speed = x)
	_slider(v, "Sensibilidad del ratón", 1.0, 10.0, 0.5, Sim.config.mouse_sensitivity * 1000.0, func(x): Sim.config.mouse_sensitivity = x / 1000.0)
	_slider(v, "Velocidad de simulación (x)", 0.5, 4.0, 0.5, Sim.config.sim_speed, func(x): Sim.config.sim_speed = x)
	_slider(v, "Frecuencia de eventos (dificultad)", 0.5, 3.0, 0.5, Sim.config.difficulty, func(x): Sim.config.difficulty = x)
	v.add_child(UIStyle.label("Estos valores también pueden editarse en Resources/sim_config.tres.", 13, UIStyle.DIM))


func _slider(parent: Control, caption: String, mn: float, mx: float, step: float, val: float, on_change: Callable) -> void:
	var h := HBoxContainer.new()
	var cap := UIStyle.label(caption, 14, UIStyle.DIM)
	cap.custom_minimum_size = Vector2(300, 0)
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = val
	s.custom_minimum_size = Vector2(300, 24)
	s.focus_mode = Control.FOCUS_NONE
	var out := UIStyle.label("%.1f" % val, 14)
	s.value_changed.connect(func(x):
		out.text = "%.1f" % x
		on_change.call(x))
	h.add_child(cap)
	h.add_child(s)
	h.add_child(out)
	parent.add_child(h)
