extends Node3D
## Panel de interfaz en el mundo 3D para VR: un SubViewport con Controls se
## muestra en un quad con colisión (capa 4). El puntero láser de la mano
## derecha convierte el punto de impacto en eventos de ratón.

const LAYER_BIT := 8   # capa de colisión 4

var content: Control            # interfaz a mostrar (se asigna antes de añadir al árbol)
var size_px := Vector2i(900, 600)
var width_m: float = 1.5
var viewport: SubViewport
var _body: StaticBody3D
var _down: bool = false
var _last: Vector2 = Vector2.ZERO


func _ready() -> void:
	viewport = SubViewport.new()
	viewport.size = size_px
	viewport.transparent_bg = false
	viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(viewport)
	if content:
		viewport.add_child(content)
	var h: float = width_m * float(size_px.y) / float(size_px.x)
	var quad := MeshInstance3D.new()
	var qm := QuadMesh.new()
	qm.size = Vector2(width_m, h)
	quad.mesh = qm
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = viewport.get_texture()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	quad.material_override = mat
	add_child(quad)
	_body = StaticBody3D.new()
	_body.collision_layer = LAYER_BIT
	_body.collision_mask = 0
	_body.set_meta("vr_panel", self)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(width_m, h, 0.02)
	cs.shape = bs
	_body.add_child(cs)
	add_child(_body)
	hide_panel()


func show_in_front() -> void:
	var cam: Camera3D = get_viewport().get_camera_3d()
	if cam:
		var fwd: Vector3 = -cam.global_transform.basis.z
		fwd.y = 0.0
		fwd = fwd.normalized() if fwd.length() > 0.01 else Vector3.FORWARD
		var pos: Vector3 = cam.global_position + fwd * 1.1
		pos.y = cam.global_position.y - 0.1
		global_transform = Transform3D(Basis.looking_at(pos - cam.global_position, Vector3.UP), pos)
	visible = true
	_body.collision_layer = LAYER_BIT
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS


func hide_panel() -> void:
	visible = false
	if _body:
		_body.collision_layer = 0
	if viewport:
		viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	_down = false


func pointer_move(global_hit: Vector3) -> void:
	var local: Vector3 = to_local(global_hit)
	var h: float = width_m * float(size_px.y) / float(size_px.x)
	var px := Vector2((local.x / width_m + 0.5) * size_px.x, (0.5 - local.y / h) * size_px.y)
	var ev := InputEventMouseMotion.new()
	ev.position = px
	ev.global_position = px
	ev.relative = px - _last
	ev.button_mask = MOUSE_BUTTON_MASK_LEFT if _down else 0
	_last = px
	viewport.push_input(ev, true)


func pointer_button(pressed: bool) -> void:
	_down = pressed
	var ev := InputEventMouseButton.new()
	ev.button_index = MOUSE_BUTTON_LEFT
	ev.pressed = pressed
	ev.position = _last
	ev.global_position = _last
	ev.button_mask = MOUSE_BUTTON_MASK_LEFT if pressed else 0
	viewport.push_input(ev, true)
