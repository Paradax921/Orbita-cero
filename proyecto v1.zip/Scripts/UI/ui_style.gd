@tool
extends RefCounted
## Utilidades de estilo para la interfaz futurista (azul oscuro, celeste,
## blanco y detalles amarillos).

const BG := Color(0.02, 0.06, 0.13, 0.86)
const EDGE := Color(0.25, 0.7, 1.0, 0.9)
const TEXT := Color(0.86, 0.95, 1.0)
const DIM := Color(0.5, 0.65, 0.8)
const ACCENT := Color(1.0, 0.82, 0.2)
const OK := Color(0.25, 0.95, 0.55)
const WARN := Color(1.0, 0.8, 0.15)
const BAD := Color(1.0, 0.25, 0.2)


static func panel(bg: Color = BG, edge: Color = EDGE, border: int = 1, radius: int = 4) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = edge
	s.set_border_width_all(border)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 6
	s.content_margin_bottom = 6
	return s


static func bar_fill(color: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(2)
	return s


static func level_color(pct: float) -> Color:
	if pct <= 15.0:
		return BAD
	if pct <= 35.0:
		return WARN
	return OK


static func label(text: String, size: int = 14, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func progress(color: Color = EDGE, height: float = 14.0) -> ProgressBar:
	var b := ProgressBar.new()
	b.min_value = 0.0
	b.max_value = 100.0
	b.show_percentage = false
	b.custom_minimum_size = Vector2(120, height)
	b.add_theme_stylebox_override("background", panel(Color(0.03, 0.09, 0.18, 1.0), Color(0.2, 0.4, 0.6, 0.8), 1, 2))
	b.add_theme_stylebox_override("fill", bar_fill(color))
	return b


static func set_bar(b: ProgressBar, pct: float, color: Color) -> void:
	b.value = clampf(pct, 0.0, 100.0)
	b.add_theme_stylebox_override("fill", bar_fill(color))


static func button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 14)
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_stylebox_override("normal", panel(Color(0.05, 0.15, 0.3, 0.95), EDGE, 1, 3))
	b.add_theme_stylebox_override("hover", panel(Color(0.1, 0.3, 0.55, 1.0), Color(0.6, 0.9, 1.0), 1, 3))
	b.add_theme_stylebox_override("pressed", panel(Color(0.9, 0.7, 0.1, 0.9), ACCENT, 1, 3))
	b.add_theme_stylebox_override("disabled", panel(Color(0.05, 0.08, 0.12, 0.8), Color(0.2, 0.3, 0.4), 1, 3))
	return b
