extends CanvasLayer
## INTERFAZ DE USUARIO COMPLETA — SPACE CONTI
## Gestiona:
## 1. Pantalla de Bienvenida con atribución de datos NASA (DONKI, OSDR, Artemis).
## 2. HUD en vivo (4 barras de recursos, ciclo/sol, alertas visuales de hambre/asfixia/radiación).
## 3. Tarjeta 2D contextual didáctica para módulos 3D (alto contraste, nunca se corta).
## 4. Ventana modal con el Minijuego de Calibración de Frecuencia.
## 5. Pantalla de Muerte / Rejugabilidad Roguelike con explicación científica pedagógica.

const UIStyle = preload("res://Scripts/UI/ui_style.gd")

# Paneles principales
var start_screen: Control
var hud_root: Control
var minigame_modal: Control
var death_screen: Control
var blackout_rect: ColorRect
var module_card_panel: PanelContainer

# Elementos del HUD
var bar_energy: ProgressBar
var bar_oxygen: ProgressBar
var bar_food: ProgressBar
var bar_shield: ProgressBar
var label_cycle: Label
var label_alerts: Label

# Notificaciones y feedback visual de recursos
const COLOR_ENERGY := Color(1.0, 0.85, 0.2)
const COLOR_OXYGEN := Color(0.2, 0.85, 1.0)
const COLOR_FOOD := Color(0.3, 0.9, 0.35)
const COLOR_SHIELD := Color(0.85, 0.35, 1.0)

var _prev_energy: float = 100.0
var _prev_oxygen: float = 100.0
var _prev_food: float = 100.0
var _prev_shield: float = 100.0

var hud_notice_panel: PanelContainer
var hud_notice_label: Label
var _notice_tween: Tween

# Modales Roguelike y Eventos NASA
var perk_modal: Control
var perk_cards_container: HBoxContainer
var perk_cycle_title: Label

var crisis_modal: Control
var crisis_title_label: Label
var crisis_badge_label: Label
var crisis_desc_label: Label
var crisis_kids_label: Label
var crisis_btn_a: Button
var crisis_btn_b: Button
var current_active_crisis: Dictionary = {}

# Barra de Telemetría Houston / DSN
var dsn_modal: Control
var dsn_bar: ProgressBar
var dsn_info_label: Label
var _dsn_tween: Tween

# Contenedor de Parches en Pantalla de Muerte / Victoria
var badges_container: HBoxContainer

# Reproductor de Sonidos Sintéticos
var sfx_player: AudioStreamPlayer

# Elementos de la Tarjeta Contextual 2D de Módulo
var module_card_title: Label
var module_card_fact: Label
var module_card_source: Label
var module_card_tradeoff: Label
var current_context_module: Node = null

# Elementos de Inicio
var btn_start: Button

# Elementos del Minijuego
var minigame_active: bool = false
var current_module: Node = null
var needle_value: float = 0.0
var needle_speed: float = 2.4
var needle_dir: float = 1.0
var minigame_bar: ProgressBar
var minigame_status_label: Label
var minigame_needle_marker: ColorRect

# Elementos de Pantalla de Derrota
var death_title: Label
var death_reason: Label
var death_science_tip: Label


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_ui()
	
	GameManager.resources_changed.connect(_on_resources_changed)
	GameManager.day_cycle_advanced.connect(_on_cycle_advanced)
	GameManager.player_died.connect(_on_player_died)
	GameManager.debuff_changed.connect(_on_debuff_changed)
	GameManager.notification_sent.connect(_on_notification_sent)
	GameManager.perk_selection_requested.connect(_on_perk_selection_requested)
	GameManager.crisis_triggered.connect(_on_crisis_triggered)
	GameManager.houston_transmission_started.connect(_on_houston_transmission_started)
	GameManager.houston_transmission_completed.connect(_on_houston_transmission_completed)
	
	# Mostrar Panel de Inicio "SPACE CONTI" pausando el drenaje de recursos hasta pulsar "INICIAR MISIÓN"
	GameManager.is_game_active = false
	_show_start_screen()


func _build_ui() -> void:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	
	sfx_player = AudioStreamPlayer.new()
	add_child(sfx_player)
	
	# Viñeta negra para micro-desmayos por asfixia
	blackout_rect = ColorRect.new()
	blackout_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	blackout_rect.color = Color(0, 0, 0, 0)
	blackout_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(blackout_rect)
	
	_build_hud(root)
	_build_module_card_panel(root)
	_build_minigame(root)
	_build_dsn_telemetry_ui(root)
	_build_crisis_modal(root)
	_build_perk_modal(root)
	_build_start_screen(root)
	_build_death_screen(root)


# ==============================================================================
# 1. PANTALLA DE INICIO (SPACE CONTI)
# ==============================================================================

func _build_start_screen(parent: Control) -> void:
	start_screen = PanelContainer.new()
	start_screen.set_anchors_preset(Control.PRESET_CENTER)
	start_screen.custom_minimum_size = Vector2(720, 480)
	start_screen.grow_horizontal = Control.GROW_DIRECTION_BOTH
	start_screen.grow_vertical = Control.GROW_DIRECTION_BOTH
	
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.08, 0.16, 0.95)
	sb.border_color = Color(0.25, 0.7, 1.0, 0.9)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(24)
	start_screen.add_theme_stylebox_override("panel", sb)
	parent.add_child(start_screen)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	start_screen.add_child(vbox)
	
	var title := UIStyle.label("★ SPACE CONTI ★", 34, UIStyle.ACCENT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	
	var subtitle := UIStyle.label("Junior Astronaut Mission Trainer · NASA Space Apps 2026", 15, UIStyle.OK)
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(subtitle)
	
	var desc := UIStyle.label(
		"¡Bienvenido a la Base Lunar Artemis!\n\n" +
		"Como futuro astronauta de la NASA (7 a 12 años), tu misión es mantener en equilibrio los 4 recursos vitales: " +
		"ENERGÍA, OXÍGENO, COMIDA y ESCUDO DE RADIACIÓN.\n\n" +
		"• WASD para moverte y Ratón para mirar.\n" +
		"• Acércate a los módulos interactivos y presiona [E] para calibrarlos.\n" +
		"• ¡Ninguna decisión es gratis! Todo beneficio exige un coste de recursos.",
		14
	)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(desc)
	
	var nasa_box := PanelContainer.new()
	var n_sb := StyleBoxFlat.new()
	n_sb.bg_color = Color(0.06, 0.14, 0.28, 0.85)
	n_sb.border_color = Color(0.3, 0.6, 0.9, 0.5)
	n_sb.set_border_width_all(1)
	n_sb.set_corner_radius_all(6)
	n_sb.set_content_margin_all(10)
	nasa_box.add_theme_stylebox_override("panel", n_sb)
	
	var nasa_lbl := UIStyle.label(
		"🔬 FUNDAMENTO CIENTÍFICO REAL:\n" +
		"Simulación impulsada por datos abiertos de NASA DONKI (Clima Espacial), " +
		"NASA OSDR (Biología y Cultivos VEGGIE) y el Programa Artemis.",
		12, UIStyle.TEXT
	)
	nasa_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	nasa_box.add_child(nasa_lbl)
	vbox.add_child(nasa_box)
	
	btn_start = Button.new()
	btn_start.text = "🚀 INICIAR MISIÓN [ESPACIO]"
	btn_start.custom_minimum_size = Vector2(280, 48)
	btn_start.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	btn_start.pressed.connect(_on_start_pressed)
	vbox.add_child(btn_start)


func _show_start_screen() -> void:
	start_screen.visible = true
	Sim.ui_blocking = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if btn_start:
		btn_start.grab_focus()


func _on_start_pressed() -> void:
	start_screen.visible = false
	Sim.ui_blocking = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	GameManager.start_game()


# ==============================================================================
# 2. HUD EN PARTIDA (4 RECURSOS Y ALERTAS)
# ==============================================================================

func _build_hud(parent: Control) -> void:
	hud_root = Control.new()
	hud_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(hud_root)
	
	var top := PanelContainer.new()
	top.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.01, 0.04, 0.1, 0.85)))
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 14
	top.offset_right = -14
	top.offset_top = 10
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_root.add_child(top)
	
	var hbar := HBoxContainer.new()
	hbar.add_theme_constant_override("separation", 14)
	hbar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(hbar)
	
	bar_energy = _create_resource_bar(hbar, "⚡ ENERGÍA", Color(1.0, 0.85, 0.2))
	bar_oxygen = _create_resource_bar(hbar, "💨 OXÍGENO", Color(0.2, 0.85, 1.0))
	bar_food = _create_resource_bar(hbar, "🌱 COMIDA", Color(0.3, 0.9, 0.35))
	bar_shield = _create_resource_bar(hbar, "🛡️ ESCUDO (DONKI)", Color(0.85, 0.35, 1.0))
	
	var cycle_box := VBoxContainer.new()
	cycle_box.custom_minimum_size = Vector2(170, 0)
	cycle_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label_cycle = UIStyle.label("SOL 1 / 14", 20, UIStyle.ACCENT)
	label_alerts = UIStyle.label("SISTEMAS NOMINALES", 12, UIStyle.OK)
	cycle_box.add_child(label_cycle)
	cycle_box.add_child(label_alerts)
	hbar.add_child(cycle_box)
	
	# Banner superior para mensajes grandes de calibración y alertas
	hud_notice_panel = PanelContainer.new()
	hud_notice_panel.set_anchors_preset(Control.PRESET_TOP_WIDE)
	hud_notice_panel.offset_left = 60
	hud_notice_panel.offset_right = -60
	hud_notice_panel.offset_top = 80
	hud_notice_panel.offset_bottom = 126
	hud_notice_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	
	var n_sb := StyleBoxFlat.new()
	n_sb.bg_color = Color(0.05, 0.08, 0.16, 0.94)
	n_sb.border_color = Color(1.0, 0.25, 0.25, 0.9)
	n_sb.set_border_width_all(2)
	n_sb.set_corner_radius_all(6)
	n_sb.set_content_margin_all(8)
	hud_notice_panel.add_theme_stylebox_override("panel", n_sb)
	hud_notice_panel.visible = false
	hud_root.add_child(hud_notice_panel)
	
	hud_notice_label = UIStyle.label("", 16, UIStyle.TEXT)
	hud_notice_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_notice_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hud_notice_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hud_notice_panel.add_child(hud_notice_label)


func _create_resource_bar(parent: HBoxContainer, title_text: String, bar_color: Color) -> ProgressBar:
	var pc := PanelContainer.new()
	pc.custom_minimum_size = Vector2(175, 0)
	pc.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.03, 0.09, 0.18, 0.8)))
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(pc)
	
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.add_child(vb)
	
	var lbl := UIStyle.label(title_text, 12, UIStyle.DIM)
	vb.add_child(lbl)
	
	var pb := ProgressBar.new()
	pb.custom_minimum_size = Vector2(0, 16)
	pb.max_value = 100.0
	pb.value = 100.0
	pb.show_percentage = true
	var sb := StyleBoxFlat.new()
	sb.bg_color = bar_color
	sb.set_corner_radius_all(3)
	pb.add_theme_stylebox_override("fill", sb)
	vb.add_child(pb)
	
	return pb


# ==============================================================================
# 3. TARJETA DIDÁCTICA 2D CONTEXTUAL (HUD LIMPIO DE ALTO CONTRASTE)
# ==============================================================================

func _build_module_card_panel(parent: Control) -> void:
	module_card_panel = PanelContainer.new()
	module_card_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	module_card_panel.custom_minimum_size = Vector2(620, 150)
	module_card_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	module_card_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	module_card_panel.offset_bottom = -70
	module_card_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	
	# Fondo oscuro de alto contraste con bordes redondeados
	var card_sb := StyleBoxFlat.new()
	card_sb.bg_color = Color(0.05, 0.08, 0.14, 0.88)
	card_sb.border_color = Color(0.25, 0.7, 1.0, 0.88)
	card_sb.set_border_width_all(2)
	card_sb.set_corner_radius_all(8)
	card_sb.set_content_margin_all(14)
	module_card_panel.add_theme_stylebox_override("panel", card_sb)
	module_card_panel.visible = false
	parent.add_child(module_card_panel)
	
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	module_card_panel.add_child(vb)
	
	var hb_top := HBoxContainer.new()
	hb_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(hb_top)
	
	module_card_title = UIStyle.label("Nombre del Módulo", 16, UIStyle.ACCENT)
	module_card_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb_top.add_child(module_card_title)
	
	var prompt_badge := UIStyle.label("Presiona [E] para Calibrar", 13, UIStyle.OK)
	hb_top.add_child(prompt_badge)
	
	module_card_fact = UIStyle.label("Explicación científica de la NASA...", 13, UIStyle.TEXT)
	module_card_fact.autowrap_mode = TextServer.AUTOWRAP_WORD
	module_card_fact.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(module_card_fact)
	
	var hb_bot := HBoxContainer.new()
	hb_bot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(hb_bot)
	
	module_card_source = UIStyle.label("Fuente: NASA OSDR", 11, UIStyle.DIM)
	module_card_source.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb_bot.add_child(module_card_source)
	
	module_card_tradeoff = UIStyle.label("Intercambio: -15 E / +25 O₂", 12, UIStyle.WARN)
	hb_bot.add_child(module_card_tradeoff)


func show_module_card(module_node: Node) -> void:
	if minigame_active:
		return
	current_context_module = module_node
	module_card_title.text = "✦ %s ✦" % module_node.module_title
	module_card_fact.text = module_node.nasa_fact
	module_card_source.text = "Fuente NASA: %s" % module_node.nasa_source
	module_card_tradeoff.text = "Intercambio: %s" % module_node.cost_benefit_text
	module_card_panel.visible = true


func hide_module_card(module_node: Node) -> void:
	if current_context_module == module_node:
		current_context_module = null
		module_card_panel.visible = false


# ==============================================================================
# 4. MINIJUEGO DE CALIBRACIÓN DE FRECUENCIA
# ==============================================================================

func _build_minigame(parent: Control) -> void:
	minigame_modal = PanelContainer.new()
	minigame_modal.set_anchors_preset(Control.PRESET_CENTER)
	minigame_modal.custom_minimum_size = Vector2(560, 340)
	minigame_modal.grow_horizontal = Control.GROW_DIRECTION_BOTH
	minigame_modal.grow_vertical = Control.GROW_DIRECTION_BOTH
	
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.09, 0.2, 0.95)
	sb.border_color = Color(0.25, 0.7, 1.0, 0.9)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(20)
	minigame_modal.add_theme_stylebox_override("panel", sb)
	minigame_modal.visible = false
	parent.add_child(minigame_modal)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	minigame_modal.add_child(vbox)
	
	var title := UIStyle.label("⚡ CALIBRACIÓN DE FRECUENCIA ⚡", 22, UIStyle.ACCENT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	
	minigame_status_label = UIStyle.label(
		"Detén la aguja dentro de la ZONA VERDE (40% - 60%) presionando [ESPACIO] o [CLIC].",
		14
	)
	minigame_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	minigame_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(minigame_status_label)
	
	var bar_container := Control.new()
	bar_container.custom_minimum_size = Vector2(460, 48)
	bar_container.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vbox.add_child(bar_container)
	
	minigame_bar = ProgressBar.new()
	minigame_bar.custom_minimum_size = Vector2(460, 32)
	minigame_bar.max_value = 100.0
	minigame_bar.value = 100.0
	minigame_bar.show_percentage = false
	var bg_sb := StyleBoxFlat.new()
	bg_sb.bg_color = Color(0.1, 0.2, 0.3)
	minigame_bar.add_theme_stylebox_override("background", bg_sb)
	bar_container.add_child(minigame_bar)
	
	# Zona verde de éxito central (40% a 60%)
	var green_zone := ColorRect.new()
	green_zone.position = Vector2(460.0 * 0.40, 0)
	green_zone.size = Vector2(460.0 * 0.20, 32)
	green_zone.color = Color(0.2, 0.9, 0.4, 0.75)
	bar_container.add_child(green_zone)
	
	# Aguja marcadora roja
	minigame_needle_marker = ColorRect.new()
	minigame_needle_marker.position = Vector2(0, -6)
	minigame_needle_marker.size = Vector2(8, 44)
	minigame_needle_marker.color = Color(1.0, 0.25, 0.2)
	bar_container.add_child(minigame_needle_marker)
	
	var btn_calibrate := Button.new()
	btn_calibrate.text = "🎯 FIJAR FRECUENCIA [ESPACIO]"
	btn_calibrate.custom_minimum_size = Vector2(240, 44)
	btn_calibrate.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	btn_calibrate.pressed.connect(_on_minigame_action)
	vbox.add_child(btn_calibrate)


func start_calibration_minigame(module_ref: Node) -> void:
	current_module = module_ref
	minigame_active = true
	needle_value = 0.0
	needle_dir = 1.0
	minigame_modal.visible = true
	module_card_panel.visible = false
	Sim.ui_blocking = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	minigame_status_label.text = "Calibrando: %s\nPresiona ESPACIO o haz Clic cuando la aguja esté en la ZONA VERDE." % module_ref.module_title


func _on_minigame_action() -> void:
	if not minigame_active or current_module == null:
		return
		
	minigame_active = false
	var success: bool = needle_value >= 0.38 and needle_value <= 0.62
	
	minigame_modal.visible = false
	Sim.ui_blocking = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	
	current_module.apply_calibration_effect(success)
	current_module = null


func _unhandled_input(event: InputEvent) -> void:
	if perk_modal and perk_modal.visible:
		return
	if crisis_modal and crisis_modal.visible:
		return
	if minigame_active:
		if event.is_action_pressed("ui_accept"):
			_on_minigame_action()
		elif event.is_action_pressed("ui_cancel"):
			_cancel_minigame()
	elif start_screen and start_screen.visible:
		if (event is InputEventMouseButton and event.pressed) or event.is_action_pressed("ui_accept") or event.is_action_pressed("toggle_cursor"):
			_on_start_pressed()


func _cancel_minigame() -> void:
	minigame_active = false
	minigame_modal.visible = false
	Sim.ui_blocking = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	current_module = null


# ==============================================================================
# MODALES ROGUELIKE: MEJORAS / MUTADORES ENTRE SOLES (PERKS)
# ==============================================================================

func _build_perk_modal(parent: Control) -> void:
	perk_modal = PanelContainer.new()
	perk_modal.set_anchors_preset(Control.PRESET_CENTER)
	perk_modal.custom_minimum_size = Vector2(980, 500)
	perk_modal.grow_horizontal = Control.GROW_DIRECTION_BOTH
	perk_modal.grow_vertical = Control.GROW_DIRECTION_BOTH
	
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.07, 0.15, 0.97)
	sb.border_color = Color(0.25, 0.7, 1.0, 0.95)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(20)
	perk_modal.add_theme_stylebox_override("panel", sb)
	perk_modal.visible = false
	parent.add_child(perk_modal)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	perk_modal.add_child(vbox)
	
	perk_cycle_title = UIStyle.label("★ FIN DEL SOL — ELIGE 1 TECNOLOGÍA O MUTADOR NASA ★", 22, UIStyle.ACCENT)
	perk_cycle_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(perk_cycle_title)
	
	var subtitle := UIStyle.label("Adapta tu base lunar con investigaciones científicas reales de NASA Artemis, OSDR y Glenn.", 13, UIStyle.OK)
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(subtitle)
	
	perk_cards_container = HBoxContainer.new()
	perk_cards_container.add_theme_constant_override("separation", 16)
	perk_cards_container.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(perk_cards_container)


func _on_perk_selection_requested(perks: Array) -> void:
	if perks.is_empty():
		return
	perk_cycle_title.text = "★ SOL %d SUPERADO — ELIGE 1 MEJORA TECNOLÓGICA NASA ★" % (GameManager.day_cycle - 1)
	
	for c in perk_cards_container.get_children():
		c.queue_free()
		
	for perk in perks:
		var card := _create_perk_card(perk)
		perk_cards_container.add_child(card)
		
	perk_modal.visible = true
	Sim.ui_blocking = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	play_sfx_success()


func _create_perk_card(perk: Dictionary) -> Control:
	var pc := PanelContainer.new()
	pc.custom_minimum_size = Vector2(290, 360)
	pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.12, 0.22, 0.95)
	sb.border_color = Color(0.3, 0.65, 0.9, 0.8)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(14)
	pc.add_theme_stylebox_override("panel", sb)
	
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	pc.add_child(vb)
	
	var cat := UIStyle.label("[%s]" % perk.get("category", "Tecnología Lunar"), 11, UIStyle.DIM)
	vb.add_child(cat)
	
	var title := UIStyle.label(perk.get("title", "Mejora"), 15, UIStyle.ACCENT)
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(title)
	
	var desc := UIStyle.label(perk.get("description", ""), 12, UIStyle.TEXT)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(desc)
	
	var pro := UIStyle.label("✔ " + perk.get("pros", ""), 12, Color(0.3, 0.95, 0.45))
	pro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(pro)
	
	var con := UIStyle.label("✖ " + perk.get("cons", ""), 12, Color(1.0, 0.45, 0.35))
	con.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(con)
	
	var src := UIStyle.label("Fuente: " + perk.get("nasa_source", "NASA"), 10, UIStyle.DIM)
	src.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(src)
	
	var btn := Button.new()
	btn.text = "⚡ EQUIPAR MEJORA"
	btn.custom_minimum_size = Vector2(0, 38)
	btn.pressed.connect(func(): _on_perk_card_selected(perk))
	vb.add_child(btn)
	
	return pc


func _on_perk_card_selected(perk: Dictionary) -> void:
	perk_modal.visible = false
	Sim.ui_blocking = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var em = get_node_or_null("/root/EventManager")
	if em and em.has_method("apply_chosen_perk"):
		em.apply_chosen_perk(perk)
	play_sfx_success()


# ==============================================================================
# MODAL DE CRISIS ESPACIALES (DONKI / OSDR / ARTEMIS)
# ==============================================================================

func _build_crisis_modal(parent: Control) -> void:
	crisis_modal = PanelContainer.new()
	crisis_modal.set_anchors_preset(Control.PRESET_CENTER)
	crisis_modal.custom_minimum_size = Vector2(740, 480)
	crisis_modal.grow_horizontal = Control.GROW_DIRECTION_BOTH
	crisis_modal.grow_vertical = Control.GROW_DIRECTION_BOTH
	
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.12, 0.04, 0.05, 0.97)
	sb.border_color = Color(1.0, 0.3, 0.25, 0.95)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(20)
	crisis_modal.add_theme_stylebox_override("panel", sb)
	crisis_modal.visible = false
	parent.add_child(crisis_modal)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	crisis_modal.add_child(vbox)
	
	var top_hdr := UIStyle.label("⚠️ ALERTA DE CLIMA ESPACIAL (NASA DONKI / OSDR) ⚠️", 22, UIStyle.BAD)
	top_hdr.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(top_hdr)
	
	crisis_badge_label = UIStyle.label("[DONKI · Radiación Solar]", 12, UIStyle.WARN)
	crisis_badge_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(crisis_badge_label)
	
	crisis_title_label = UIStyle.label("Título de la Crisis", 18, UIStyle.ACCENT)
	crisis_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(crisis_title_label)
	
	crisis_desc_label = UIStyle.label("Descripción del evento...", 13, UIStyle.TEXT)
	crisis_desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(crisis_desc_label)
	
	var k_box := PanelContainer.new()
	var k_sb := StyleBoxFlat.new()
	k_sb.bg_color = Color(0.18, 0.07, 0.08, 0.9)
	k_sb.border_color = Color(1.0, 0.5, 0.3, 0.6)
	k_sb.set_border_width_all(1)
	k_sb.set_corner_radius_all(6)
	k_sb.set_content_margin_all(10)
	k_box.add_theme_stylebox_override("panel", k_sb)
	
	crisis_kids_label = UIStyle.label("¿Sabías que...? Explicación educativa para jóvenes astronautas.", 12, Color(1.0, 0.9, 0.75))
	crisis_kids_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	k_box.add_child(crisis_kids_label)
	vbox.add_child(k_box)
	
	var act_hdr := UIStyle.label("DECISIÓN DE CONTINGENCIA (TOMA DE CONTROL):", 13, UIStyle.DIM)
	vbox.add_child(act_hdr)
	
	crisis_btn_a = Button.new()
	crisis_btn_a.custom_minimum_size = Vector2(0, 44)
	crisis_btn_a.pressed.connect(func(): _on_crisis_option_chosen(0))
	vbox.add_child(crisis_btn_a)
	
	crisis_btn_b = Button.new()
	crisis_btn_b.custom_minimum_size = Vector2(0, 44)
	crisis_btn_b.pressed.connect(func(): _on_crisis_option_chosen(1))
	vbox.add_child(crisis_btn_b)


func _on_crisis_triggered(crisis: Dictionary) -> void:
	current_active_crisis = crisis
	crisis_badge_label.text = "[%s]" % crisis.get("badge", crisis.get("category", "Clima Espacial"))
	crisis_title_label.text = crisis.get("title", "Alerta de Misión")
	crisis_desc_label.text = crisis.get("description", "")
	crisis_kids_label.text = "💡 ¿SABÍAS QUE?\n" + crisis.get("kids_explanation", "")
	
	var options: Array = crisis.get("options", [])
	if options.size() > 0:
		var opt0 = options[0]
		crisis_btn_a.text = "Opción A: %s (%s)" % [opt0.get("text", ""), opt0.get("tradeoff", "")]
		crisis_btn_a.visible = true
	else:
		crisis_btn_a.visible = false
		
	if options.size() > 1:
		var opt1 = options[1]
		crisis_btn_b.text = "Opción B: %s (%s)" % [opt1.get("text", ""), opt1.get("tradeoff", "")]
		crisis_btn_b.visible = true
	else:
		crisis_btn_b.visible = false
		
	crisis_modal.visible = true
	Sim.ui_blocking = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	play_sfx_crisis()


func _on_crisis_option_chosen(choice_idx: int) -> void:
	crisis_modal.visible = false
	Sim.ui_blocking = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	
	var em = get_node_or_null("/root/EventManager")
	if em and em.has_method("resolve_crisis"):
		em.resolve_crisis(current_active_crisis.get("id", ""), choice_idx)
	current_active_crisis = {}
	play_sfx_success()


# ==============================================================================
# BARRA DE TELEMETRÍA DEEP SPACE NETWORK (DSN - HOUSTON)
# ==============================================================================

func _build_dsn_telemetry_ui(parent: Control) -> void:
	dsn_modal = PanelContainer.new()
	dsn_modal.set_anchors_preset(Control.PRESET_TOP_WIDE)
	dsn_modal.offset_left = 140
	dsn_modal.offset_right = -140
	dsn_modal.offset_top = 75
	dsn_modal.offset_bottom = 150
	
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.08, 0.18, 0.95)
	sb.border_color = Color(0.3, 0.8, 1.0, 0.9)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(10)
	dsn_modal.add_theme_stylebox_override("panel", sb)
	dsn_modal.visible = false
	dsn_modal.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(dsn_modal)
	
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	dsn_modal.add_child(vb)
	
	var title := UIStyle.label("📡 ENLACE DEEP SPACE NETWORK (DSN) · TIERRA <-> LUNA · 384,400 KM", 13, UIStyle.ACCENT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)
	
	dsn_info_label = UIStyle.label("Transmitiendo a la velocidad de la luz (Latencia real de señal: 1.3 s)...", 12, UIStyle.OK)
	dsn_info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(dsn_info_label)
	
	dsn_bar = ProgressBar.new()
	dsn_bar.custom_minimum_size = Vector2(0, 16)
	dsn_bar.max_value = 100.0
	dsn_bar.value = 0.0
	dsn_bar.show_percentage = true
	var b_sb := StyleBoxFlat.new()
	b_sb.bg_color = Color(0.2, 0.8, 1.0)
	b_sb.set_corner_radius_all(3)
	dsn_bar.add_theme_stylebox_override("fill", b_sb)
	vb.add_child(dsn_bar)


func _on_houston_transmission_started(duration: float) -> void:
	dsn_modal.visible = true
	dsn_bar.value = 0.0
	dsn_info_label.text = "Transmitiendo a la velocidad de la luz (Latencia real de señal: 1.3 s)..."
	play_sfx_radio()
	
	if _dsn_tween and _dsn_tween.is_valid():
		_dsn_tween.kill()
	_dsn_tween = create_tween()
	_dsn_tween.tween_property(dsn_bar, "value", 100.0, duration)


func _on_houston_transmission_completed() -> void:
	dsn_info_label.text = "🛰️ ¡ENLACE EXITOSO! Telemetría de soporte vital recibida (+20 O₂, +20 Escudo)"
	play_sfx_success()
	await get_tree().create_timer(1.2).timeout
	if dsn_modal:
		dsn_modal.visible = false


# ==============================================================================
# REPRODUCTOR DE SONIDOS SINTÉTICOS PROCEDURALES
# ==============================================================================

func _play_tone(freq: float, duration: float, type: String = "sine") -> void:
	var sample_rate: int = 22050
	var num_samples: int = int(sample_rate * duration)
	var data := PackedByteArray()
	data.resize(num_samples)
	for i in range(num_samples):
		var t: float = float(i) / float(sample_rate)
		var val: float = 0.0
		if type == "square":
			val = 0.7 if sin(TAU * freq * t) > 0.0 else -0.7
		elif type == "saw":
			val = (fmod(t * freq, 1.0) * 2.0 - 1.0) * 0.6
		else:
			val = sin(TAU * freq * t) * 0.8
		var env: float = clampf(1.0 - (float(i) / float(num_samples)), 0.0, 1.0)
		var sample_val: int = clampi(int(val * env * 127.0) + 128, 0, 255)
		data[i] = sample_val
	
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_8_BITS
	stream.mix_rate = sample_rate
	stream.data = data
	
	if sfx_player:
		sfx_player.stream = stream
		sfx_player.play()


func play_sfx_success() -> void:
	_play_tone(660.0, 0.25, "sine")


func play_sfx_error() -> void:
	_play_tone(140.0, 0.35, "square")


func play_sfx_crisis() -> void:
	_play_tone(420.0, 0.45, "saw")


func play_sfx_radio() -> void:
	_play_tone(880.0, 0.16, "sine")


# ==============================================================================
# 5. PANTALLA DE DERROTA / REJUGABILIDAD EDUCATIVA
# ==============================================================================

func _build_death_screen(parent: Control) -> void:
	death_screen = PanelContainer.new()
	death_screen.set_anchors_preset(Control.PRESET_CENTER)
	death_screen.custom_minimum_size = Vector2(700, 460)
	death_screen.grow_horizontal = Control.GROW_DIRECTION_BOTH
	death_screen.grow_vertical = Control.GROW_DIRECTION_BOTH
	
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.02, 0.02, 0.96)
	sb.border_color = Color(1.0, 0.25, 0.2, 0.9)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(8)
	sb.set_content_margin_all(20)
	death_screen.add_theme_stylebox_override("panel", sb)
	death_screen.visible = false
	parent.add_child(death_screen)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	death_screen.add_child(vbox)
	
	death_title = UIStyle.label("MISIÓN FALLIDA — INFORME DE TELEMETRÍA", 24, UIStyle.BAD)
	death_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(death_title)
	
	death_reason = UIStyle.label("Causa del fallo", 16, UIStyle.WARN)
	death_reason.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(death_reason)
	
	var tip_box := PanelContainer.new()
	var t_sb := StyleBoxFlat.new()
	t_sb.bg_color = Color(0.12, 0.04, 0.04, 0.85)
	t_sb.set_border_width_all(1)
	t_sb.set_corner_radius_all(6)
	t_sb.set_content_margin_all(12)
	tip_box.add_theme_stylebox_override("panel", t_sb)
	death_science_tip = UIStyle.label("Explicación científica de la NASA", 14)
	death_science_tip.autowrap_mode = TextServer.AUTOWRAP_WORD
	tip_box.add_child(death_science_tip)
	vbox.add_child(tip_box)
	
	var badges_header := UIStyle.label("🏅 PARCHES Y LOGROS DE MISIÓN OBTENIDOS:", 13, UIStyle.ACCENT)
	badges_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(badges_header)
	
	badges_container = HBoxContainer.new()
	badges_container.alignment = BoxContainer.ALIGNMENT_CENTER
	badges_container.add_theme_constant_override("separation", 10)
	vbox.add_child(badges_container)
	
	var btn_retry := Button.new()
	btn_retry.text = "🔄 NUEVA PARTIDA (NUEVO CICLO ROGUELIKE)"
	btn_retry.custom_minimum_size = Vector2(300, 48)
	btn_retry.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	btn_retry.pressed.connect(_on_restart_pressed)
	vbox.add_child(btn_retry)


func _on_player_died(reason: String, explanation: String) -> void:
	death_title.text = "¡MISIÓN CUMPLIDA!" if "Éxito" in reason else "MISIÓN FALLIDA — INFORME DE LA NASA"
	death_reason.text = reason
	death_science_tip.text = "¿CÓMO LO RESUELVE LA NASA EN LA VIDA REAL?\n\n" + explanation
	
	# Mostrar parches obtenidos en la misión
	if badges_container:
		for c in badges_container.get_children():
			c.queue_free()
		for b_id in GameManager.unlocked_badges.keys():
			var b_info: Dictionary = GameManager.unlocked_badges[b_id]
			var pc := PanelContainer.new()
			var b_sb := StyleBoxFlat.new()
			b_sb.bg_color = Color(0.12, 0.16, 0.25, 0.95)
			b_sb.border_color = Color(1.0, 0.85, 0.25, 0.85)
			b_sb.set_border_width_all(1)
			b_sb.set_corner_radius_all(6)
			b_sb.set_content_margin_all(8)
			pc.add_theme_stylebox_override("panel", b_sb)
			
			var vb := VBoxContainer.new()
			pc.add_child(vb)
			var ico := UIStyle.label(b_info.get("icon", "🏅"), 20)
			ico.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			vb.add_child(ico)
			var tit := UIStyle.label(b_info.get("title", ""), 11, UIStyle.ACCENT)
			tit.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			vb.add_child(tit)
			badges_container.add_child(pc)
			
	module_card_panel.visible = false
	minigame_modal.visible = false
	if perk_modal: perk_modal.visible = false
	if crisis_modal: crisis_modal.visible = false
	if dsn_modal: dsn_modal.visible = false
	death_screen.visible = true
	Sim.ui_blocking = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	play_sfx_error()


func _on_restart_pressed() -> void:
	death_screen.visible = false
	Sim.ui_blocking = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	GameManager.start_game()


# ==============================================================================
# PROCESO Y ACTUALIZACIONES
# ==============================================================================

func _on_resources_changed(e: float, ox: float, fd: float, sh: float) -> void:
	if bar_energy:
		bar_energy.value = e
		if e < _prev_energy - 3.0:
			_flash_bar(bar_energy, COLOR_ENERGY)
	if bar_oxygen:
		bar_oxygen.value = ox
		if ox < _prev_oxygen - 3.0:
			_flash_bar(bar_oxygen, COLOR_OXYGEN)
	if bar_food:
		bar_food.value = fd
		if fd < _prev_food - 3.0:
			_flash_bar(bar_food, COLOR_FOOD)
	if bar_shield:
		bar_shield.value = sh
		if sh < _prev_shield - 3.0:
			_flash_bar(bar_shield, COLOR_SHIELD)
			
	_prev_energy = e
	_prev_oxygen = ox
	_prev_food = fd
	_prev_shield = sh


func _on_notification_sent(message: String, color: Color) -> void:
	if not hud_notice_panel or not hud_notice_label:
		return
	hud_notice_label.text = message
	hud_notice_label.add_theme_color_override("font_color", color)
	
	var sb := hud_notice_panel.get_theme_stylebox("panel") as StyleBoxFlat
	if sb:
		sb.border_color = color
		
	hud_notice_panel.visible = true
	hud_notice_panel.modulate.a = 1.0
	
	if _notice_tween and _notice_tween.is_valid():
		_notice_tween.kill()
	_notice_tween = create_tween()
	_notice_tween.tween_interval(3.5)
	_notice_tween.tween_property(hud_notice_panel, "modulate:a", 0.0, 0.6)
	_notice_tween.tween_callback(func(): hud_notice_panel.visible = false)


func _flash_bar(bar: ProgressBar, base_color: Color) -> void:
	if not bar:
		return
	var fill_sb := bar.get_theme_stylebox("fill") as StyleBoxFlat
	if not fill_sb:
		return
	var tw := create_tween()
	tw.tween_property(fill_sb, "bg_color", Color(1.0, 0.15, 0.15), 0.12)
	tw.tween_property(fill_sb, "bg_color", base_color, 0.12)
	tw.tween_property(fill_sb, "bg_color", Color(1.0, 0.15, 0.15), 0.12)
	tw.tween_property(fill_sb, "bg_color", base_color, 0.25)


func _on_cycle_advanced(new_cycle: int) -> void:
	if label_cycle:
		label_cycle.text = "SOL %d / 14" % new_cycle


func _on_debuff_changed(_debuff: String, _active: bool) -> void:
	if not label_alerts:
		return
	if GameManager.is_suffocating:
		label_alerts.text = "¡ASFIXIA CRÍTICA (<30% O₂)! RIESGO DE DESMAYO"
		label_alerts.add_theme_color_override("font_color", UIStyle.BAD)
	elif GameManager.is_starving:
		label_alerts.text = "¡HAMBRE CRÍTICA (<25%)! VELOCIDAD AL 55%"
		label_alerts.add_theme_color_override("font_color", UIStyle.WARN)
	elif GameManager.is_irradiated:
		label_alerts.text = "¡RADIACIÓN SOLAR ALTA! CONSUMO DE O₂ x2"
		label_alerts.add_theme_color_override("font_color", UIStyle.BAD)
	else:
		label_alerts.text = "SISTEMAS NOMINALES"
		label_alerts.add_theme_color_override("font_color", UIStyle.OK)


func _process(delta: float) -> void:
	# Viñeta negra durante micro-desmayos
	if GameManager.in_micro_blackout:
		blackout_rect.color.a = move_toward(blackout_rect.color.a, 0.95, delta * 3.0)
	else:
		blackout_rect.color.a = move_toward(blackout_rect.color.a, 0.0, delta * 2.0)
		
	# Lógica oscilante del minijuego de calibración
	if minigame_active and minigame_needle_marker:
		needle_value += needle_dir * needle_speed * delta
		if needle_value >= 1.0:
			needle_value = 1.0
			needle_dir = -1.0
		elif needle_value <= 0.0:
			needle_value = 0.0
			needle_dir = 1.0
			
		var bar_w: float = minigame_bar.size.x
		minigame_needle_marker.position.x = needle_value * bar_w - 4.0
