extends Node
## AUTOLOAD "NasaDataManager" — SPACE CONTI
## Conecta con las APIs públicas abiertas de la NASA (DONKI y OSDR).
## Consulta llamaradas solares reales mediante HTTPRequest y utiliza
## `res://Resources/nasa_events.json` como respaldo automático en modo offline.

signal event_pool_ready(events: Array)
signal live_nasa_event_received(event_data: Dictionary)

const NASA_API_URL: String = "https://api.nasa.gov/DONKI/FLR?startDate=2024-01-01&endDate=2024-12-31&api_key=DEMO_KEY"
const FALLBACK_JSON_PATH: String = "res://Resources/nasa_events.json"

var http_request: HTTPRequest
var events_catalog: Array = []
var is_using_live_data: bool = false


func _ready() -> void:
	http_request = HTTPRequest.new()
	http_request.timeout = 5.0
	add_child(http_request)
	http_request.request_completed.connect(_on_http_request_completed)
	
	# Cargamos primero el respaldo local JSON para disponibilidad inmediata
	_load_fallback_json()
	
	# Intentamos consultar la API de la NASA en segundo plano
	fetch_live_solar_data()


func fetch_live_solar_data() -> void:
	var error: Error = http_request.request(NASA_API_URL)
	if error != OK:
		print("NasaDataManager: No se pudo iniciar HTTPRequest (%s). Usando respaldo JSON." % error)


func _on_http_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
		print("NasaDataManager: Respuesta API NASA con código %d. Manteniendo respaldo JSON." % response_code)
		return
		
	var json_str: String = body.get_string_from_utf8()
	var parsed: Variant = JSON.parse_string(json_str)
	
	if parsed is Array and not parsed.is_empty():
		var live_events: Array = []
		# Filtramos eventos reales de clase X o M
		for item in parsed:
			if item is Dictionary and item.has("classType"):
				var ctype: String = str(item.get("classType", ""))
				if ctype.begins_with("X") or ctype.begins_with("M"):
					var ev: Dictionary = _convert_donki_flare_to_event(item)
					live_events.append(ev)
					if live_events.size() >= 3:
						break
						
		if not live_events.is_empty():
			is_using_live_data = true
			# Agregamos los eventos de la API en vivo al catálogo
			for lev in live_events:
				events_catalog.push_front(lev)
			print("NasaDataManager: ¡Conexión con NASA DONKI exitosa! %d llamaradas solares reales cargadas." % live_events.size())
			live_nasa_event_received.emit(live_events[0])
			event_pool_ready.emit(events_catalog)


func _convert_donki_flare_to_event(flare: Dictionary) -> Dictionary:
	var flare_id: String = str(flare.get("flrID", "DONKI-FLR"))
	var ctype: String = str(flare.get("classType", "Clase X"))
	var begin_time: String = str(flare.get("beginTime", "2024"))
	var region: String = str(flare.get("activeRegionNum", "Activa"))
	
	return {
		"id": flare_id,
		"title": "¡Llamarada Solar Real %s (NASA DONKI)!" % ctype,
		"category": "Clima Espacial en Vivo",
		"badge": "DONKI LIVE · %s" % ctype,
		"description": "Telemetría real satelital de la NASA: La región solar %s produjo una potente eyección %s registrada el %s." % [region, ctype, begin_time],
		"kids_explanation": "¡Datos directos del Sol! Los satélites de la NASA vieron esta explosión solar en vivo. En la Luna no tenemos atmósfera para frenarla, así que debemos decidir cómo repartir la energía.",
		"nasa_source": "NASA DONKI API (api.nasa.gov) - Evento ID: %s" % flare_id,
		"options": [
			{
				"text": "Blindaje Deflector a máxima potencia",
				"tradeoff": "-25 Energía / +30 Escudo de Radiación",
				"deltas": {
					"energy": -25,
					"oxygen": 0,
					"food": 0,
					"radiation_shield": 30
				},
				"feedback": "Desviaste la radiación solar ionizante detectada en vivo por la NASA."
			},
			{
				"text": "Ahorro de batería y refugio en túneles de regolito",
				"tradeoff": "+15 Energía / -20 Escudo / -15 Oxígeno",
				"deltas": {
					"energy": 15,
					"oxygen": -15,
					"food": 0,
					"radiation_shield": -20
				},
				"feedback": "Ahorraste energía apagando luces, pero el hacinamiento en el refugio consumió aire."
			}
		]
	}


func _load_fallback_json() -> void:
	if not FileAccess.file_exists(FALLBACK_JSON_PATH):
		push_warning("NasaDataManager: Archivo JSON no encontrado: %s" % FALLBACK_JSON_PATH)
		return
		
	var f := FileAccess.open(FALLBACK_JSON_PATH, FileAccess.READ)
	if f == null:
		return
		
	var txt := f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if parsed is Dictionary and parsed.has("events"):
		events_catalog = parsed["events"]
		print("NasaDataManager: %d eventos históricos de la NASA cargados desde JSON." % events_catalog.size())
		event_pool_ready.emit(events_catalog)


func get_random_event() -> Dictionary:
	if events_catalog.is_empty():
		_load_fallback_json()
	if events_catalog.is_empty():
		return {}
	return events_catalog[randi() % events_catalog.size()].duplicate(true)
