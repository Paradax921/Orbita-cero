extends Node
## Pruebas automáticas de la lógica de simulación (sin gráficos).
## Ejecutar:  godot --headless res://Scenes/Tests/SimTest.tscn
## Sale con código 0 si todas las pruebas pasan.

var failures := 0
var checks := 0
var verbose := OS.get_cmdline_user_args().has("--verbose-sim")


func _ready() -> void:
	await get_tree().process_frame
	Sim.running = false  # control manual: usamos Sim.step()
	_test_events_and_repairs()
	_test_coupling()
	_test_unattended()
	_test_good_player()
	print("")
	print("RESULTADO: %d comprobaciones, %d fallos" % [checks, failures])
	get_tree().quit(1 if failures > 0 else 0)


func check(cond: bool, msg: String) -> void:
	checks += 1
	if cond:
		print("  [OK]   " + msg)
	else:
		failures += 1
		print("  [FALLO] " + msg)


func fresh() -> void:
	Sim.start_mission()
	Sim.config.first_event_delay = 99999.0  # sin eventos aleatorios salvo los forzados
	Sim.events.timer = 99999.0
	Sim.running = true


func run(seconds: float, dt: float = 0.1) -> void:
	var t := 0.0
	while t < seconds and not Sim.mission_over:
		Sim.step(dt)
		t += dt


func _test_events_and_repairs() -> void:
	print("== Eventos y reparaciones ==")
	fresh()
	check(Sim.events.trigger("panel_failure"), "panel_failure se dispara")
	check(Sim.power.failed_count() == 1, "un panel queda averiado")
	var kits: int = Sim.repair_kits
	check(Sim.interaction.perform("power_console"), "reparar panel desde consola de energía")
	check(Sim.power.failed_count() == 0 and Sim.repair_kits == kits - 1, "panel reparado y kit consumido")

	check(Sim.events.trigger("power_short"), "power_short se dispara")
	var d0: float = Sim.total_power_demand()
	Sim.interaction.perform("power_console")
	check(Sim.total_power_demand() < d0, "reparar cortocircuito reduce la demanda")

	Sim.events.trigger("o2_leak")
	var r0: float = Sim.oxygen.reserve
	Sim.oxygen.generator_on = false
	run(10.0)
	check(Sim.oxygen.reserve < r0, "la fuga de O₂ reduce la reserva")
	Sim.interaction.perform("o2_tank")
	check(not Sim.oxygen.leak_active, "fuga de O₂ sellada")

	Sim.events.trigger("water_leak")
	Sim.interaction.perform("water_tank")
	check(not Sim.water.leak_active, "fuga de agua sellada")

	Sim.events.trigger("filter_clog")
	check(Sim.water.filter < 0.2, "filtro obstruido")
	Sim.interaction.perform("water_filter")
	check(Sim.water.filter > 0.99, "filtro restaurado")

	Sim.events.trigger("crop_blight")
	check(Sim.food.blight_count() > 0, "plaga aplicada")
	Sim.interaction.perform("greenhouse")
	check(Sim.food.blight_count() == 0, "plaga tratada")

	Sim.events.trigger("solar_flare")
	check(Sim.power.flare_time > 0.0, "tormenta solar activa")
	Sim.power.flare_time = 0.5
	run(2.0)
	check(not Sim.events.is_active("solar_flare"), "tormenta solar se resuelve sola")
	check(Sim.events.resolved_incidents >= 6, "contador de incidentes resueltos coherente")


func _test_coupling() -> void:
	print("== Acoplamiento entre sistemas ==")
	fresh()
	run(1.0)
	var d_on: float = Sim.total_power_demand()
	Sim.water.recycler_on = false
	check(Sim.total_power_demand() < d_on, "el reciclador de agua consume energía")
	Sim.water.recycler_on = true
	Sim.food.lights_on = false
	check(Sim.total_power_demand() < d_on, "el invernadero consume energía")
	Sim.food.lights_on = true
	var w0: float = Sim.water.reserve
	Sim.water.recycler_on = false
	Sim.oxygen.generator_on = false
	Sim.food.plots[0]["stage"] = 2
	run(20.0)
	var spent: float = w0 - Sim.water.reserve
	check(spent > Sim.config.crew_size * Sim.water.CREW_USE * 20.0 * 0.99, "el invernadero consume agua además de la tripulación")
	fresh()
	Sim.power.set_all(false)
	Sim.power.battery = 0.0
	run(5.0)
	check(Sim.power.supply_ratio < 0.1, "sin paneles ni batería, supply_ratio ≈ 0")
	var p_before: float = Sim.food.plots[0]["progress"]
	run(5.0)
	check(Sim.food.stalled_reason == "energía insuficiente", "cultivos se detienen sin energía")
	check(Sim.alerts.has("lvl_energy"), "alerta de energía generada")


func _test_unattended() -> void:
	print("== Estación sin atender (debe degradarse) ==")
	fresh()
	run(Sim.config.mission_duration + 10.0)
	check(Sim.mission_over, "la misión termina")
	var rep: Dictionary = Sim.last_report
	print("    -> %s | puntuación %.1f (%s) | estabilidad media %.1f" % [rep["reason"], rep["score"], rep["grade"], rep["stability_avg"]])
	check(rep["score"] < 85.0, "sin intervención no se obtiene calificación A")


func _test_good_player() -> void:
	print("== Jugador competente (debe completar la misión) ==")
	Sim.config.first_event_delay = 20.0
	Sim.start_mission()
	Sim.config.event_interval_min = 45.0
	Sim.config.event_interval_max = 80.0
	Sim.running = true
	var t := 0.0
	while t < Sim.config.mission_duration + 5.0 and not Sim.mission_over:
		Sim.step(0.1)
		t += 0.1
		if int(t * 10.0) % 20 == 0:  # actúa cada 2 s
			_play_policy()
		if verbose and int(t * 10.0) % 300 == 0:
			print("    t=%3d E=%3d O2c=%3d O2r=%3d H2O=%3d F=%3d crew=%3d kits=%d gen=%.1f dem=%.1f sun=%.2f ev=%s" % [t, Sim.power.percent(), Sim.oxygen.cabin, Sim.oxygen.reserve_percent(), Sim.water.percent(), Sim.food.percent(), Sim.crew_health, Sim.repair_kits, Sim.power.generation, Sim.total_power_demand(), Sim.power.sun_factor, str(Sim.events.active.keys())])
	var rep: Dictionary = Sim.last_report
	check(Sim.mission_over and rep["success"], "misión completada con éxito")
	print("    -> incidentes %d (resueltos %d) | puntuación %.1f (%s)" % [rep["incidents"], rep["resolved"], rep["score"], rep["grade"]])
	print("    -> estabilidad %.1f%% | disponibilidad %.1f%% | eficiencia energética %.1f%% | alimentos %.0f cosechados" % [rep["stability_avg"], rep["availability"], rep["energy_eff"], rep["food_harvested"]])
	check(rep["score"] >= 55.0, "calificación mínima C para jugador competente")
	check(rep["crew_health"] > 50.0, "la tripulación sobrevive en buen estado")


func _play_policy() -> void:
	var I = Sim.interaction
	if Sim.events.is_active("power_short") or Sim.power.failed_count() > 0:
		I.perform("power_console")
	if Sim.oxygen.leak_active:
		I.perform("o2_tank")
	if Sim.water.leak_active:
		I.perform("water_tank")
	if Sim.events.is_active("filter_clog"):
		I.perform("water_filter")
	if Sim.food.blight_count() > 0 or Sim.food.ripe_count() > 0 or Sim.food.empty_count() > 0 or Sim.food.nutrients < 30.0:
		I.perform("greenhouse")
	if Sim.power.panels_online() < 6 and Sim.power.failed_count() == 0:
		Sim.power.set_all(true)
	if Sim.oxygen.generator_wear > 0.5 or Sim.power.avg_dust() > 0.5 or Sim.water.filter < 0.3:
		I.perform("toolbox")
