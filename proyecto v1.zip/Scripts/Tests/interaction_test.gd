extends Node
## Prueba de integración: para cada objeto interactivo coloca al jugador
## frente a él, verifica que el RayCast3D lo detecta y que la tecla E
## (InputEventAction "interact") ejecuta la acción y modifica la simulación.
## Ejecutar:  godot --headless res://Scenes/Tests/InteractionTest.tscn

var failures := 0
var dash_opened := false
var cases := [
	["central_console", Vector3(0, 0.05, -9.2), 0.0, -0.25],
	["greenhouse", Vector3(-0.8, 0.05, -6.5), 90.0, 0.0],
	["lab_terminal", Vector3(-0.8, 0.05, -11.0), 90.0, 0.0],
	["power_console", Vector3(-0.6, 0.05, -2.3), 90.0, 0.0],
	["o2_tank", Vector3(0.9, 0.05, -3.8), -90.0, 0.0],
	["o2_valve", Vector3(1.2, 0.05, -5.7), -90.0, 0.0],
	["o2_generator", Vector3(0.9, 0.05, -7.0), -90.0, 0.0],
	["water_tank", Vector3(0.6, 0.05, -8.9), -90.0, 0.0],
	["water_recycler", Vector3(0.6, 0.05, -10.5), -90.0, 0.0],
	["water_filter", Vector3(0.6, 0.05, -12.0), -90.0, 0.0],
	["toolbox", Vector3(1.0, 0.05, -1.3), -90.0, 0.0],
]


func _ready() -> void:
	var main: Node = load("res://Scenes/Main/Main.tscn").instantiate()
	add_child(main)
	Sim.running = false
	await get_tree().process_frame
	var player: CharacterBody3D = get_tree().get_first_node_in_group("player")
	for c in cases:
		player.global_position = c[1]
		player.rotation_degrees.y = c[2]
		player.get_node("Head").rotation.x = c[3]
		player.velocity = Vector3.ZERO
		for i in 4:
			await get_tree().physics_frame
		var target = player._target
		var ok: bool = target != null and target.interaction_id == c[0]
		print("%s %-16s prompt: %s" % ["[OK]  " if ok else "[FALLO]", c[0], Sim.current_prompt])
		if not ok:
			failures += 1
	# efectos reales tras pulsar E
	print("== Efecto de la tecla E ==")
	await _press_at("o2_valve", func(): return Sim.oxygen.valve_mode == 3)
	await _press_at("o2_generator", func(): return not Sim.oxygen.generator_on)
	await _press_at("water_recycler", func(): return not Sim.water.recycler_on)
	await _press_at("power_console", func(): return Sim.power.panels_online() == 0)
	Sim.food.plots[0]["stage"] = 4
	await _press_at("greenhouse", func(): return Sim.food.harvested_total > 0.0)
	Sim.dashboard_requested.connect(func(_t): dash_opened = true)
	await _press_at("central_console", func(): return dash_opened)
	print("")
	print("RESULTADO interacción: %d fallos" % failures)
	get_tree().quit(1 if failures > 0 else 0)


func _press_at(id: String, check: Callable) -> void:
	for c in cases:
		if c[0] == id:
			var player: CharacterBody3D = get_tree().get_first_node_in_group("player")
			player.global_position = c[1]
			player.rotation_degrees.y = c[2]
			player.get_node("Head").rotation.x = c[3]
			for i in 4:
				await get_tree().physics_frame
			var ev := InputEventAction.new()
			ev.action = "interact"
			ev.pressed = true
			player._unhandled_input(ev)
			var ok: bool = check.call()
			print("%s E sobre %s" % ["[OK]  " if ok else "[FALLO]", id])
			if not ok:
				failures += 1
