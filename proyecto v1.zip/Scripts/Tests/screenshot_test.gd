extends Node
## Herramienta de verificación visual: carga la escena principal, coloca al
## jugador en varios puntos y guarda capturas en user://shots (o ruta indicada).

var shots := [
	["inicio", Vector3(0, 0.05, -4.5), 0.0, 0.0],
	["ventana", Vector3(0, 0.05, -8.0), 0.0, 0.05],
	["invernadero", Vector3(-0.8, 0.05, -6.5), 90.0, -0.1],
	["lab", Vector3(-0.8, 0.05, -11.0), 90.0, -0.05],
	["tanques", Vector3(0.9, 0.05, -3.8), -90.0, 0.0],
	["agua", Vector3(0.6, 0.05, -10.5), -90.0, 0.0],
	["energia", Vector3(-0.6, 0.05, -2.3), 90.0, 0.0],
	["consola", Vector3(0, 0.05, -9.2), 0.0, -0.25],
]


func _ready() -> void:
	var main: Node = load("res://Scenes/Main/Main.tscn").instantiate()
	add_child(main)
	Sim.config.first_event_delay = 99999.0
	Sim.events.timer = 99999.0
	await get_tree().create_timer(1.5).timeout
	var player: Node3D = get_tree().get_first_node_in_group("player")
	var dir := OS.get_environment("SHOT_DIR")
	if dir == "":
		dir = "/tmp/shots"
	DirAccess.make_dir_recursive_absolute(dir)
	var only := OS.get_environment("SHOT_ONLY")
	for s in shots:
		if only != "" and only != s[0]:
			continue
		player.global_position = s[1]
		player.rotation_degrees.y = s[2]
		player.get_node("Head").rotation.x = s[3]
		Sim.ui_blocking = true
		await get_tree().create_timer(0.7).timeout
		var img := get_viewport().get_texture().get_image()
		img.save_png("%s/%s.png" % [dir, s[0]])
		print("captura: ", s[0], " ", img.get_size())
	if only == "" or only == "ui":
		Sim.ui_blocking = false
		Sim.events.trigger("o2_leak")
		Sim.events.trigger("panel_failure")
		Sim.events.trigger("filter_clog")
		await get_tree().create_timer(0.8).timeout
		get_viewport().get_texture().get_image().save_png(dir + "/alertas.png")
		var dash: Node = main.get_node("Dashboard")
		for t in ["Energía", "Oxígeno", "Alimentos", "Estadísticas"]:
			dash.open(t)
			await get_tree().create_timer(0.5).timeout
			get_viewport().get_texture().get_image().save_png(dir + "/dash_" + t + ".png")
		dash.close()
		Sim.end_mission("MISIÓN COMPLETADA", true)
		await get_tree().create_timer(0.5).timeout
		get_viewport().get_texture().get_image().save_png(dir + "/informe.png")
	get_tree().quit()
