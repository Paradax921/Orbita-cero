extends Node
## Herramienta de verificación: activa cada cámara "Vista_*" de Main.tscn y
## guarda la imagen que ve (sin HUD). Uso: ver Scenes/Tests/Views.tscn

func _ready() -> void:
	var main: Node = load("res://Scenes/Main/Main.tscn").instantiate()
	add_child(main)
	Sim.config.first_event_delay = 99999.0
	Sim.events.timer = 99999.0
	main.get_node("HUD").visible = false
	await get_tree().create_timer(1.5).timeout
	var dir := OS.get_environment("SHOT_DIR")
	if dir == "":
		dir = "/tmp/views"
	DirAccess.make_dir_recursive_absolute(dir)
	for c in main.get_children():
		if c is Camera3D and c.name.begins_with("Vista_"):
			c.make_current()
			await get_tree().create_timer(0.7).timeout
			get_viewport().get_texture().get_image().save_png("%s/%s.png" % [dir, c.name])
			print("vista ", c.name)
	get_tree().quit()
