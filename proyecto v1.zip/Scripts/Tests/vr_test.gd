extends Node
## Prueba sin visor: instancia el jugador VR y los paneles VR, fuerza
## Sim.vr_mode y comprueba que no hay errores y que el puntero convierte
## coordenadas en eventos de UI (pulsa un botón del Dashboard).
## Ejecutar:  godot --headless res://Scenes/Tests/VRTest.tscn

var pressed := false


func _ready() -> void:
	var failures := 0
	Sim.vr_mode = true   # simulamos modo VR (sin visor real)
	var main: Node = load("res://Scenes/Main/Main.tscn").instantiate()
	add_child(main)
	await get_tree().create_timer(0.5).timeout
	var xr = get_tree().get_first_node_in_group("player")
	var ok_player: bool = xr != null and xr.get_script().resource_path.ends_with("xr_player.gd")
	print("%s jugador VR instanciado en lugar del plano" % ("[OK]  " if ok_player else "[FALLO]"))
	if not ok_player:
		failures += 1
	var dash = main.get_node("Dashboard")
	var panel = dash._vr_panel
	var ok_panel: bool = panel != null and panel.is_inside_tree()
	print("%s panel VR de la consola creado" % ("[OK]  " if ok_panel else "[FALLO]"))
	if not ok_panel:
		failures += 1
	else:
		dash.open("Energía")
		await get_tree().create_timer(0.3).timeout
		var visible_ok: bool = panel.visible and Sim.ui_blocking
		print("%s la consola se muestra como panel 3D" % ("[OK]  " if visible_ok else "[FALLO]"))
		if not visible_ok:
			failures += 1
		# localizar el botón "Apagar todos" y apuntar el láser hacia él
		var btn: Button = _find_button(dash._root, "Apagar todos")
		var center: Vector2 = btn.get_global_rect().get_center()
		var h: float = panel.width_m * float(panel.size_px.y) / float(panel.size_px.x)
		var local := Vector3((center.x / panel.size_px.x - 0.5) * panel.width_m, (0.5 - center.y / panel.size_px.y) * h, 0.0)
		var world: Vector3 = panel.to_global(local)
		panel.pointer_move(world)
		await get_tree().process_frame   # en uso real el láser se mueve fotogramas antes del clic
		await get_tree().process_frame
		panel.pointer_move(world)
		panel.pointer_button(true)
		await get_tree().process_frame
		panel.pointer_button(false)
		await get_tree().process_frame
		var all_off: bool = Sim.power.panels_online() == 0
		print("%s puntero VR pulsa 'Apagar todos' (paneles activos: %d)" % ["[OK]  " if all_off else "[FALLO]", Sim.power.panels_online()])
		if not all_off:
			failures += 1
		dash.close()
	print("RESULTADO VR: %d fallos" % failures)
	get_tree().quit(1 if failures > 0 else 0)


func _find_button(n: Node, text: String) -> Button:
	if n is Button and n.text == text:
		return n
	for c in n.get_children():
		var r = _find_button(c, text)
		if r:
			return r
	return null
