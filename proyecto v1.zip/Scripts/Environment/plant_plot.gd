extends Node3D
## Bandeja hidropónica. Todas las mallas están en la escena (visibles en el editor):
##   Cuenco, Etapa1_Semilla, Etapa2_Brote, Etapa3_Crecimiento, Etapa4_Madura
## Este script solo muestra la etapa real de Sim.food.plots[index] y tiñe las hojas
## (material compartido por todas las hojas de la bandeja) si hay plaga.

@export var index: int = 0

var _stage_nodes: Array = []
var _leaf_mat: StandardMaterial3D
var _last_stage: int = -1
var _last_blight: bool = false


func _ready() -> void:
	for n in ["Etapa1_Semilla", "Etapa2_Brote", "Etapa3_Crecimiento", "Etapa4_Madura"]:
		_stage_nodes.append(get_node(n))
	var leaf: MeshInstance3D = get_node("Etapa2_Brote/Hoja_1")
	_leaf_mat = leaf.material_override as StandardMaterial3D


func _process(_delta: float) -> void:
	var p: Dictionary = Sim.food.plots[index]
	var stage: int = p["stage"]
	if stage != _last_stage:
		_last_stage = stage
		for i in _stage_nodes.size():
			_stage_nodes[i].visible = (i + 1 == stage)
	if stage >= 1 and stage <= 3:
		var s: float = 0.85 + 0.15 * p["progress"]
		_stage_nodes[stage - 1].scale = Vector3(s, s, s)
	if p["blight"] != _last_blight:
		_last_blight = p["blight"]
		if _leaf_mat:
			_leaf_mat.albedo_color = Color(0.45, 0.33, 0.12) if _last_blight else Color(0.2, 0.72, 0.28)
