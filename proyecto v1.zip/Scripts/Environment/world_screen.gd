@tool
extends Node3D
## Pantalla 3D con interfaz viva: un SubViewport con Controls se proyecta
## sobre un quad. Muestra datos reales de la simulación.

const UIStyle = preload("res://Scripts/UI/ui_style.gd")

@onready var _vp: SubViewport = $SubViewport
@onready var _quad: MeshInstance3D = $Quad

@export var mode: String = "overview"
@export var size_m: Vector2 = Vector2(1.0, 0.6)
var _bars: Array = []      # [{bar, value, getter}]
var _text: Label
var _text_getter: Callable
var _title: Label
var _acc: float = 0.0
var _map: Control


## mode: energy_oxygen | food_water | overview | power | oxygen | water | food | stats
func setup(p_mode: String, p_size: Vector2) -> void:
	mode = p_mode
	size_m = p_size
	_setup()


func _ready() -> void:
	_setup()


func _setup() -> void:
	_vp.size = Vector2i(int(size_m.x * 420.0), int(size_m.y * 420.0))
	_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	_vp.transparent_bg = false
	var qm := QuadMesh.new()
	qm.size = size_m
	_quad.mesh = qm
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = _vp.get_texture()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.emission_enabled = false
	_quad.material_override = mat
	_build_ui()
	_update()


func _process(delta: float) -> void:
	_acc += delta
	if _acc >= 0.25:
		_acc = 0.0
		_update()
	if _map:
		_map.queue_redraw()


func _build_ui() -> void:
	var root := PanelContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_stylebox_override("panel", UIStyle.panel(Color(0.01, 0.05, 0.11, 1.0), UIStyle.EDGE, 3, 0))
	_vp.add_child(root)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	root.add_child(v)
	var titles := {"energy_oxygen": "ENERGÍA · OXÍGENO", "food_water": "ALIMENTOS · AGUA", "overview": "ESTADO GENERAL",
		"power": "SISTEMA ENERGÉTICO", "oxygen": "SOPORTE VITAL · O₂", "water": "AGUA Y RECICLAJE",
		"food": "INVERNADERO", "stats": "LABORATORIO · MISIÓN"}
	var fs: int = clampi(int(_vp.size.y / 12.0), 12, 30)
	_title = UIStyle.label(titles.get(mode, mode), fs, UIStyle.ACCENT)
	v.add_child(_title)
	var defs: Array = []
	match mode:
		"energy_oxygen":
			var gm = get_node_or_null("/root/GameManager")
			if gm != null:
				defs = [
					["ENERGÍA", func(): return gm.energy],
					["OXÍGENO", func(): return gm.oxygen],
					["ESCUDO", func(): return gm.radiation_shield]
				]
				_text_getter = func(): return "Ciclo %d/14 · Baterías: Inv %d | Esc %d | Ant %d" % [
					gm.cycle, gm.battery_allocations["greenhouse"], gm.battery_allocations["shield"], gm.battery_allocations["antenna"]
				]
			else:
				defs = [["ENERGÍA", func(): return Sim.power.percent()], ["OXÍGENO CABINA", func(): return Sim.oxygen.cabin]]
				_text_getter = func(): return "%.1f kW gen · %.1f kW uso" % [Sim.power.generation, Sim.total_power_demand()]
		"food_water":
			defs = [["ALIMENTOS", func(): return Sim.food.percent()], ["AGUA", func(): return Sim.water.percent()]]
			_text_getter = func(): return "Cosecha: %d listas" % Sim.food.ripe_count()
		"power":
			defs = [["BATERÍA", func(): return Sim.power.percent()]]
			_text_getter = func():
				var s := ""
				for i in Sim.power.panels.size():
					var p: Dictionary = Sim.power.panels[i]
					s += "P%d:%s  " % [i + 1, "FALLA" if p["failed"] else ("ON" if p["online"] else "OFF")]
					if i == 2:
						s += "\n"
				return "%s\nGen %.1f kW · Uso %.1f kW" % [s, Sim.power.generation, Sim.total_power_demand()]
		"oxygen":
			defs = [["RESERVA", func(): return Sim.oxygen.reserve_percent()], ["CABINA", func(): return Sim.oxygen.cabin]]
			_text_getter = func(): return "Válvula: %s\nGenerador: %s%s" % [Sim.oxygen.MODE_NAMES[Sim.oxygen.valve_mode], "ON" if Sim.oxygen.generator_on else "OFF", "\n¡FUGA!" if Sim.oxygen.leak_active else ""]
		"water":
			defs = [["RESERVA", func(): return Sim.water.percent()], ["FILTRO", func(): return Sim.water.filter * 100.0]]
			_text_getter = func(): return "Reciclador: %s%s" % ["ON" if Sim.water.recycler_on else "OFF", "\n¡FUGA!" if Sim.water.leak_active else ""]
		"food":
			defs = [["ALMACÉN", func(): return Sim.food.percent()], ["NUTRIENTES", func(): return Sim.food.nutrients]]
			_text_getter = func(): return "Listas: %d · Creciendo: %d\n%s" % [Sim.food.ripe_count(), Sim.food.growing_count(), Sim.food.stalled_reason.to_upper() if Sim.food.stalled_reason != "" else "Crecimiento normal"]
		"stats":
			_text_getter = func(): return "Estabilidad %d%%\nIncidentes %d (%d activos)\nEficiencia %d%%\nProducción %d%%" % [
				int(Sim.evaluation.stability()), Sim.events.total_incidents, Sim.events.active.size(),
				int(Sim.evaluation.energy_efficiency()), int(Sim.evaluation.food_production_level())]
		"overview":
			var gm = get_node_or_null("/root/GameManager")
			if gm != null:
				defs = [
					["ENERGÍA", func(): return gm.energy],
					["OXÍGENO", func(): return gm.oxygen],
					["ESCUDO", func(): return gm.radiation_shield]
				]
				_text_getter = func():
					var ev_title = "Sin incidentes"
					if gm.event_manager and not gm.event_manager.active_crisis_list.is_empty():
						ev_title = gm.event_manager.active_crisis_list[0].get("title", "")
					return "CICLO %d / 14\nCRISIS: %s" % [gm.cycle, ev_title]
			else:
				_text_getter = func(): return "T+ %s\nESTACIÓN: %s\nTRIPULACIÓN: %d%%\nKITS: %d" % [Sim.format_clock(Sim.elapsed), Sim.station_status, int(Sim.crew_health), Sim.repair_kits]
			_map = Control.new()
			_map.custom_minimum_size = Vector2(0, _vp.size.y * 0.3)
			_map.size_flags_vertical = Control.SIZE_EXPAND_FILL
			_map.draw.connect(_draw_map)
			v.add_child(_map)
	for d in defs:
		var cap := UIStyle.label(d[0], int(fs * 0.7), UIStyle.DIM)
		var bar := UIStyle.progress(UIStyle.EDGE, maxf(8.0, fs * 0.7))
		v.add_child(cap)
		v.add_child(bar)
		_bars.append({"bar": bar, "getter": d[1]})
	_text = UIStyle.label("", int(fs * 0.75))
	v.add_child(_text)


func _update() -> void:
	if Engine.is_editor_hint():
		# En el editor no existe la simulación: se muestra una vista previa fija.
		for b in _bars:
			UIStyle.set_bar(b["bar"], 72.0, UIStyle.OK)
		if _text:
			_text.text = "VISTA PREVIA DEL EDITOR"
		_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
		return
	for b in _bars:
		var pct: float = b["getter"].call()
		UIStyle.set_bar(b["bar"], pct, UIStyle.level_color(pct))
	_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	if _text_getter.is_valid():
		_text.text = _text_getter.call()
		if mode == "overview":
			var col: Color = {"NOMINAL": UIStyle.OK, "ADVERTENCIA": UIStyle.WARN, "CRÍTICO": UIStyle.BAD}[Sim.station_status]
			_text.add_theme_color_override("font_color", col)


func _draw_map() -> void:
	var s: Vector2 = _map.size
	_map.draw_rect(Rect2(Vector2.ZERO, s), Color(0.0, 0.1, 0.18))
	var grid := Color(0.2, 0.7, 1.0, 0.25)
	for i in range(1, 8):
		_map.draw_line(Vector2(s.x * i / 8.0, 0), Vector2(s.x * i / 8.0, s.y), grid)
	for i in range(1, 4):
		_map.draw_line(Vector2(0, s.y * i / 4.0), Vector2(s.x, s.y * i / 4.0), grid)
	var continents := [
		[Vector2(0.06, 0.2), Vector2(0.3, 0.15), Vector2(0.33, 0.45), Vector2(0.22, 0.55), Vector2(0.12, 0.4)],
		[Vector2(0.24, 0.6), Vector2(0.34, 0.6), Vector2(0.32, 0.9), Vector2(0.26, 0.85)],
		[Vector2(0.45, 0.2), Vector2(0.6, 0.15), Vector2(0.58, 0.4), Vector2(0.5, 0.45)],
		[Vector2(0.47, 0.45), Vector2(0.6, 0.45), Vector2(0.58, 0.8), Vector2(0.5, 0.75)],
		[Vector2(0.6, 0.15), Vector2(0.92, 0.2), Vector2(0.9, 0.45), Vector2(0.68, 0.5)],
		[Vector2(0.78, 0.68), Vector2(0.9, 0.68), Vector2(0.9, 0.82), Vector2(0.8, 0.82)],
	]
	for poly in continents:
		var pts := PackedVector2Array()
		for p in poly:
			pts.append(Vector2(p.x * s.x, p.y * s.y))
		_map.draw_colored_polygon(pts, Color(0.1, 0.55, 0.75, 0.55))
		pts.append(pts[0])
		_map.draw_polyline(pts, Color(0.5, 0.9, 1.0, 0.9), 1.0)
	var pulse: float = 0.5 + 0.5 * sin(Time.get_ticks_msec() / 250.0)
	_map.draw_circle(Vector2(s.x * 0.92, s.y * 0.1), 3.0 + pulse * 3.0, Color(1.0, 0.8, 0.2, 0.9))
