@tool
extends MeshInstance3D
## Superficie lunar procedural: relieve suave cerca de la base, colinas y
## montañas lejanas y cráteres con borde elevado.

const Materials = preload("res://Scripts/Environment/materials.gd")

const SIZE := 520.0
const N := 160
const CENTER := Vector3(0, 0, -100)
const STATION := Vector2(0, -7)

var _noise := FastNoiseLite.new()
var _detail := FastNoiseLite.new()
var _craters: Array = []


func _ready() -> void:
	_noise.seed = 21
	_noise.frequency = 0.012
	_noise.fractal_octaves = 4
	_detail.seed = 5
	_detail.frequency = 0.08
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for i in 40:
		var pos := Vector2(rng.randf_range(-200, 200), rng.randf_range(-260, 40))
		if pos.distance_to(STATION) < 38.0:
			continue
		_craters.append([pos.x, pos.y, rng.randf_range(4.0, 24.0), rng.randf_range(0.5, 2.5)])
	# cráteres cercanos, bien visibles desde la ventana
	_craters.append([-12.0, -52.0, 9.0, 1.4])
	_craters.append([16.0, -66.0, 14.0, 2.0])
	_build()


func height_at(x: float, z: float) -> float:
	var d: float = Vector2(x, z).distance_to(STATION)
	var mask: float = smoothstep(32.0, 110.0, d)
	var far: float = smoothstep(160.0, 260.0, d)
	var h: float = -0.2
	h += mask * (_noise.get_noise_2d(x, z) * 9.0 + _detail.get_noise_2d(x, z) * 0.6)
	h += far * (_noise.get_noise_2d(x + 300.0, z) * 14.0 + 6.0)
	h += (_detail.get_noise_2d(x * 3.0, z * 3.0)) * 0.05
	for c in _craters:
		var dd: float = Vector2(x - c[0], z - c[1]).length() / c[2]
		if dd < 1.0:
			h -= c[3] * (1.0 - dd * dd)
		elif dd < 1.3:
			h += c[3] * 0.3 * (1.0 - (dd - 1.0) / 0.3)
	return h


func _build() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var step: float = SIZE / N
	for j in N + 1:
		for i in N + 1:
			var x: float = CENTER.x - SIZE * 0.5 + i * step
			var z: float = CENTER.z - SIZE * 0.5 + j * step
			st.set_uv(Vector2(x * 0.1, z * 0.1))
			st.add_vertex(Vector3(x, height_at(x, z), z))
	for j in N:
		for i in N:
			var a: int = j * (N + 1) + i
			var b: int = a + 1
			var c: int = a + N + 1
			var d: int = c + 1
			st.add_index(a)
			st.add_index(b)
			st.add_index(c)
			st.add_index(b)
			st.add_index(d)
			st.add_index(c)
	st.generate_normals()
	mesh = st.commit()
	material_override = Materials.regolith()
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
