extends Node3D
## Script de la raíz de Main.tscn ("EstacionEspacial"), solo en ejecución.
## La geometría, luces y colisiones son nodos normales editables en la escena;
## este script únicamente anima:
##   - LuzSolar y ambiente según el ciclo día/noche (Sim.power.sun_factor)
##   - luces interiores (grupo "luz_interior") según la energía disponible,
##     con modo de emergencia rojo si cae el suministro
##   - luz del invernadero (LuzInvernadero / TiraInvernadero)
##   - ajustes de rendimiento en VR (sin SSAO/glow, sin luces azules de suelo)

var _sun: DirectionalLight3D
var _env: Environment
var _lights: Array = []
var _panel_mats: Array = []
var _gh_light: OmniLight3D
var _gh_strip_mat: StandardMaterial3D
var _flicker: float = 0.0


func _ready() -> void:
	# En VR se sustituye al jugador de pantalla plana por el jugador XR.
	if Sim.vr_mode and has_node("Player"):
		var flat: Node3D = $Player
		var xf: Transform3D = flat.global_transform
		remove_child(flat)
		flat.queue_free()
		var xr: Node3D = load("res://Scenes/Player/XRPlayer.tscn").instantiate()
		add_child(xr)
		xr.global_transform = xf
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_sun = get_node_or_null("LuzSolar")
	var we: WorldEnvironment = get_node_or_null("Ambiente")
	if we:
		_env = we.environment
	for l in get_tree().get_nodes_in_group("luz_interior"):
		_lights.append(l)
	for m in get_tree().get_nodes_in_group("panel_luz"):
		var mat: StandardMaterial3D = m.material_override
		if mat and not _panel_mats.has(mat):
			_panel_mats.append(mat)
	_gh_light = get_node_or_null("Invernadero_Luz")
	var strip: MeshInstance3D = get_node_or_null("Invernadero_TiraLuz")
	if strip:
		_gh_strip_mat = strip.material_override
	if Sim.vr_mode:
		if _env:
			_env.ssao_enabled = false
			_env.glow_enabled = false
		for l in get_tree().get_nodes_in_group("luz_azul"):
			l.visible = false
			_lights.erase(l)
	await get_tree().create_timer(0.6).timeout
	Sim.notify("Bienvenido a LUNAR BASE 01. Acérquese a la consola central y revise los sistemas.", "info")


func _process(delta: float) -> void:
	var sun_f: float = Sim.power.sun_factor
	if _sun:
		_sun.light_energy = lerpf(0.0, 1.5, sun_f)
		_sun.visible = sun_f > 0.01
	if _env:
		_env.ambient_light_energy = lerpf(0.22, 0.3, sun_f)
	var ratio: float = Sim.power.supply_ratio
	_flicker += delta
	var emergency: bool = ratio < 0.5
	var f: float = lerpf(0.12, 1.0, clampf(ratio, 0.0, 1.0))
	if emergency and fmod(_flicker, 1.3) < 0.12:
		f *= 0.2
	for l in _lights:
		var light: OmniLight3D = l
		light.light_energy = float(light.get_meta("energia_base", 1.0)) * f
		light.light_color = Color(1.0, 0.25, 0.2) if emergency else (light.get_meta("color_base", Color.WHITE) as Color)
	for mat in _panel_mats:
		mat.emission_energy_multiplier = 2.2 * f
		mat.emission = Color(1.0, 0.3, 0.25) if emergency else Color(0.95, 0.98, 1.0)
	var grow: bool = Sim.food.lights_on and ratio >= 0.2
	if _gh_light:
		_gh_light.light_energy = 0.8 if grow else 0.0
	if _gh_strip_mat:
		_gh_strip_mat.emission_energy_multiplier = 1.6 if grow else 0.0
