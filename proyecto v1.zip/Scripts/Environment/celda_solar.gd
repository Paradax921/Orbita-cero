extends Node3D
## Celda (panel) solar exterior. La malla y la colisión están en la escena
## (Scenes/Modules/CeldaSolar.tscn); este script solo anima su aspecto según el
## estado real en Sim.power.panels[index]: activo (orientado al Sol), apagado
## (plegado) o averiado (torcido + luz roja parpadeante).

const Materials = preload("res://Scripts/Environment/materials.gd")

@export var index: int = 0

@onready var _tilt: Node3D = $Inclinacion
@onready var _cells: MeshInstance3D = $Inclinacion/Celdas
@onready var _lamp: MeshInstance3D = $Luz

var _cells_mat: StandardMaterial3D
var _lamp_mat: StandardMaterial3D
var _angle: float = -38.0


func _ready() -> void:
	# Los materiales vienen guardados en la escena; si faltan (prefab) se crean aquí.
	if _cells.material_override == null:
		var metal := Materials.plain(Color(0.7, 0.72, 0.75), 0.9, 0.35)
		for n in ["Base", "Poste", "Inclinacion/MarcoA", "Inclinacion/MarcoB"]:
			(get_node(n) as MeshInstance3D).material_override = metal
		_cells.material_override = Materials.solar_cells()
		_lamp.material_override = Materials.emissive(Color.GREEN, 3.0)
	_cells_mat = _cells.material_override as StandardMaterial3D
	_lamp_mat = _lamp.material_override as StandardMaterial3D
	_tilt.rotation_degrees.x = _angle


func _process(delta: float) -> void:
	var p: Dictionary
	var sun: float = 1.0
	p = Sim.power.panels[index]
	sun = Sim.power.sun_factor
	var target: float
	var lamp_col: Color
	var roll := 0.0
	if p["failed"]:
		target = -55.0 + sin(Time.get_ticks_msec() / 300.0 + index) * 4.0
		lamp_col = Color.RED if int(Time.get_ticks_msec() / 350.0) % 2 == 0 else Color(0.2, 0.0, 0.0)
		roll = 22.0
	elif p["online"]:
		target = -38.0
		lamp_col = Color(0.2, 1.0, 0.4)
	else:
		target = -4.0
		lamp_col = Color(0.5, 0.55, 0.6)
	_tilt.rotation_degrees.z = lerpf(_tilt.rotation_degrees.z, roll, delta * 2.0)
	_angle = lerpf(_angle, target, delta * 2.0)
	_tilt.rotation_degrees.x = _angle
	_lamp_mat.albedo_color = lamp_col
	_lamp_mat.emission = lamp_col
	_cells_mat.emission_energy_multiplier = 0.6 * sun if p["online"] and not p["failed"] else 0.0
