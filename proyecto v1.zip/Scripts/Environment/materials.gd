@tool
extends RefCounted
## Fábrica de materiales y texturas procedurales (sin archivos externos).
## Las texturas se generan una sola vez y se reutilizan.

static var _cache: Dictionary = {}
## Si es false se generan siempre las texturas por código (lo usa la herramienta que crea los PNG).
static var use_png: bool = true

const FILES := {
	"panel": "panel_metalico", "floor": "piso_metalico", "cells": "celdas_solares",
	"grain_3": "regolito", "earth": "tierra",
}


static func png_path(key: String) -> String:
	return "res://Assets/Textures/%s.png" % FILES.get(key, key)


static func _from_png(key: String) -> Texture2D:
	if use_png and ResourceLoader.exists(png_path(key)):
		var t: Texture2D = load(png_path(key))
		_cache[key] = t
		return t
	return null


static func _tex(key: String, w: int, h: int, painter: Callable) -> Texture2D:
	if _cache.has(key):
		return _cache[key]
	var png := _from_png(key)
	if png:
		return png
	var img := Image.create(w, h, false, Image.FORMAT_RGB8)
	for y in h:
		for x in w:
			img.set_pixel(x, y, painter.call(x, y))
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_cache[key] = t
	return t


static func panel_texture() -> Texture2D:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	return _tex("panel", 256, 256, func(x: int, y: int) -> Color:
		var v: float = 0.82 + rng.randf() * 0.035
		if x < 3 or y < 3 or x > 252 or y > 252:
			v = 0.38
		elif x == 128 or y == 128:
			v = 0.66
		for c in [Vector2(14, 14), Vector2(242, 14), Vector2(14, 242), Vector2(242, 242)]:
			if Vector2(x, y).distance_to(c) < 3.5:
				v = 0.48
		return Color(v, v, v))


static func floor_texture() -> Texture2D:
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	return _tex("floor", 256, 256, func(x: int, y: int) -> Color:
		var v: float = 0.34 + rng.randf() * 0.04
		var d: int = (x + y) % 32
		var e: int = (x - y + 256) % 32
		if d < 3 or e < 3:
			v += 0.12
		if x % 128 < 3 or y % 128 < 3:
			v = 0.15
		return Color(v, v * 1.02, v * 1.05))


static func grain_texture(seed_v: int, base: float, amp: float) -> Texture2D:
	var key := "grain_%d" % seed_v
	if _cache.has(key):
		return _cache[key]
	var png := _from_png(key)
	if png:
		return png
	var n := FastNoiseLite.new()
	n.seed = seed_v
	n.frequency = 0.035
	n.fractal_octaves = 4
	var img: Image = n.get_seamless_image(256, 256)
	img.convert(Image.FORMAT_RGB8)
	for y in 256:
		for x in 256:
			var g: float = img.get_pixel(x, y).r
			var v: float = base + (g - 0.5) * amp
			img.set_pixel(x, y, Color(v, v * 0.98, v * 0.95))
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_cache[key] = t
	return t


static func solar_cell_texture() -> Texture2D:
	return _tex("cells", 128, 128, func(x: int, y: int) -> Color:
		var v := Color(0.06, 0.12, 0.3)
		if x % 32 < 2 or y % 32 < 2:
			v = Color(0.55, 0.6, 0.7)
		elif x % 16 == 8:
			v = Color(0.09, 0.17, 0.4)
		return v)


static func earth_texture() -> Texture2D:
	if _cache.has("earth"):
		return _cache["earth"]
	var png := _from_png("earth")
	if png:
		return png
	var land := FastNoiseLite.new()
	land.seed = 42
	land.frequency = 1.3
	land.fractal_octaves = 4
	var cloud := FastNoiseLite.new()
	cloud.seed = 9
	cloud.frequency = 2.4
	cloud.fractal_octaves = 3
	var w := 512
	var h := 256
	var img := Image.create(w, h, false, Image.FORMAT_RGB8)
	for y in h:
		var lat: float = (0.5 - float(y) / h) * PI
		for x in w:
			var lon: float = float(x) / w * TAU
			var p := Vector3(cos(lat) * cos(lon), sin(lat), cos(lat) * sin(lon))
			var n: float = land.get_noise_3d(p.x, p.y, p.z)
			var col: Color
			if n > 0.08:
				var t: float = clampf((n - 0.08) * 3.0, 0.0, 1.0)
				col = Color(0.18, 0.42, 0.16).lerp(Color(0.55, 0.45, 0.28), t)
			else:
				col = Color(0.03, 0.14, 0.4).lerp(Color(0.06, 0.3, 0.6), clampf((n + 0.4) * 2.0, 0.0, 1.0))
			if absf(lat) > 1.2:
				col = col.lerp(Color(0.95, 0.97, 1.0), 0.9)
			var c: float = clampf((cloud.get_noise_3d(p.x, p.y, p.z) - 0.05) * 2.2, 0.0, 0.85)
			col = col.lerp(Color(1, 1, 1), c)
			img.set_pixel(x, y, col)
	img.generate_mipmaps()
	var t := ImageTexture.create_from_image(img)
	_cache["earth"] = t
	return t


# ------------------------------------------------------------------ materiales
static func plain(color: Color, metallic: float = 0.0, rough: float = 0.6) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metallic
	m.roughness = rough
	return m


static func triplanar(tex: Texture2D, tint: Color, scale: float, metallic: float, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.albedo_color = tint
	m.metallic = metallic
	m.roughness = rough
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(scale, scale, scale)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	return m


static func wall() -> StandardMaterial3D:
	return triplanar(panel_texture(), Color(0.55, 0.57, 0.62), 0.5, 0.4, 0.5)


static func white_panel() -> StandardMaterial3D:
	return triplanar(panel_texture(), Color(0.78, 0.8, 0.84), 0.5, 0.25, 0.45)


static func dark_metal() -> StandardMaterial3D:
	return plain(Color(0.14, 0.16, 0.19), 0.8, 0.4)


static func floor_mat() -> StandardMaterial3D:
	return triplanar(floor_texture(), Color(0.55, 0.56, 0.62), 0.5, 0.5, 0.55)


static func emissive(color: Color, energy: float = 2.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	return m


static func glass(alpha: float = 0.1, tint: Color = Color(0.7, 0.85, 1.0)) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(tint.r, tint.g, tint.b, alpha)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.05
	m.metallic = 0.2
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


static func regolith() -> StandardMaterial3D:
	var m := triplanar(grain_texture(3, 0.58, 0.55), Color(0.62, 0.6, 0.58), 0.18, 0.0, 1.0)
	return m


static func solar_cells() -> StandardMaterial3D:
	var m := triplanar(solar_cell_texture(), Color(1, 1, 1), 1.2, 0.6, 0.25)
	m.emission_enabled = true
	m.emission = Color(0.1, 0.25, 0.7)
	m.emission_energy_multiplier = 0.0
	return m


static func earth() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = earth_texture()
	m.roughness = 0.9
	m.emission_enabled = true
	m.emission_texture = earth_texture()
	m.emission_energy_multiplier = 0.35
	return m
