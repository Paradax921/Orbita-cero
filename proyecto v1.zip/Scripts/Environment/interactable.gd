extends StaticBody3D
## Objeto interactivo. Nodos hijos (visibles en el editor):
##   CollisionShape3D  caja de colisión/interacción (capa 1 física + capa 2 interacción)
##   Lamp              luz de estado (verde/amarillo/rojo/gris/celeste según Sim.interaction)
## Delega texto y acción en Sim.interaction usando `interaction_id`.

@export var interaction_id: String = ""

@onready var _lamp: MeshInstance3D = $Lamp

var _lamp_mat: StandardMaterial3D
var _acc: float = 0.0


func _ready() -> void:
	collision_layer = 3   # capa 1 (física) + capa 2 (interacción)
	collision_mask = 0
	_lamp_mat = _lamp.material_override as StandardMaterial3D
	if _lamp_mat == null:
		_lamp_mat = StandardMaterial3D.new()
		_lamp.material_override = _lamp_mat
	_lamp_mat.emission_enabled = true
	_lamp_mat.emission_energy_multiplier = 3.0
	_refresh_lamp()


func get_prompt() -> String:
	return Sim.interaction.prompt(interaction_id)


func interact(_player: Node) -> void:
	Sim.interaction.perform(interaction_id)
	_refresh_lamp()
	var tw := create_tween()
	tw.tween_property(_lamp_mat, "emission_energy_multiplier", 12.0, 0.08)
	tw.tween_property(_lamp_mat, "emission_energy_multiplier", 3.0, 0.3)


func _process(delta: float) -> void:
	_acc += delta
	if _acc >= 0.25:
		_acc = 0.0
		_refresh_lamp()


func _refresh_lamp() -> void:
	var c: Color = Sim.interaction.status_color(interaction_id)
	_lamp_mat.albedo_color = c
	_lamp_mat.emission = c
