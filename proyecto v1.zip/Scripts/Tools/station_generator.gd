extends RefCounted
## GENERADOR de la estación LUNAR BASE 01 (herramienta de edición).
## Construye la estación con primitivas y devuelve un árbol de nodos con nombres
## y grupos. La herramienta Scripts/Tools/bake_station.gd lo guarda como la
## escena editable Scenes/Environment/EstacionEspacial.tscn.
##
## Patrón de cada sólido (igual que en un modelo importado):
##   MeshInstance3D "Nombre"  ->  StaticBody3D "Solid"  ->  CollisionShape3D
##
## Sistema de coordenadas: pasillo principal a lo largo de -Z.
##   X: -3 .. +3 (ancho)   Z: 0 (escotilla trasera) .. -14 (ventana)   Y: 0 .. 3.4

const Materials = preload("res://Scripts/Environment/materials.gd")
const InteractableScript = preload("res://Scripts/Environment/interactable.gd")
const WorldScreenScript = preload("res://Scripts/Environment/world_screen.gd")
const CeldaScript = preload("res://Scripts/Environment/celda_solar.gd")
const TerrainScript = preload("res://Scripts/Environment/terrain.gd")
const PlantPlotScript = preload("res://Scripts/Environment/plant_plot.gd")
## Grupos cuyos nodos no llevan prefijo en el nombre.
const NO_PREFIX := ["Estructura", "Exterior", "CeldasSolares"]
const PREVIEW_STAGES := [4, 3, 2, 2, 1, 1]

const H := 3.4
const PLOT_COUNT := 6
const TERRAIN_MESH := "res://Assets/Models/terreno_lunar.res"
const TERRAIN_SHAPE := "res://Assets/Models/terreno_lunar_colision.res"

var m_wall: StandardMaterial3D
var m_white: StandardMaterial3D
var m_dark: StandardMaterial3D
var m_floor: StandardMaterial3D
var m_light_panel: StandardMaterial3D
var m_blue_strip: StandardMaterial3D
var m_glass: StandardMaterial3D

var root: Node3D
var _cur: Node3D
var _count: Dictionary = {}
var _prefix: String = ""


func build() -> Node3D:
	root = Node3D.new()
	root.name = "EstacionEspacial"
	_cur = root
	m_wall = Materials.wall()
	m_white = Materials.white_panel()
	m_dark = Materials.dark_metal()
	m_floor = Materials.floor_mat()
	m_light_panel = Materials.emissive(Color(0.95, 0.98, 1.0), 2.2)
	m_blue_strip = Materials.emissive(Color(0.2, 0.65, 1.0), 2.5)
	m_glass = Materials.glass(0.03, Color(0.5, 0.65, 0.8))
	_build_environment()
	_build_shell()
	_build_lighting()
	_build_center_console()
	_build_greenhouse()
	_build_lab()
	_build_power_corner()
	_build_right_wall()
	_build_decor()
	_build_exterior()
	_build_views()
	return root


# =============================================================== utilidades
## Define la zona actual: los nodos nuevos se nombran "Zona_Pieza" y cuelgan
## directamente de la raíz (lista plana, todo visible en el panel Escena).
func _group(group_name: String, _unused: Node3D = null) -> Node3D:
	_prefix = "" if group_name in NO_PREFIX else group_name + "_"
	return null


func _unique(base: String) -> String:
	var key := _prefix + base   # contador independiente por zona
	_count[key] = int(_count.get(key, 0)) + 1
	return "%s_%02d" % [base, _count[key]]


func _add(parent: Node, node: Node, nm: String = "", base: String = "") -> void:
	var pfx: String = _prefix if parent == null else ""
	if nm != "":
		node.name = pfx + nm
	elif base != "":
		node.name = pfx + _unique(base)
	(parent if parent else root).add_child(node)


func _solid(mi: MeshInstance3D, shape: Shape3D) -> void:
	var sb := StaticBody3D.new()
	sb.name = "Solid"
	var cs := CollisionShape3D.new()
	cs.name = "CollisionShape3D"
	cs.shape = shape
	sb.add_child(cs)
	mi.add_child(sb)


func _box(pos: Vector3, size: Vector3, mat: Material, parent: Node = null, collide: bool = true, nm: String = "") -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	_add(parent, mi, nm, "Caja")
	if collide:
		var bs := BoxShape3D.new()
		bs.size = size
		_solid(mi, bs)
	return mi


func _cyl(pos: Vector3, radius: float, height: float, mat: Material, parent: Node = null, collide: bool = false, rot: Vector3 = Vector3.ZERO, nm: String = "") -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 20
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot
	_add(parent, mi, nm, "Cilindro")
	if collide:
		var sh := CylinderShape3D.new()
		sh.radius = radius
		sh.height = height
		_solid(mi, sh)
	return mi


func _sphere(pos: Vector3, radius: float, mat: Material, parent: Node = null, nm: String = "") -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0
	mi.mesh = sm
	mi.material_override = mat
	mi.position = pos
	_add(parent, mi, nm, "Esfera")
	return mi


func _label3d(text: String, pos: Vector3, rot_y: float, size: float, color: Color) -> void:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.rotation_degrees.y = rot_y
	l.pixel_size = size
	l.font_size = 64
	l.modulate = color
	l.outline_size = 0
	l.shaded = false
	_add(null, l, "", "Letrero")


func _interactable(id: String, pos: Vector3, size: Vector3, lamp_pos: Vector3) -> Node3D:
	var it := StaticBody3D.new()
	it.set_script(InteractableScript)
	it.set("interaction_id", id)
	it.position = pos
	it.collision_layer = 3
	it.collision_mask = 0
	var cs := CollisionShape3D.new()
	cs.name = "CollisionShape3D"
	var box := BoxShape3D.new()
	box.size = size
	cs.shape = box
	it.add_child(cs)
	var lamp := MeshInstance3D.new()
	lamp.name = "Lamp"
	var sm := SphereMesh.new()
	sm.radius = 0.05
	sm.height = 0.1
	sm.radial_segments = 12
	sm.rings = 6
	lamp.mesh = sm
	lamp.position = lamp_pos
	lamp.material_override = Materials.emissive(Color(0.3, 0.75, 1.0), 3.0)
	it.add_child(lamp)
	_add(root, it, "Interactivo_" + id)
	return it


func _screen(mode: String, pos: Vector3, rot_y: float, size: Vector2, tilt_x: float = 0.0) -> void:
	var s := Node3D.new()
	s.set_script(WorldScreenScript)
	s.set("mode", mode)
	s.set("size_m", size)
	s.position = pos
	s.rotation_degrees = Vector3(tilt_x, rot_y, 0)
	var vp := SubViewport.new()
	vp.name = "SubViewport"
	vp.size = Vector2i(int(size.x * 420.0), int(size.y * 420.0))
	s.add_child(vp)
	var q := MeshInstance3D.new()
	q.name = "Quad"
	var qm := QuadMesh.new()
	qm.size = size
	q.mesh = qm
	s.add_child(q)
	_add(root, s, "Pantalla_" + mode)


func _light(pos: Vector3, color: Color, energy: float, rng: float, shadow: bool = false, blue: bool = false) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = color
	l.light_energy = energy
	l.omni_range = rng
	l.shadow_enabled = shadow
	l.set_meta("energia_base", energy)
	l.set_meta("color_base", color)
	_add(null, l, "", "LuzAzulSuelo" if blue else "LuzTecho")
	l.add_to_group("luz_interior", true)
	if blue:
		l.add_to_group("luz_azul", true)
	return l


# =============================================================== entorno
func _build_environment() -> void:
	_cur = root
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ShaderMaterial.new()
	sm.shader = load("res://Assets/Materials/stars_sky.gdshader")
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.3, 0.36, 0.5)
	env.ambient_light_energy = 0.28
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 0.9
	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_bloom = 0.05
	env.glow_hdr_threshold = 1.3
	env.ssao_enabled = true
	env.ssao_radius = 1.2
	env.ssao_intensity = 1.6
	we.environment = env
	_add(null, we, "Ambiente")

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-32.0, 28.0, 0.0)
	sun.light_energy = 1.5
	sun.light_color = Color(1.0, 0.97, 0.92)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 90.0
	sun.shadow_bias = 0.05
	_add(null, sun, "LuzSolar")


# =============================================================== estructura
func _build_shell() -> void:
	_group("Estructura")
	# suelo y techo
	_box(Vector3(0, -0.15, -7), Vector3(6.4, 0.3, 14.4), m_floor, null, true, "NucleoPiso")
	_box(Vector3(0, H + 0.1, -7), Vector3(6.4, 0.2, 14.4), m_wall, null, true, "NucleoTecho")
	# paredes laterales y trasera
	_box(Vector3(-3.1, H / 2.0 - 0.1, -7), Vector3(0.2, H + 0.4, 14.4), m_wall, null, true, "MuroIzquierdo")
	_box(Vector3(3.1, H / 2.0 - 0.1, -7), Vector3(0.2, H + 0.4, 14.4), m_wall, null, true, "MuroDerecho")
	_box(Vector3(0, H / 2.0, 0.1), Vector3(6.4, H, 0.2), m_wall, null, true, "MuroTrasero")
	# pared frontal con ventana panorámica (x ±2.6, y 0.8..2.9)
	_box(Vector3(0, 0.4, -14.1), Vector3(6.4, 0.8, 0.2), m_wall, null, true, "MuroFrontalInferior")
	_box(Vector3(0, (2.9 + H) / 2.0, -14.1), Vector3(6.4, H - 2.9, 0.2), m_wall, null, true, "MuroFrontalSuperior")
	_box(Vector3(-2.95, H / 2.0, -14.1), Vector3(0.7, H, 0.2), m_wall, null, true, "PilarVentanaIzquierdo")
	_box(Vector3(2.95, H / 2.0, -14.1), Vector3(0.7, H, 0.2), m_wall, null, true, "PilarVentanaDerecho")
	var gl := _box(Vector3(0, 1.85, -14.1), Vector3(5.2, 2.1, 0.03), m_glass, null, true, "VentanaVidrio")
	gl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# marco de la ventana
	_box(Vector3(0, 0.82, -13.95), Vector3(5.4, 0.12, 0.35), m_dark, null, false)
	_box(Vector3(0, 2.9, -13.95), Vector3(5.4, 0.12, 0.35), m_dark, null, false)
	_box(Vector3(-2.62, 1.85, -13.95), Vector3(0.12, 2.1, 0.35), m_dark, null, false)
	_box(Vector3(2.62, 1.85, -13.95), Vector3(0.12, 2.1, 0.35), m_dark, null, false)
	for x in [-1.3, 0.0, 1.3]:
		_box(Vector3(x, 1.85, -13.98), Vector3(0.06, 2.1, 0.1), m_dark, null, false)
	# costillas estructurales
	for z in [-1.5, -4.5, -7.5, -10.5, -13.3]:
		for sx in [-1.0, 1.0]:
			_box(Vector3(sx * 2.93, H / 2.0, z), Vector3(0.14, H, 0.3), m_dark, null, false)
		_box(Vector3(0, H - 0.07, z), Vector3(6.0, 0.14, 0.3), m_dark, null, false)
	# tuberías en techo
	for sx in [-1.0, 1.0]:
		_cyl(Vector3(sx * 2.7, H - 0.2, -7), 0.07, 13.6, Materials.plain(Color(0.7, 0.72, 0.75), 0.9, 0.3), null, false, Vector3(90, 0, 0))
	_cyl(Vector3(-2.45, H - 0.18, -7), 0.04, 13.6, Materials.plain(Color(0.8, 0.2, 0.15), 0.4, 0.4), null, false, Vector3(90, 0, 0))
	_cyl(Vector3(2.45, H - 0.18, -7), 0.04, 13.6, Materials.plain(Color(0.2, 0.4, 0.85), 0.4, 0.4), null, false, Vector3(90, 0, 0))
	# tiras azules en el suelo
	for sx in [-1.0, 1.0]:
		_box(Vector3(sx * 2.0, 0.012, -7), Vector3(0.05, 0.02, 13.4), m_blue_strip, null, false)
	# franjas de peligro (amarillo) alrededor de la consola
	var amber := Materials.emissive(Color(1.0, 0.75, 0.1), 0.8)
	_box(Vector3(0, 0.012, -9.9), Vector3(3.4, 0.02, 0.08), amber, null, false)
	# escotilla circular trasera
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.82
	tm.outer_radius = 0.98
	ring.mesh = tm
	ring.material_override = m_dark
	ring.rotation_degrees = Vector3(90, 0, 0)
	ring.position = Vector3(0, 1.5, -0.03)
	_add(null, ring, "EscotillaAro")
	_cyl(Vector3(0, 1.5, -0.05), 0.82, 0.06, m_white, null, false, Vector3(90, 0, 0), "EscotillaPuerta")
	var wheel := MeshInstance3D.new()
	var wt := TorusMesh.new()
	wt.inner_radius = 0.15
	wt.outer_radius = 0.2
	wheel.mesh = wt
	wheel.material_override = Materials.plain(Color(0.9, 0.7, 0.1), 0.6, 0.4)
	wheel.rotation_degrees = Vector3(90, 0, 0)
	wheel.position = Vector3(0, 1.5, -0.12)
	_add(null, wheel, "EscotillaVolante")
	_label3d("ESCOTILLA DE ACCESO", Vector3(0, 2.7, -0.06), 180.0, 0.0025, Color(1.0, 0.85, 0.2))


func _build_lighting() -> void:
	_group("Iluminacion")
	for z in [-2.0, -5.5, -9.0, -12.2]:
		for sx in [-1.0, 1.0]:
			var p := _box(Vector3(sx * 1.2, H - 0.03, z), Vector3(0.4, 0.05, 2.0), m_light_panel, null, false, _unique("PanelLuz"))
			p.add_to_group("panel_luz", true)
			p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_light(Vector3(0, H - 0.4, z), Color(0.92, 0.96, 1.0), 0.75, 7.5)
	for z in [-3.0, -8.0, -12.5]:
		for sx in [-1.0, 1.0]:
			_light(Vector3(sx * 2.4, 0.35, z), Color(0.25, 0.55, 1.0), 0.9, 3.5, false, true)


# =============================================================== consola central
func _build_center_console() -> void:
	_group("ConsolaCentral")
	var base := _box(Vector3(0, 0.4, -11.3), Vector3(2.8, 0.8, 1.0), m_white, null, true, "Base")
	_box(Vector3(0, 0.1, -10.77), Vector3(2.5, 0.2, 0.06), m_dark, null, false)
	# losa inclinada con botones
	var slab := Node3D.new()
	slab.position = Vector3(0, 0.86, -11.2)
	slab.rotation_degrees.x = 14.0
	_add(null, slab, "LosaBotones")
	_box(Vector3.ZERO, Vector3(2.8, 0.08, 0.85), m_dark, slab, false)
	var colors := [Color(0.9, 0.15, 0.15), Color(0.2, 0.9, 0.3), Color(1.0, 0.85, 0.15), Color(0.2, 0.5, 1.0), Color(0.9, 0.95, 1.0)]
	for r in 3:
		for c in 6:
			var col: Color = colors[(r * 6 + c) % colors.size()]
			_box(Vector3(0.55 + c * 0.17, 0.05, -0.2 + r * 0.17), Vector3(0.1, 0.03, 0.1), Materials.emissive(col, 1.6), slab, false)
	for r in 3:
		for c in 4:
			_box(Vector3(-1.2 + c * 0.2, 0.05, -0.2 + r * 0.17), Vector3(0.15, 0.025, 0.1), Materials.emissive(Color(0.1, 0.6, 0.9), 1.2), slab, false)
	# panel trasero con pantallas
	var back := _box(Vector3(0, 1.17, -11.62), Vector3(2.9, 0.62, 0.1), m_dark, null, false, "PanelPantallas")
	back.rotation_degrees.x = -28.0
	_screen("energy_oxygen", Vector3(-0.98, 1.17, -11.56), 0.0, Vector2(0.88, 0.52), -28.0)
	_screen("overview", Vector3(0.0, 1.17, -11.56), 0.0, Vector2(0.98, 0.56), -28.0)
	_screen("food_water", Vector3(0.98, 1.17, -11.56), 0.0, Vector2(0.88, 0.52), -28.0)
	_interactable("central_console", Vector3(0, 0.55, -11.2), Vector3(2.8, 1.1, 1.1), Vector3(1.25, 1.05, -10.7))


# =============================================================== invernadero (pared izquierda)
func _build_greenhouse() -> void:
	_group("Invernadero")
	var gx := -2.5
	_box(Vector3(gx, 0.45, -6.5), Vector3(0.9, 0.9, 4.1), m_white, null, true, "Mueble")
	_box(Vector3(gx + 0.46, 0.45, -6.5), Vector3(0.02, 0.7, 3.8), m_dark, null, false)
	_box(Vector3(gx, 0.96, -6.5), Vector3(0.74, 0.12, 3.9), Materials.plain(Color(0.7, 0.72, 0.75), 0.5, 0.4), null, false)
	# estructura del módulo de cultivo
	_box(Vector3(-2.93, 1.45, -6.5), Vector3(0.12, 1.0, 4.0), m_white, null, false)
	_box(Vector3(gx, 2.0, -6.5), Vector3(0.9, 0.12, 4.0), m_white, null, false)
	_box(Vector3(gx + 0.1, 1.92, -6.5), Vector3(0.55, 0.03, 3.7), Materials.emissive(Color(0.95, 0.85, 1.0), 1.6), null, false, "TiraLuz")
	var hood := _box(Vector3(gx + 0.1, 1.47, -6.5), Vector3(0.72, 0.95, 3.9), Materials.glass(0.05, Color(0.8, 1.0, 0.9)), null, false, "Cupula")
	hood.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var gl_light := OmniLight3D.new()
	gl_light.position = Vector3(gx + 0.2, 1.7, -6.5)
	gl_light.light_color = Color(0.95, 0.85, 1.0)
	gl_light.light_energy = 0.8
	gl_light.omni_range = 4.5
	_add(null, gl_light, "Luz")
	for i in PLOT_COUNT:
		_plant_plot(i, Vector3(gx + 0.1, 1.03, -4.9 - 0.65 * i))
	_screen("food", Vector3(-2.97, 2.65, -6.5), 90.0, Vector2(2.0, 0.6))
	_interactable("greenhouse", Vector3(gx + 0.05, 1.05, -6.5), Vector3(1.0, 2.0, 4.2), Vector3(gx + 0.52, 0.75, -4.5))
	_label3d("INVERNADERO HIDROPÓNICO", Vector3(-2.95, 3.1, -6.5), 90.0, 0.0021, Color(0.6, 1.0, 0.7))


## Bandeja con todas sus etapas como nodos reales; solo se muestra la de vista previa
## (en ejecución el script plant_plot.gd muestra la etapa real).
func _plant_plot(i: int, pos: Vector3) -> void:
	var plot := Node3D.new()
	plot.set_script(PlantPlotScript)
	plot.set("index", i)
	plot.position = pos
	var leaf := Materials.plain(Color(0.2, 0.72, 0.28), 0.0, 0.6)
	var stem := Materials.plain(Color(0.3, 0.55, 0.2), 0.0, 0.7)
	var fruit := Materials.plain(Color(0.95, 0.25, 0.45), 0.0, 0.4)
	var seed_m := Materials.plain(Color(0.35, 0.22, 0.12), 0.0, 0.8)
	var cup := _cyl(Vector3.ZERO, 0.15, 0.06, Materials.plain(Color(0.85, 0.87, 0.9), 0.1, 0.5), plot, false, Vector3.ZERO, "Cuenco")
	cup.mesh.bottom_radius = 0.12
	var st: int = PREVIEW_STAGES[i % PREVIEW_STAGES.size()]
	var s1 := Node3D.new()
	s1.name = "Etapa1_Semilla"
	s1.visible = (st == 1)
	plot.add_child(s1)
	_sphere(Vector3(0, 0.05, 0), 0.035, seed_m, s1, "Semilla")
	plot.add_child(_plant_stage("Etapa2_Brote", 0.14, 2, false, stem, leaf, fruit, st == 2))
	plot.add_child(_plant_stage("Etapa3_Crecimiento", 0.3, 5, false, stem, leaf, fruit, st == 3))
	plot.add_child(_plant_stage("Etapa4_Madura", 0.4, 6, true, stem, leaf, fruit, st == 4))
	_add(root, plot, "Bandeja_%d" % (i + 1))


func _plant_stage(stage_name: String, height: float, leaves: int, with_fruit: bool, stem_m: Material, leaf_m: Material, fruit_m: Material, shown: bool) -> Node3D:
	var n := Node3D.new()
	n.name = stage_name
	n.visible = shown
	_cyl(Vector3(0, height * 0.5 + 0.03, 0), 0.015, height, stem_m, n, false, Vector3.ZERO, "Tallo")
	for k in leaves:
		var ang: float = TAU * k / leaves + k * 0.7
		var y: float = 0.06 + height * (0.35 + 0.65 * float(k) / leaves)
		var r: float = 0.09 + 0.01 * (leaves - k)
		var lf := MeshInstance3D.new()
		lf.name = "Hoja_%d" % (k + 1)
		var sm := SphereMesh.new()
		sm.radius = r
		sm.height = r * 0.5
		lf.mesh = sm
		lf.material_override = leaf_m
		lf.position = Vector3(cos(ang) * r * 0.8, y, sin(ang) * r * 0.8)
		lf.rotation_degrees = Vector3(cos(ang) * 18.0, 0, sin(ang) * 18.0)
		n.add_child(lf)
	if with_fruit:
		for k in 3:
			var a: float = TAU * k / 3.0
			_sphere(Vector3(cos(a) * 0.07, height * 0.7, sin(a) * 0.07), 0.04, fruit_m, n, "Fruto_%d" % (k + 1))
	return n


# =============================================================== laboratorio
func _build_lab() -> void:
	_group("Laboratorio")
	_box(Vector3(-2.6, 0.45, -11.6), Vector3(0.8, 0.9, 3.6), m_white)
	_box(Vector3(-2.6, 0.92, -11.6), Vector3(0.84, 0.05, 3.7), Materials.plain(Color(0.18, 0.2, 0.24), 0.3, 0.35), null, false)
	# estantes
	for y in [0.35, 0.7]:
		_box(Vector3(-2.35, y, -9.55), Vector3(0.5, 0.04, 0.6), m_dark, null, false)
	# frascos de muestras
	var jar_cols := [Color(0.45, 0.32, 0.22), Color(0.6, 0.28, 0.2), Color(0.25, 0.22, 0.2)]
	for i in 3:
		var jar := _cyl(Vector3(-2.7, 1.04, -10.0 - i * 0.28), 0.08, 0.16, Materials.plain(jar_cols[i], 0.0, 0.8))
		var cap := _cyl(Vector3(0, 0.1, 0), 0.085, 0.04, Materials.plain(Color(0.8, 0.8, 0.85), 0.8, 0.3), jar)
		cap.rotation_degrees = Vector3.ZERO
	for i in 3:
		_cyl(Vector3(-2.35, 0.96, -10.9 - i * 0.2), 0.09, 0.02, Materials.plain(Color(0.4, 0.4, 0.42), 0.6, 0.4))
	# microscopio y equipos
	_box(Vector3(-2.55, 1.0, -12.3), Vector3(0.22, 0.14, 0.3), m_dark, null, false)
	_box(Vector3(-2.55, 1.2, -12.35), Vector3(0.06, 0.35, 0.06), m_dark, null, false)
	_box(Vector3(-2.45, 1.0, -12.9), Vector3(0.4, 0.1, 0.3), Materials.plain(Color(0.9, 0.5, 0.1), 0.2, 0.6), null, false)
	# tablero de herramientas (pegboard)
	_box(Vector3(-2.96, 1.9, -9.9), Vector3(0.04, 1.0, 0.8), m_dark, null, false)
	var tool_cols := [Color(0.7, 0.72, 0.78), Color(0.9, 0.7, 0.1), Color(0.2, 0.4, 0.8)]
	for i in 3:
		_box(Vector3(-2.9, 1.9 + (i - 1) * 0.25, -9.9 + (i - 1) * 0.1), Vector3(0.05, 0.18, 0.03), Materials.plain(tool_cols[i], 0.7, 0.4), null, false)
	_screen("stats", Vector3(-2.97, 1.85, -12.0), 90.0, Vector2(1.3, 0.8))
	_interactable("lab_terminal", Vector3(-2.55, 1.1, -11.9), Vector3(0.9, 1.9, 3.4), Vector3(-2.15, 1.0, -10.2))
	_label3d("LABORATORIO DE INVESTIGACIÓN", Vector3(-2.95, 2.95, -11.6), 90.0, 0.0021, Color(0.6, 0.85, 1.0))


# =============================================================== consola de energía
func _build_power_corner() -> void:
	_group("ConsolaEnergia")
	_box(Vector3(-2.65, 0.5, -2.3), Vector3(0.6, 1.0, 2.2), m_white)
	var slab := _box(Vector3(-2.52, 1.05, -2.3), Vector3(0.5, 0.07, 2.1), m_dark, null, false)
	slab.rotation_degrees.z = -18.0
	for i in 6:
		_box(Vector3(-2.48, 1.1, -1.5 - i * 0.28), Vector3(0.1, 0.03, 0.12), Materials.emissive(Color(0.2, 0.9, 0.4), 1.4), null, false).rotation_degrees.z = -18.0
	_screen("power", Vector3(-2.97, 1.95, -2.3), 90.0, Vector2(1.7, 0.95))
	_interactable("power_console", Vector3(-2.65, 0.9, -2.3), Vector3(0.7, 1.9, 2.3), Vector3(-2.25, 1.15, -1.1))
	_label3d("ENERGÍA · PANELES SOLARES", Vector3(-2.95, 2.75, -2.3), 90.0, 0.0021, Color(1.0, 0.85, 0.2))


# =============================================================== pared derecha
func _build_right_wall() -> void:
	var tank_mat := Materials.plain(Color(0.42, 0.47, 0.43), 0.75, 0.4)
	var collar := Materials.plain(Color(0.15, 0.16, 0.18), 0.8, 0.4)
	var red := Materials.plain(Color(0.8, 0.15, 0.12), 0.3, 0.5)
	var blue := Materials.plain(Color(0.15, 0.35, 0.85), 0.3, 0.5)
	# --- tanques de O₂ ---
	_group("TanquesOxigeno")
	for i in 3:
		var z: float = -2.9 - i * 0.7
		_cyl(Vector3(2.45, 0.98, z), 0.28, 1.9, tank_mat, null, true)
		_cyl(Vector3(2.45, 0.4, z), 0.3, 0.08, collar)
		_cyl(Vector3(2.45, 1.5, z), 0.3, 0.08, collar)
		_sphere(Vector3(2.45, 1.95, z), 0.28, tank_mat)
		_cyl(Vector3(2.45, 2.28, z), 0.05, 0.14, collar)
	_cyl(Vector3(2.7, 2.15, -3.9), 0.035, 2.4, red, null, false, Vector3(90, 0, 0))
	_cyl(Vector3(2.78, 1.95, -3.9), 0.035, 2.4, blue, null, false, Vector3(90, 0, 0))
	_screen("oxygen", Vector3(2.97, 2.7, -3.9), -90.0, Vector2(1.5, 0.75))
	_interactable("o2_tank", Vector3(2.45, 1.0, -3.9), Vector3(0.9, 2.1, 2.3), Vector3(2.1, 2.4, -2.7))
	_label3d("RESERVA DE OXÍGENO", Vector3(2.95, 3.15, -3.9), -90.0, 0.0021, Color(0.6, 0.85, 1.0))
	# --- válvula de distribución ---
	_group("ValvulaOxigeno")
	_box(Vector3(2.9, 1.3, -5.7), Vector3(0.2, 0.7, 0.6), m_dark, null, false)
	for i in 3:
		_box(Vector3(2.79, 1.12 + i * 0.18, -5.7), Vector3(0.02, 0.1, 0.4), Materials.emissive(Color(0.2, 0.7, 1.0), 1.5), null, false)
	var vw := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.08
	tm.outer_radius = 0.11
	vw.mesh = tm
	vw.material_override = red
	vw.rotation_degrees = Vector3(0, 0, 90)
	vw.position = Vector3(2.76, 1.45, -5.7)
	_add(null, vw, "Volante")
	_interactable("o2_valve", Vector3(2.85, 1.3, -5.7), Vector3(0.4, 0.8, 0.7), Vector3(2.7, 1.72, -5.7))
	# --- generador de oxígeno ---
	_group("GeneradorOxigeno")
	_box(Vector3(2.45, 0.85, -7.0), Vector3(1.0, 1.7, 1.1), m_white)
	_box(Vector3(1.94, 1.3, -7.0), Vector3(0.02, 0.4, 0.7), Materials.emissive(Color(0.1, 0.5, 0.9), 1.5), null, false)
	_box(Vector3(1.94, 0.55, -7.0), Vector3(0.02, 0.3, 0.8), m_dark, null, false)
	_interactable("o2_generator", Vector3(2.45, 0.9, -7.0), Vector3(1.05, 1.8, 1.15), Vector3(1.9, 1.62, -6.6))
	_label3d("GENERADOR O₂", Vector3(1.93, 1.0, -7.0), -90.0, 0.002, Color(1, 1, 1))
	# --- agua ---
	_group("SistemaAgua")
	var tank_w := Materials.plain(Color(0.5, 0.55, 0.6), 0.8, 0.35)
	_cyl(Vector3(2.35, 0.8, -8.9), 0.5, 1.6, tank_w, null, true)
	var level := _cyl(Vector3(1.86, 0.85, -8.9), 0.04, 1.1, Materials.emissive(Color(0.2, 0.6, 1.0), 1.5))
	level.rotation_degrees = Vector3.ZERO
	_cyl(Vector3(2.35, 1.65, -8.9), 0.5, 0.1, collar)
	_interactable("water_tank", Vector3(2.35, 0.85, -8.9), Vector3(1.1, 1.8, 1.1), Vector3(1.75, 1.7, -8.9))
	_box(Vector3(2.5, 0.65, -10.5), Vector3(0.9, 1.3, 1.1), m_white)
	_box(Vector3(2.04, 0.9, -10.5), Vector3(0.02, 0.35, 0.7), Materials.emissive(Color(0.1, 0.8, 0.7), 1.3), null, false)
	_interactable("water_recycler", Vector3(2.5, 0.95, -10.5), Vector3(0.95, 1.9, 1.15), Vector3(2.0, 1.28, -10.1))
	_cyl(Vector3(2.7, 0.65, -12.0), 0.22, 1.3, Materials.plain(Color(0.6, 0.75, 0.85), 0.5, 0.3), null, true)
	_cyl(Vector3(2.7, 1.35, -12.0), 0.25, 0.1, collar)
	_cyl(Vector3(2.7, 0.15, -12.0), 0.25, 0.1, collar)
	_interactable("water_filter", Vector3(2.7, 0.95, -12.0), Vector3(0.6, 1.9, 0.6), Vector3(2.38, 1.5, -12.0))
	_screen("water", Vector3(2.97, 2.35, -10.5), -90.0, Vector2(1.7, 0.85))
	_label3d("AGUA · FILTRACIÓN · RECICLAJE", Vector3(2.95, 3.05, -10.5), -90.0, 0.0021, Color(0.5, 0.9, 1.0))
	# --- armario de herramientas (mantenimiento) ---
	_group("ArmarioHerramientas")
	_box(Vector3(2.8, 1.35, -1.3), Vector3(0.35, 1.5, 1.1), m_dark)
	_box(Vector3(2.62, 1.35, -1.3), Vector3(0.02, 1.3, 0.95), Materials.plain(Color(0.08, 0.1, 0.12), 0.3, 0.7), null, false)
	for i in 4:
		_box(Vector3(2.6, 0.95 + i * 0.28, -1.3 + (i % 2) * 0.2 - 0.1), Vector3(0.05, 0.05, 0.4), Materials.plain([Color(0.9, 0.7, 0.1), Color(0.7, 0.72, 0.78), Color(0.2, 0.4, 0.85), Color(0.8, 0.2, 0.15)][i], 0.6, 0.4), null, false)
	var door := _box(Vector3(2.4, 1.35, -0.6), Vector3(0.04, 1.4, 0.5), m_white, null, false)
	door.rotation_degrees.y = 60.0
	_interactable("toolbox", Vector3(2.7, 1.3, -1.3), Vector3(0.6, 1.8, 1.3), Vector3(2.5, 2.1, -1.3))
	_label3d("MANTENIMIENTO", Vector3(2.94, 2.35, -1.3), -90.0, 0.0021, Color(1.0, 0.85, 0.2))


# =============================================================== decoración
func _build_decor() -> void:
	_group("Decoracion")
	# caja de control del techo sobre la ventana
	_box(Vector3(0, 3.05, -13.6), Vector3(3.2, 0.6, 0.6), m_wall, null, false)
	var lamp_cols := [Color(1, 0.85, 0.1), Color(0.9, 0.15, 0.1), Color(0.2, 0.9, 0.3), Color(0.2, 0.5, 1.0)]
	for i in 8:
		_box(Vector3(-1.25 + i * 0.12, 3.17, -13.28), Vector3(0.07, 0.07, 0.03), Materials.emissive(lamp_cols[0], 2.0), null, false)
	for i in 8:
		_box(Vector3(-1.25 + i * 0.12, 3.02, -13.28), Vector3(0.07, 0.05, 0.03), Materials.emissive(lamp_cols[(i % 3) + 1], 1.4), null, false)
	_box(Vector3(0.55, 3.07, -13.27), Vector3(0.45, 0.3, 0.03), Materials.emissive(Color(0.2, 0.55, 1.0), 1.4), null, false)
	_box(Vector3(1.25, 3.07, -13.27), Vector3(0.45, 0.3, 0.03), Materials.emissive(Color(0.1, 0.9, 0.4), 0.8), null, false)
	# parches y señales
	_patch(Vector3(-2.98, 2.4, -3.4), 90.0)
	_patch(Vector3(2.98, 2.0, -12.9), -90.0)
	_sign(Vector3(-2.97, 1.0, -1.0), 90.0, "PRECAUCIÓN", Color(1.0, 0.85, 0.1))
	_sign(Vector3(2.97, 0.8, -13.2), -90.0, "ADVERTENCIA", Color(1.0, 0.3, 0.2))
	_label3d("LUNAR BASE 01", Vector3(0, 3.28, -0.1), 180.0, 0.007, Color(0.7, 0.9, 1.0))


func _patch(pos: Vector3, rot_y: float) -> void:
	var inward: float = sign(-pos.x)
	_cyl(pos + Vector3(0.012 * inward, 0, 0), 0.33, 0.012, Materials.plain(Color(0.9, 0.92, 1.0), 0.2, 0.5), null, false, Vector3(0, 0, 90))
	_cyl(pos + Vector3(0.02 * inward, 0, 0), 0.29, 0.012, Materials.plain(Color(0.08, 0.2, 0.55), 0.2, 0.6), null, false, Vector3(0, 0, 90))
	_label3d("LB-01", pos + Vector3(0.03 * inward, 0, 0), rot_y, 0.0025, Color(1, 1, 1))


func _sign(pos: Vector3, rot_y: float, text: String, col: Color) -> void:
	var b := _box(pos, Vector3(0.03, 0.3, 0.55), Materials.plain(col, 0.0, 0.7), null, false)
	b.rotation_degrees.y = 0.0
	_label3d(text, pos + Vector3(0.02 * sign(-pos.x), 0, 0), rot_y, 0.0022, Color(0.05, 0.05, 0.05))


# =============================================================== cámaras de vista interior
## Cámaras dentro de la base (altura de ojos, current = false) para ver el interior
## desde adentro en el visor 3D del editor: seleccione una, pulse "Preview".
func _build_views() -> void:
	_group("Exterior")
	var views := [
		["Vista_Entrada", Vector3(0, 1.6, -1.0), 0.0, -4.0, 80.0],
		["Vista_ConsolaCentral", Vector3(0, 1.6, -8.3), 0.0, -14.0, 80.0],
		["Vista_Ventana", Vector3(0, 1.6, -9.3), 0.0, 2.0, 80.0],
		["Vista_Invernadero", Vector3(0.3, 1.6, -6.5), 90.0, -10.0, 90.0],
		["Vista_Laboratorio", Vector3(0.4, 1.6, -8.9), 50.0, -12.0, 85.0],
		["Vista_ConsolaEnergia", Vector3(0.3, 1.6, -2.3), 90.0, -8.0, 90.0],
		["Vista_TanquesOxigeno", Vector3(0.3, 1.6, -3.9), -90.0, -6.0, 90.0],
		["Vista_GeneradorOxigeno", Vector3(0.3, 1.6, -6.9), -90.0, -8.0, 90.0],
		["Vista_SistemaAgua", Vector3(0.9, 1.6, -9.4), -65.0, -8.0, 85.0],
		["Vista_Escotilla", Vector3(0, 1.6, -12.0), 180.0, -2.0, 80.0],
		["Vista_Cenital", Vector3(0, 3.2, -7.0), 0.0, -90.0, 90.0],
	]
	for v in views:
		var cam := Camera3D.new()
		cam.position = v[1]
		cam.rotation_degrees = Vector3(v[3], v[2], 0)
		cam.fov = v[4]
		cam.near = 0.05
		cam.far = 1500.0
		cam.current = false
		_add(root, cam, v[0])


# =============================================================== exterior
func _build_exterior() -> void:
	_cur = root
	_build_terrain()
	# --- Tierra ---
	var earth := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 7.0
	sm.height = 14.0
	sm.radial_segments = 48
	sm.rings = 24
	earth.mesh = sm
	earth.material_override = Materials.earth()
	earth.position = Vector3(26, 21.0, -205)
	earth.rotation_degrees = Vector3(10, 150, 18)
	earth.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_add(root, earth, "Tierra")
	# --- celdas solares (módulo reutilizable CeldaSolar.tscn) ---
	_group("CeldasSolares")
	var spots := [Vector3(-6, -0.2, -28), Vector3(-2, -0.2, -28), Vector3(2, -0.2, -28), Vector3(6, -0.2, -28),
		Vector3(-4, -0.2, -40), Vector3(4, -0.2, -40)]
	for i in spots.size():
		_celda_solar(i, spots[i], (i % 3 - 1) * 8.0)
	# --- vehículos y equipos exteriores ---
	_group("Exterior")
	_build_rover(Vector3(-3.5, -0.2, -21.0), 28.0)
	_build_lander(Vector3(4.2, -0.2, -22.5))
	var metal := Materials.plain(Color(0.78, 0.8, 0.83), 0.9, 0.3)
	var ant := Node3D.new()
	ant.position = Vector3(-9, 0, -20)
	_add(null, ant, "AntenaParabolica")
	_cyl(Vector3(0, 1.0, 0), 0.06, 2.0, metal, ant, true, Vector3.ZERO, "AntenaMastil")
	_cyl(Vector3(0, 2.1, -0.2), 0.7, 0.05, metal, ant, false, Vector3(70, 0, 0), "AntenaPlato")


func _celda_solar(i: int, pos: Vector3, yaw: float) -> void:
	var c := Node3D.new()
	c.set_script(CeldaScript)
	c.set("index", i)
	c.position = pos
	c.rotation_degrees.y = yaw
	var metal := Materials.plain(Color(0.7, 0.72, 0.75), 0.9, 0.35)
	_cyl(Vector3(0, 0.05, 0), 0.25, 0.1, metal, c, true, Vector3.ZERO, "Base")
	_cyl(Vector3(0, 0.65, 0), 0.07, 1.3, metal, c, true, Vector3.ZERO, "Poste")
	var tilt := Node3D.new()
	tilt.name = "Inclinacion"
	tilt.position = Vector3(0, 1.3, 0)
	tilt.rotation_degrees.x = -38.0
	c.add_child(tilt)
	_box(Vector3.ZERO, Vector3(3.0, 0.06, 1.8), Materials.solar_cells(), tilt, true, "Celdas")
	_box(Vector3(0, 0, 0.9), Vector3(3.1, 0.04, 0.06), metal, tilt, false, "MarcoA")
	_box(Vector3(0, 0, -0.9), Vector3(3.1, 0.04, 0.06), metal, tilt, false, "MarcoB")
	_sphere(Vector3(0, 1.45, 0), 0.08, Materials.emissive(Color(0.2, 1.0, 0.4), 3.0), c, "Luz")
	_add(root, c, "CeldaSolar_%d" % (i + 1))


## Genera el relieve lunar, lo guarda como recurso (malla + colisión trimesh)
## y lo coloca como MeshInstance3D "TerrenoLunar" -> "Solid" -> CollisionShape3D.
func _build_terrain() -> void:
	var gen := MeshInstance3D.new()
	gen.set_script(TerrainScript)
	gen._ready()
	var mesh: ArrayMesh = gen.mesh
	var mat: Material = gen.material_override
	DirAccess.make_dir_recursive_absolute("res://Assets/Models")
	ResourceSaver.save(mesh, TERRAIN_MESH)
	ResourceSaver.save(mesh.create_trimesh_shape(), TERRAIN_SHAPE)
	gen.free()
	var mi := MeshInstance3D.new()
	mi.mesh = load(TERRAIN_MESH)
	mi.material_override = mat
	_add(root, mi, "TerrenoLunar")
	_solid(mi, load(TERRAIN_SHAPE))


func _build_rover(pos: Vector3, yaw: float) -> void:
	var r := Node3D.new()
	r.position = pos
	r.rotation_degrees.y = yaw
	_add(null, r, "RoverLunar")
	var body_mat := Materials.plain(Color(0.62, 0.52, 0.38), 0.4, 0.6)
	var dark := Materials.plain(Color(0.12, 0.12, 0.14), 0.6, 0.5)
	_box(Vector3(0, 0.75, 0), Vector3(2.2, 0.5, 1.2), body_mat, r, true, "RoverChasis")
	_box(Vector3(-0.3, 1.15, 0), Vector3(1.0, 0.4, 1.0), body_mat, r, true, "RoverCabina")
	_box(Vector3(0.5, 1.05, 0), Vector3(0.5, 0.25, 0.9), dark, r, false, "RoverEquipo")
	for wx in [-0.8, 0.0, 0.8]:
		for wz in [-0.75, 0.75]:
			_cyl(Vector3(wx, 0.35, wz), 0.33, 0.25, dark, r, true, Vector3(90, 0, 0), _unique("RoverRueda"))
	_cyl(Vector3(-0.8, 1.7, 0.3), 0.025, 1.0, Materials.plain(Color(0.8, 0.8, 0.85), 0.9, 0.3), r, false, Vector3.ZERO, "RoverMastil")
	_cyl(Vector3(-0.8, 2.2, 0.3), 0.18, 0.04, Materials.plain(Color(0.9, 0.9, 0.95), 0.8, 0.3), r, false, Vector3(60, 0, 0), "RoverAntena")
	_box(Vector3(-0.2, 1.38, 0), Vector3(0.9, 0.03, 0.9), Materials.solar_cells(), r, false, "RoverPanelSolar")


func _build_lander(pos: Vector3) -> void:
	var l := Node3D.new()
	l.position = pos
	_add(null, l, "ModuloAterrizaje")
	var gold := Materials.plain(Color(0.8, 0.62, 0.2), 0.85, 0.35)
	var metal := Materials.plain(Color(0.75, 0.77, 0.8), 0.9, 0.35)
	_box(Vector3(0, 1.2, 0), Vector3(1.4, 1.0, 1.4), gold, l, true, "ModuloCuerpo")
	_box(Vector3(0, 1.85, 0), Vector3(0.9, 0.35, 0.9), metal, l, false, "ModuloCupula")
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_cyl(Vector3(sx * 0.95, 0.55, sz * 0.95), 0.05, 1.5, metal, l, false, Vector3(sz * 22.0, 0, -sx * 22.0), _unique("ModuloPata"))
			_cyl(Vector3(sx * 1.2, 0.05, sz * 1.2), 0.22, 0.06, metal, l, true, Vector3.ZERO, _unique("ModuloPlantilla"))
	for sx in [-1.0, 1.0]:
		_box(Vector3(sx * 1.9, 1.7, 0), Vector3(1.7, 0.04, 1.1), Materials.solar_cells(), l, false, _unique("ModuloPanelSolar"))
	_cyl(Vector3(0, 2.35, 0), 0.03, 0.8, metal, l, false, Vector3.ZERO, "ModuloAntena")
