extends Node
## Paso 2 del horneado: construye la estación con el generador y la guarda como
## la escena principal editable Scenes/Main/Main.tscn (todos los nodos en línea).
##   godot --headless --path . res://Scenes/Tests/BakeStation.tscn
## (requiere haber creado e importado antes las texturas PNG)

const Generator = preload("res://Scripts/Tools/station_generator.gd")
const OUT := "res://Scenes/Main/Main.tscn"


func _ready() -> void:
	var gen = Generator.new()
	var root: Node3D = gen.build()
	root.set_script(load("res://Scripts/Environment/station_controller.gd"))
	_add_instance(root, "res://Scenes/Player/Player.tscn", "Player", Transform3D(Basis.IDENTITY, Vector3(0, 0.05, -4.5)))
	_add_instance(root, "res://Scenes/Interface/HUD.tscn", "HUD")
	_add_instance(root, "res://Scenes/Interface/Dashboard.tscn", "Dashboard")
	_add_instance(root, "res://Scenes/Interface/ReportScreen.tscn", "ReportScreen")
	_set_owners(root, root)
	var ps := PackedScene.new()
	var err := ps.pack(root)
	if err != OK:
		push_error("pack falló: %d" % err)
		get_tree().quit(1)
		return
	err = ResourceSaver.save(ps, OUT)
	print("Guardado %s (%s) · %d nodos" % [OUT, "ok" if err == OK else "ERROR %d" % err, _count(root)])
	root.free()
	get_tree().quit(0 if err == OK else 1)


## Asigna `owner` a todos los nodos para que se guarden. No entra en las
## escenas instanciadas (Interactable, WorldScreen, CeldaSolar): se guardan como instancias.
func _set_owners(node: Node, root: Node) -> void:
	for c in node.get_children():
		c.owner = root
		if c.scene_file_path == "":
			_set_owners(c, root)


func _add_instance(root: Node3D, path: String, nm: String, xf: Transform3D = Transform3D.IDENTITY) -> void:
	var n: Node = load(path).instantiate()
	n.name = nm
	if n is Node3D:
		n.transform = xf
	root.add_child(n)


func _count(n: Node) -> int:
	var t := 1
	for c in n.get_children():
		t += _count(c) if c.scene_file_path == "" else 1
	return t
