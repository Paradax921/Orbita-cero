extends SceneTree
## Paso 1 del horneado: genera las texturas procedurales y las guarda como PNG
## en Assets/Textures. Ejecutar:
##   godot --headless --path . --script res://Scripts/Tools/bake_textures.gd
## Después: godot --headless --path . --import

const Materials = preload("res://Scripts/Environment/materials.gd")


func _initialize() -> void:
	Materials.use_png = false
	DirAccess.make_dir_recursive_absolute("res://Assets/Textures")
	var textures := {
		"panel": Materials.panel_texture(),
		"floor": Materials.floor_texture(),
		"cells": Materials.solar_cell_texture(),
		"grain_3": Materials.grain_texture(3, 0.58, 0.55),
		"earth": Materials.earth_texture(),
	}
	for key in textures:
		var img: Image = textures[key].get_image()
		img.clear_mipmaps()
		var path: String = Materials.png_path(key)
		var err := img.save_png(path)
		print("%s -> %s (%s)" % [key, path, "ok" if err == OK else "ERROR %d" % err])
	quit()
