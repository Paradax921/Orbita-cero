extends Resource
## Parámetros configurables de la simulación (editable desde el Inspector
## abriendo Resources/sim_config.tres, o en juego desde la pestaña "Config").

@export_group("Jugador")
@export var move_speed: float = 4.0
@export var sprint_multiplier: float = 1.6
@export var mouse_sensitivity: float = 0.0025

@export_group("Misión")
## Duración de la misión en segundos reales.
@export var mission_duration: float = 900.0
## Segundos de misión mostrados por cada segundo real (solo reloj visual).
@export var clock_scale: float = 96.0
## Multiplicador de velocidad de simulación.
@export var sim_speed: float = 1.0
## Duración (s reales) de un ciclo día/noche lunar acelerado.
@export var day_cycle: float = 480.0
@export var crew_size: int = 4

@export_group("Eventos")
@export var first_event_delay: float = 40.0
@export var event_interval_min: float = 45.0
@export var event_interval_max: float = 80.0
@export var max_active_events: int = 3
## 1.0 normal; >1 eventos más frecuentes.
@export var difficulty: float = 1.0
